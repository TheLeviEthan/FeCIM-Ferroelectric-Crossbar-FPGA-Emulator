# B5 — adc_quant: shared output quantizer with round-to-nearest

| | |
|---|---|
| **Owner** | Megan Mendez |
| **Due** | Fri 20 Nov |
| **Board bucket** | Bucket 3 — Lane B |
| **Board task** | B5: `adc_quant` (shared, round-to-nearest) |
| **Needs first** | C2 (ADC golden vectors) |
| **Unblocks** | C5, A4 re-test |
| **AI version** | `B5_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

In an analog crossbar, each column's answer is a current. To use it digitally, an analog-to-digital converter (ADC) has to measure that current, and ADCs have limited resolution. A 6-bit ADC can only report 64 different values, however precise the analog sum was. ADCs also dominate the area and power of real compute-in-memory chips, so designers want as few bits as they can get away with. **ADC quantization** is the sixth non-ideality, and "how few bits can the classifier tolerate" is one of the most practical questions our emulator can answer.

Our accumulators are exact 32-bit integers, so we model the ADC by throwing away low-order bits of each result as it leaves the array. One shared block does it, because results come out one per cycle during the drain.

Two details decide whether the model is honest. The ADC's full scale has to be the range the signal actually uses (24 bits), not the 32-bit container, or an 8-bit setting would squash every result into one or two codes. And it must *round* instead of truncating, because truncation pulls every result slightly downward, and that bias would look like a weight-mapping bug.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Implement:** `rtl/array/adc_quant.sv` (skeleton, currently `assign adc_out = acc_in;`). It's purely combinational: `noise_en`, `adc_bits[4:0]`, `acc_in[31:0]`, `adc_out[31:0]`.
- **Sits between:** `mac_array.chain_out` and both `result_buffer.wdata` and `argmax_unit.in_val` (see `fecim_top.sv`).
- **New testbench:** `tb/sv/tb_adc_quant.sv`, in `tb/run_sims.sh` and CI.
- **Golden vectors (from C2):** `tb/golden/adc/`.
- **Reference:** `adc_quantize()` in `model/src/read_path.cpp`.
- **Specs:** `03-lane-b-array/mac-array-spec.md` §9 and §12 test 9; `01-contract/protocol.md` §6.5.

## 3. How to build it

```systemverilog
logic [4:0] sh;
// Full scale is the USED range (ACC_USED_W = 24), not the 32-bit container.
assign sh = (adc_bits >= ACC_USED_W) ? 5'd0 : 5'(ACC_USED_W - adc_bits);

assign adc_out = (noise_en.adc && sh != 5'd0)
               ? (($signed(acc_in) + (32'sd1 <<< (sh - 1))) >>> sh) <<< sh    // round, then rescale
               : acc_in;
```

What the three steps do, with `adc_bits = 20` (`sh = 4`) and an input of 1000:

1. Add half a step: `1000 + 8 = 1008`.
2. Arithmetic shift right by 4: `63` (the ADC code).
3. Shift left by 4: `1008`. The result stays on the original scale, just snapped to multiples of 16.

For −1000: `−1000 + 8 = −992`, `>>> 4` is `−62`, `<<< 4` is `−992`.

The shift must be arithmetic (`>>>` on a signed value) so negative numbers keep their sign.

## 4. How you know it's done

- Every case in `tb/golden/adc/` passes for `adc_bits` ∈ {4, 8, 16, 24} and for both signs.
- `adc_bits` = 24 through 31 are exact no-ops (output equals input for every tested value).
- With `NOISE_EN.adc = 0`, output equals input whatever `adc_bits` is.
- Zero mean error over random inputs: the average of `adc_out − acc_in` is close to 0, not negative.
- Lint clean with the skeleton waivers removed.

## 5. Watch out for

- **`(x + half) >> sh` isn't the same as "round to nearest" in the textbook sense for negative halves.** The model does exactly `(x + half) >> sh`, so copy that expression; don't use a rounding idiom that treats negatives symmetrically.
- **`adc_bits` below 4** is rejected by the driver but the RTL still computes something. Whatever it computes, the model computes the same; don't add a clamp the model doesn't have.
- **Timing.** This block is combinational in front of a 32-bit compare in `argmax_unit` and the result buffer write. If A7 flags that path, the fix is to register `adc_out` and delay the drain strobes by one cycle, coordinated with Zhiting.
- The add can't overflow in practice (the input is within ±8.3 million), so no saturation is needed.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

