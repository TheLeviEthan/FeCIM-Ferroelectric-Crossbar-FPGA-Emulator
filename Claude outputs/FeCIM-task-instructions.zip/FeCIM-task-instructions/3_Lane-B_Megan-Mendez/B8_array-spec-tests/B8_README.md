# B8 — mac-array-spec section 12 tests 2 to 10, all passing

| | |
|---|---|
| **Owner** | Megan Mendez |
| **Due** | Wed 25 Nov |
| **Board bucket** | Bucket 3 — Lane B |
| **Board task** | B8: mac-array-spec §12 tests 2–10, all passing |
| **Needs first** | B2, B4, B5, B6, B7; C4 (covers test 2) |
| **Unblocks** | C10 (verification report), P2 results slides |
| **AI version** | `B8_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

"It passed simulation" isn't a claim an engineer can defend unless they can say *which properties* were tested. The array spec already lists them: ten specific things that have to be true of the MAC array, each aimed at one way it could be subtly wrong.

Several of these go beyond "RTL matches the model", and that's why they matter. If the model and the RTL share the same misunderstanding, they agree with each other and are both wrong. So these tests ask independent questions. Does the noise actually have zero mean? Are two lanes' noise sequences actually uncorrelated? Does the worst possible input overflow the accumulator? Is the cheap one-multiplier IR-drop trick actually identical to the expensive version?

One result here goes straight into the report: the *measured* statistics of the read noise. Our generator makes a bell-shaped distribution, but it isn't a textbook Gaussian, and saying so with measured numbers is more credible than claiming a shape we didn't verify.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Testbenches:** new files under `tb/sv/`, one per test or small group, each registered in `tb/run_sims.sh`. Fast ones go in CI.
- **Sample dumps and analysis:** have a testbench write samples to a text file under `build/`, and analyze them with a small script, for example `tb/scripts/noise_stats.py` (plain Python, standard library only).
- **Results table:** new `docs/verification/array-tests.md`, linked from the verification report (C10).
- **Spec:** `03-lane-b-array/mac-array-spec.md` §12.

## 3. How to build it

| # | Test | How to do it | Pass criterion |
|---|---|---|---|
| 2 | Full array, clean, bit-exact | Ethan's C4 run covers it; link to it | 1,000 matrices, zero mismatches |
| 3 | LFSR reproducibility | same seed and inputs, two computes, random idle gap and a `reseed` between | identical results |
| 4 | Noise distribution | dump 1,000,000 `ih9` samples from one lane | mean ≈ 0; record σ and kurtosis; no short period |
| 5 | Lane decorrelation | dump `noise_q` from lanes 0, 1, 31, 63; correlate pairs | correlation near 0 |
| 6 | Clamp boundary | max `READ_SIGMA`, force extreme LFSR states | `noise_q` exactly ±127 at the limits; `w_n` fits 9 bits |
| 7 | Accumulator headroom | all weights +127, all activations 255, max noise, 128 rows; then all negative | no overflow; value equals the hand calculation |
| 8 | Drain ordering | distinct value per column | each lands at its own address (shared with B7 test 3) |
| 9 | ADC rounding | sweep `adc_bits` 4 to 31 over random inputs | mean error ≈ 0; 24–31 are exact no-ops |
| 10 | IR factorization | compare with a reference in the testbench that attenuates each *product* | bit-identical for every row profile |

Useful numbers to compare against (from `cell-physics-derivation.md` §4.3): the theoretical σ of `ih9` is about 73.9, and the noise σ in weight LSBs is about `0.144 × READ_SIGMA`.

For test 7, the worst case is `254 × 255 × 128 = 8,290,560`, which needs 24 bits signed. The assertion is that the 32-bit accumulator holds exactly that value.

```python
# tb/scripts/noise_stats.py (sketch)
xs = [int(line) for line in open(sys.argv[1])]
n = len(xs); mean = sum(xs) / n
var = sum((x - mean) ** 2 for x in xs) / n
kurt = sum((x - mean) ** 4 for x in xs) / n / var ** 2
print(f"n={n} mean={mean:.3f} sigma={var ** 0.5:.2f} kurtosis={kurt:.3f}")
```

## 4. How you know it's done

- Each of tests 3–10 has a named testbench or script and a recorded result; test 2 links to the C4 run.
- `docs/verification/array-tests.md` has one row per test: what was run, the command, the result, and the commit it was run at.
- The measured mean, σ and kurtosis of the read noise are recorded for the report, next to the theoretical σ.
- The fast tests run in CI.

## 5. Watch out for

- **Report measured moments; don't claim a named distribution.** The four summed bytes come from one LFSR state and aren't independent. A Gaussian has kurtosis 3; ours will differ, and that's a finding, not a failure.
- **Test 10 depends on rounding.** `(w × ((a × α) >> 8))` and `((w × a) × α) >> 8` are *not* bit-identical in general, because the shift truncates at a different point. The spec's claim is about the unrounded algebra. If your reference attenuates each product and then shifts, expect small differences, and report exactly what you find: the model and RTL both attenuate the activation, so they agree with each other either way, but the report must describe the approximation correctly.
- A million-sample dump is slow under Verilator if the whole array is instantiated. Test one `read_noise` instance alone.
- Tests 11 (multiplier packing) and 12 (timing) are Zhiting's A5 and A7; reference them in the table.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

