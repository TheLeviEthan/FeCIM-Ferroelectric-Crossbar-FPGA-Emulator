# AI prompt — B8: mac-array-spec section 12 tests 2 to 10, all passing

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **B8 — mac-array-spec section 12 tests 2 to 10, all passing**, owned by Megan Mendez, due Wed 25 Nov.

Write the remaining array verification tests from `mac-array-spec.md` §12 (tests 3 to 10), an analysis script for the statistical ones, and the results table that records them.

Each test should be its own small self-checking testbench with a clear pass criterion and a `PASS` line, registered in `tb/run_sims.sh`. For the statistical tests (noise moments, lane correlation, ADC mean error), have the testbench dump raw samples and compute statistics in a standard-library-only Python script; state the acceptance thresholds you chose and why.

Pay particular attention to test 10. Check whether attenuating the activation before the multiply is bit-identical to attenuating each product once the `>> 8` truncation is included, show a small numeric example either way, and report plainly what you find, because the project report has to describe this approximation accurately. Editable files: new files under `tb/sv/` and `tb/scripts/`, `tb/run_sims.sh`, `.github/workflows/ci.yml`, `docs/verification/array-tests.md` (new). Don't modify RTL.

## Where the work goes

- **Testbenches:** new files under `tb/sv/`, one per test or small group, each registered in `tb/run_sims.sh`. Fast ones go in CI.
- **Sample dumps and analysis:** have a testbench write samples to a text file under `build/`, and analyze them with a small script, for example `tb/scripts/noise_stats.py` (plain Python, standard library only).
- **Results table:** new `docs/verification/array-tests.md`, linked from the verification report (C10).
- **Spec:** `03-lane-b-array/mac-array-spec.md` §12.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

| # | Test | How to do it | Pass criterion |
|---|---|---|---|
| 2 | Full array, clean, bit-exact | Ethan's C4 run covers it; link to it | 1,000 matrices, zero mismatches |
| 3 | LFSR reproducibility | same seed and inputs, two computes, random idle gap and a `reseed` between | identical results |
| 4 | Noise distribution | dump 1,000,000 `ih9` samples from one lane | mean ≈ 0; record σ and kurtosis; no short period |
| 5 | Lane decorrelation | dump `noise_q` from lanes 0, 1, 31, 63; correlate pairs | correlation near 0 |
| 6 | Clamp boundary | max `READ_SIGMA`, force extreme LFSR states | `noise_q` exactly ±127 at the limits; `w_n` fits 9 bits |
| 7 | Accumulator headroom | all weights +127, all activations 255, max noise, 128 rows; then all negative | no overflow; value equals the hand calculation |
| 8 | Drain ordering | distinct value per column | each lands at its own address (shared with B7 test 3) |
| 9 | ADC rounding | sweep `adc_bits` 4 to 31 over random inputs | mean error ≈ 0; 24–31 are exact no-ops |
| 10 | IR factorization | compare with a reference in the testbench that attenuates each *product* | bit-identical for every row profile |

Useful numbers to compare against (from `cell-physics-derivation.md` §4.3): the theoretical σ of `ih9` is about 73.9, and the noise σ in weight LSBs is about `0.144 × READ_SIGMA`.

For test 7, the worst case is `254 × 255 × 128 = 8,290,560`, which needs 24 bits signed. The assertion is that the 32-bit accumulator holds exactly that value.

```python
# tb/scripts/noise_stats.py (sketch)
xs = [int(line) for line in open(sys.argv[1])]
n = len(xs); mean = sum(xs) / n
var = sum((x - mean) ** 2 for x in xs) / n
kurt = sum((x - mean) ** 4 for x in xs) / n / var ** 2
print(f"n={n} mean={mean:.3f} sigma={var ** 0.5:.2f} kurtosis={kurt:.3f}")
```

## Acceptance checks

- Each of tests 3–10 has a named testbench or script and a recorded result; test 2 links to the C4 run.
- `docs/verification/array-tests.md` has one row per test: what was run, the command, the result, and the commit it was run at.
- The measured mean, σ and kurtosis of the read noise are recorded for the report, next to the theoretical σ.
- The fast tests run in CI.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Report measured moments; don't claim a named distribution.** The four summed bytes come from one LFSR state and aren't independent. A Gaussian has kurtosis 3; ours will differ, and that's a finding, not a failure.
- **Test 10 depends on rounding.** `(w × ((a × α) >> 8))` and `((w × a) × α) >> 8` are *not* bit-identical in general, because the shift truncates at a different point. The spec's claim is about the unrounded algebra. If your reference attenuates each product and then shifts, expect small differences, and report exactly what you find: the model and RTL both attenuate the activation, so they agree with each other either way, but the report must describe the approximation correctly.
- A million-sample dump is slow under Verilator if the whole array is instantiated. Test one `read_noise` instance alone.
- Tests 11 (multiplier packing) and 12 (timing) are Zhiting's A5 and A7; reference them in the table.

## Files to read first (attach or paste these if you're using a chatbot)

- `rtl/fecim_pkg.sv`
- `rtl/array/mac_lane.sv`, `rtl/array/mac_array.sv`, `rtl/array/read_noise.sv`, `rtl/array/act_buffer.sv`, `rtl/array/adc_quant.sv`
- `tb/sv/tb_mac_lane.sv`, `tb/integration/tb_ab_integration.sv`, `tb/run_sims.sh`
- `docs/plans and specs/03-lane-b-array/mac-array-spec.md` (§5, §8, §9, §12)
- `docs/plans and specs/06-physics-calibration/cell-physics-derivation.md` (§4)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

