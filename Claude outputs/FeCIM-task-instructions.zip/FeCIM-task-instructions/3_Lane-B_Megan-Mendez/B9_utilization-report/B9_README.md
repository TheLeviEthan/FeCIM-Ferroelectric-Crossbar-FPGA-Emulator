# B9 — Utilization report

| | |
|---|---|
| **Owner** | Megan Mendez |
| **Due** | Sat 28 Nov |
| **Board bucket** | Bucket 3 — Lane B |
| **Board task** | B9: Utilization report |
| **Needs first** | A5 and A7 (final fit of the release build) |
| **Unblocks** | P2 resource slide, X4 |
| **AI version** | `B9_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Every FPGA has a fixed budget of three things: logic elements (general-purpose gates and flip-flops), memory blocks and multiplier blocks. A design that needs more than the chip has simply can't be built. The utilization report says how much of each we used, where it went, and how that compares with what we predicted.

For this project the report carries real weight. Early in the semester we found that the chip has 144 multiplier *blocks*, not 288 multipliers as first assumed, and the 64-lane design didn't fit. We changed the arithmetic to 9-bit operands so two multiplies share a block. The spec then predicted 72 blocks, half the chip. This report is where that prediction meets the fitter's measurement. A match shows the redesign worked and that our estimates can be trusted for semester 2. A mismatch is something we need to understand before promising differential pairs, which double the write path.

It's also the source of the resource slide and a required course artifact.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Write:** new `docs/reports/utilization.md`.
- **Source data:** `quartus/reports/fecim.fit.summary` and the "Fitter Resource Utilization by Entity" section of `quartus/reports/fecim.fit.rpt`, from the same build as the release (A9).
- **Predictions to compare against:** `docs/plans and specs/00-plan/fecim-plan.md` §3.8; `03-lane-b-array/mac-array-spec.md` §11; `write-path-spec.md` §8; `control-fsm-spec.md` §9; `result-buffer-spec.md` §8.
- **Earlier evidence to cite:** `quartus/reports/dsp_pack_test.fit.summary` (the two-multiplies-per-block experiment).

## 3. How to build it

Suggested structure:

1. **Build identification.** Commit hash, `BUILD_ID`, Quartus version, device, `NUM_LANES`, and which non-idealities are present.
2. **Headline table.**

   | Resource | Predicted | Measured | Available | % used |
   |---|---|---|---|---|
   | Logic elements | ~18,300 | | 49,760 | |
   | M9K memory blocks | 66 | | 182 | |
   | Multiplier blocks (9-bit elements ÷ 2) | 72 | | 144 | |

3. **Per-module breakdown** from the by-entity table: one `mac_lane` (and × 64), `write_path`, `act_buffer`, `adc_quant`, `result_buffer` and `argmax_unit`, and the Lane A modules as one group. Put the spec's per-module estimate next to each.
4. **Where prediction and measurement differ, and why.** For example: Quartus merged registers, a memory was built from logic, the hash multiplies packed differently.
5. **The multiplier story** in four or five sentences: blocks versus multipliers, why 10-bit operands didn't fit, what 9-bit operands bought, and the measured count.
6. **Headroom for semester 2.** How many multiplier blocks and M9Ks are left, and what differential-pair modelling would need.

Quartus reports "Embedded Multiplier 9-bit elements". One 18×18 block is two 9-bit elements, so divide by two to get blocks.

## 4. How you know it's done

- Every "measured" number can be found in the committed report files at the stated commit.
- The per-lane numbers × 64 plus the shared modules roughly add up to the total, or the gap is explained.
- The report states whether 9×9 pairing happened, in one clear sentence.
- Zhiting has checked the build identification; the headline table is in the slides (P2).

## 5. Watch out for

- **Use the release build's reports**, not an earlier compile. Numbers move every time a module lands.
- "Logic elements" and "ALMs" are different units on other FPGA families; on MAX 10 it's logic elements. Use the unit the report uses.
- If the measured count is far below prediction, check that nothing was optimized away (for example a non-ideality whose enable is tied off) before celebrating.
- Don't round the multiplier number to hide a miss. If it's 76, say 76 and say why.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

