# AI prompt — B4: read_noise integrated into mac_lane

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **B4 — read_noise integrated into mac_lane**, owned by Megan Mendez, due Sat 21 Nov.

Implement the per-lane read-noise generator `read_noise` and integrate it into `mac_lane` and `mac_array`, then extend the lane testbench to cover it from the golden vectors.

Two properties matter more than anything else. First, with read noise disabled the lane must behave exactly as it does today: the existing clean golden vectors and the co-simulation harness are regression tests and must still pass. Second, the cycle in which the LFSR advances and the cycle in which each sample is used must match the C++ model; read `read_path.cpp`, `primitives.cpp` and `model_exact.cpp` to see which state the model uses for the first row, state that convention in a comment, and flag it if the model doesn't yet define it.

Editable files: `rtl/array/read_noise.sv`, `rtl/array/mac_lane.sv`, `rtl/array/mac_array.sv`, `tb/sv/tb_mac_lane.sv`. `model/cosim/run_l0.cpp` instantiates `mac_lane` directly, so list the exact port changes its owner (Lane C) needs to make; don't edit it.

## Where the work goes

- **Implement:** `rtl/array/read_noise.sv` (skeleton with the right ports: `noise_seed`, `reseed`, `advance`, `sigma`, `noise_q`).
- **Integrate:** `rtl/array/mac_lane.sv`. Add inputs `read_sigma`, `noise_seed`, `reseed`; instantiate `read_noise #(.LANE_ID(LANE_ID))`; change the line `assign w_n = {w_align[WEIGHT_W-1], w_align};` to add the noise.
- **Pass the ports through:** `rtl/array/mac_array.sv` already has `read_sigma`, `noise_seed` and `reseed` as unused inputs behind a lint waiver. Connect them to each lane and delete the waiver.
- **Testbench:** extend `tb/sv/tb_mac_lane.sv`; the existing 261 clean cases must still pass.
- **Golden vectors (from C2):** `tb/golden/read_noise/`.
- **Reference:** `read_noise_q()` in `model/src/read_path.cpp`, `lfsr_step()` and `lane_seed()` in `model/src/primitives.cpp`.
- **Specs:** `03-lane-b-array/mac-array-spec.md` §5 and §12 tests 3–6; `01-contract/protocol.md` §6.3, §6.6.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```systemverilog
// ---- read_noise.sv ----
localparam logic [31:0] LANE_SALT = LANE_SALT_C * LANE_ID;      // fixed per lane at build time
logic [31:0] lfsr, seed_eff;
assign seed_eff = (noise_seed ^ LANE_SALT) | 32'd1;             // never all-zero

always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)       lfsr <= seed_eff;                         // see "Watch out for"
    else if (reseed)  lfsr <= seed_eff;
    else if (advance) lfsr <= lfsr[0] ? ((lfsr >> 1) ^ LFSR_TAPS) : (lfsr >> 1);
end

// four bytes summed -> bell-shaped, centered, halved to fit 9 bits
logic [9:0]         ih_sum;
logic signed [10:0] ih_centered;
logic signed [8:0]  ih9, sigma9;
logic signed [17:0] scaled;
assign ih_sum      = lfsr[7:0] + lfsr[15:8] + lfsr[23:16] + lfsr[31:24];   // 0..1020
assign ih_centered = $signed({1'b0, ih_sum}) - 11'sd510;
assign ih9         = ih_centered >>> 1;                                     // +/-255
assign sigma9      = $signed({1'b0, sigma[7:0]});
assign scaled      = (ih9 * sigma9) >>> 9;                                  // scale = READ_SIGMA / 512
always_ff @(posedge clk)                                                    // registered in cycle N+1
    noise_q <= (scaled >  NOISE_CLAMP) ?  8'sd127 :
               (scaled < -NOISE_CLAMP) ? -8'sd127 : scaled[7:0];

// ---- mac_lane.sv, cycle N+2 ----
assign w_n = $signed({w_align[7], w_align})
           + (noise_en.read ? $signed({noise_q[7], noise_q}) : 9'sd0);     // no saturation needed
```

Timing of one row (this is the convention to confirm with Ethan):

| Cycle | What happens |
|---|---|
| N | row issued, `acc_en` high; LFSR advances on the clock edge that ends this cycle |
| N+1 | the *new* LFSR state is scaled and clamped; `noise_q` is registered at the end |
| N+2 | `w_n = w_align + noise_q`, then the multiply |

So the first row of a compute uses `lfsr_step(seed)`, not `seed` itself.

## Acceptance checks

- With `NOISE_EN.read = 0`: all 261 clean `mac_lane` golden cases still pass and `model/cosim/run_l0` is still green for lanes 0, 5 and 63.
- With read noise on: every case in `tb/golden/read_noise/` passes for lanes 0, 5 and 63.
- Reproducibility: same seed and inputs, two computes separated by a random number of idle cycles and a `reseed`, give identical results.
- Clamp: at maximum sigma, `noise_q` never leaves ±127. A permanent assertion in the testbench checks `w_n` stays within 9 bits signed.
- The lint waivers in `mac_array.sv` and `mac_lane.sv` around the noise ports are gone; lint clean.
- Zhiting re-runs the fit (A5): one more 9×9 multiply per lane, which should pair with the MAC multiply for 64 blocks total.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Agree the alignment in one sentence, in writing.** The spec says the LFSR "advances when the address is issued at N" and the noise is computed in N+1, which this sheet reads as "row N's sample comes from the state *after* that row's advance". Ethan's model has to make the same choice or every noisy result differs. Write the agreed sentence into `mac-array-spec.md` §5.5.
- **Does the LFSR advance when read noise is disabled?** The spec's code advances on `acc_en` with no enable gating, so yes. The model must do the same, or toggling the enable between computes desynchronizes them.
- **Async reset to a non-constant.** `seed_eff` depends on a register, so `lfsr <= seed_eff` under `!rst_n` forces Quartus to build asynchronous-load logic. If it warns or A7 shows recovery problems, reset to the constant `(LANE_SALT | 1)` instead. It's the same value, because `NOISE_SEED` is 0 after reset.
- **Changing `NOISE_SEED` doesn't reload the LFSRs.** Only reset and `CTRL[2]` do. The driver's `seed()` writes the register and then pulses `CTRL[2]`.
- The four bytes come from one LFSR state, so they're not independent and this isn't a true Irwin–Hall distribution. Measure the moments (B8) and report those; don't claim a textbook shape.
- Both operands of both multiplies in the lane must stay 9-bit signed, or pairing fails and the multiplier count doubles.

## Files to read first (attach or paste these if you're using a chatbot)

- `rtl/fecim_pkg.sv`
- `rtl/array/read_noise.sv`, `rtl/array/mac_lane.sv`, `rtl/array/mac_array.sv`
- `tb/sv/tb_mac_lane.sv`, `tb/golden/mac_lane/README.md`, `tb/golden/read_noise/`
- `model/include/fecim/read_path.h`, `model/src/read_path.cpp`, `model/include/fecim/primitives.h`, `model/src/primitives.cpp`, `model/src/model_exact.cpp`
- `model/cosim/run_l0.cpp`, `model/cosim/Makefile`
- `docs/plans and specs/03-lane-b-array/mac-array-spec.md` (§5, §6, §12)
- `docs/plans and specs/01-contract/protocol.md` (§6.3, §6.6)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

