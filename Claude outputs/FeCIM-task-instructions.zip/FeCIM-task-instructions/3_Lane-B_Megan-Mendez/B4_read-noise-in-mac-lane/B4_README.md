# B4 — read_noise integrated into mac_lane

| | |
|---|---|
| **Owner** | Megan Mendez |
| **Due** | Sat 21 Nov |
| **Board bucket** | Bucket 3 — Lane B |
| **Board task** | B4: `read_noise` integrated into `mac_lane` |
| **Needs first** | K4, C2 (read-noise golden vectors and the alignment decision) |
| **Unblocks** | C4 (noise-off regression), C5, A5 re-fit, A7 |
| **AI version** | `B4_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Reading a memory cell is a measurement, and measurements are noisy. Read the same cell twice and the sense circuit gives two slightly different answers. That's **cycle-to-cycle read noise**, the fourth non-ideality. Unlike quantization or D2D variation, it isn't baked into the stored weight: it's fresh on every single read. So it's the one effect that can't be precomputed when weights are written. It has to live in the lane, in the path every weight takes on its way to the multiplier.

Each lane gets its own pseudo-random generator (an LFSR, a shift register with feedback that cycles through a long scrambled sequence). Each lane's sequence is different, because real columns have independent sense amplifiers; if every column got the same noise, it would partly cancel in the comparison between columns and we'd understate the damage.

Two rules make this verifiable. The generator only advances when a row is actually being accumulated, never on idle clock cycles, so the noise doesn't depend on how long the host paused between commands. And the noise is clamped to ±127, so weight plus noise still fits in 9 bits and the multiplier still packs two to a block. Break the first rule and hardware stops matching the model. Break the second and the design stops fitting in the chip.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Implement:** `rtl/array/read_noise.sv` (skeleton with the right ports: `noise_seed`, `reseed`, `advance`, `sigma`, `noise_q`).
- **Integrate:** `rtl/array/mac_lane.sv`. Add inputs `read_sigma`, `noise_seed`, `reseed`; instantiate `read_noise #(.LANE_ID(LANE_ID))`; change the line `assign w_n = {w_align[WEIGHT_W-1], w_align};` to add the noise.
- **Pass the ports through:** `rtl/array/mac_array.sv` already has `read_sigma`, `noise_seed` and `reseed` as unused inputs behind a lint waiver. Connect them to each lane and delete the waiver.
- **Testbench:** extend `tb/sv/tb_mac_lane.sv`; the existing 261 clean cases must still pass.
- **Golden vectors (from C2):** `tb/golden/read_noise/`.
- **Reference:** `read_noise_q()` in `model/src/read_path.cpp`, `lfsr_step()` and `lane_seed()` in `model/src/primitives.cpp`.
- **Specs:** `03-lane-b-array/mac-array-spec.md` §5 and §12 tests 3–6; `01-contract/protocol.md` §6.3, §6.6.

## 3. How to build it

```systemverilog
// ---- read_noise.sv ----
localparam logic [31:0] LANE_SALT = LANE_SALT_C * LANE_ID;      // fixed per lane at build time
logic [31:0] lfsr, seed_eff;
assign seed_eff = (noise_seed ^ LANE_SALT) | 32'd1;             // never all-zero

always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)       lfsr <= seed_eff;                         // see "Watch out for"
    else if (reseed)  lfsr <= seed_eff;
    else if (advance) lfsr <= lfsr[0] ? ((lfsr >> 1) ^ LFSR_TAPS) : (lfsr >> 1);
end

// four bytes summed -> bell-shaped, centered, halved to fit 9 bits
logic [9:0]         ih_sum;
logic signed [10:0] ih_centered;
logic signed [8:0]  ih9, sigma9;
logic signed [17:0] scaled;
assign ih_sum      = lfsr[7:0] + lfsr[15:8] + lfsr[23:16] + lfsr[31:24];   // 0..1020
assign ih_centered = $signed({1'b0, ih_sum}) - 11'sd510;
assign ih9         = ih_centered >>> 1;                                     // +/-255
assign sigma9      = $signed({1'b0, sigma[7:0]});
assign scaled      = (ih9 * sigma9) >>> 9;                                  // scale = READ_SIGMA / 512
always_ff @(posedge clk)                                                    // registered in cycle N+1
    noise_q <= (scaled >  NOISE_CLAMP) ?  8'sd127 :
               (scaled < -NOISE_CLAMP) ? -8'sd127 : scaled[7:0];

// ---- mac_lane.sv, cycle N+2 ----
assign w_n = $signed({w_align[7], w_align})
           + (noise_en.read ? $signed({noise_q[7], noise_q}) : 9'sd0);     // no saturation needed
```

Timing of one row (this is the convention to confirm with Ethan):

| Cycle | What happens |
|---|---|
| N | row issued, `acc_en` high; LFSR advances on the clock edge that ends this cycle |
| N+1 | the *new* LFSR state is scaled and clamped; `noise_q` is registered at the end |
| N+2 | `w_n = w_align + noise_q`, then the multiply |

So the first row of a compute uses `lfsr_step(seed)`, not `seed` itself.

## 4. How you know it's done

- With `NOISE_EN.read = 0`: all 261 clean `mac_lane` golden cases still pass and `model/cosim/run_l0` is still green for lanes 0, 5 and 63.
- With read noise on: every case in `tb/golden/read_noise/` passes for lanes 0, 5 and 63.
- Reproducibility: same seed and inputs, two computes separated by a random number of idle cycles and a `reseed`, give identical results.
- Clamp: at maximum sigma, `noise_q` never leaves ±127. A permanent assertion in the testbench checks `w_n` stays within 9 bits signed.
- The lint waivers in `mac_array.sv` and `mac_lane.sv` around the noise ports are gone; lint clean.
- Zhiting re-runs the fit (A5): one more 9×9 multiply per lane, which should pair with the MAC multiply for 64 blocks total.

## 5. Watch out for

- **Agree the alignment in one sentence, in writing.** The spec says the LFSR "advances when the address is issued at N" and the noise is computed in N+1, which this sheet reads as "row N's sample comes from the state *after* that row's advance". Ethan's model has to make the same choice or every noisy result differs. Write the agreed sentence into `mac-array-spec.md` §5.5.
- **Does the LFSR advance when read noise is disabled?** The spec's code advances on `acc_en` with no enable gating, so yes. The model must do the same, or toggling the enable between computes desynchronizes them.
- **Async reset to a non-constant.** `seed_eff` depends on a register, so `lfsr <= seed_eff` under `!rst_n` forces Quartus to build asynchronous-load logic. If it warns or A7 shows recovery problems, reset to the constant `(LANE_SALT | 1)` instead. It's the same value, because `NOISE_SEED` is 0 after reset.
- **Changing `NOISE_SEED` doesn't reload the LFSRs.** Only reset and `CTRL[2]` do. The driver's `seed()` writes the register and then pulses `CTRL[2]`.
- The four bytes come from one LFSR state, so they're not independent and this isn't a true Irwin–Hall distribution. Measure the moments (B8) and report those; don't claim a textbook shape.
- Both operands of both multiplies in the lane must stay 9-bit signed, or pairing fails and the multiplier count doubles.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

