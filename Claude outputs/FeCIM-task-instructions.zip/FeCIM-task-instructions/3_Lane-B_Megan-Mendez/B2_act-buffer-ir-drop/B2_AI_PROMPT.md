# AI prompt — B2: act_buffer with IR-drop attenuation

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **B2 — act_buffer with IR-drop attenuation**, owned by Megan Mendez, due Fri 20 Nov.

Implement `act_buffer`: the activation memory with its broadcast register and the shared IR-drop attenuation multiply, plus a self-checking testbench.

The cycle alignment with the lane weight path is the critical property: read `mac_lane.sv` and `model/cosim/run_l0.cpp` and state, in a comment at the top of the module, the cycle in which `act_bcast` is valid relative to `act_addr`. The IR multiply has to sit inside the existing stage so `LANE_PIPE_DEPTH` stays 3. `ir_attenuate()` in the C++ model is the arithmetic reference.

Editable files: `rtl/array/act_buffer.sv`, `tb/sv/tb_act_buffer.sv` (new), `tb/run_sims.sh`, `.github/workflows/ci.yml`. If timing looks marginal, say so and describe the two-path pipeline change; don't make it.

## Where the work goes

- **Implement:** `rtl/array/act_buffer.sv` (skeleton).
- **Ports (already wired in `fecim_top`):** bulk stream in (`bulk_we`, `bulk_target`, `bulk_addr`, `bulk_data`), `noise_en` (uses `.ir`), `act_addr[6:0]` from `control_fsm`, `act_bcast[7:0]` out to `mac_array`.
- **New testbench:** `tb/sv/tb_act_buffer.sv`, in `tb/run_sims.sh` and CI.
- **Golden vectors (from C2):** `tb/golden/ir_drop/`.
- **Reference:** `ir_attenuate()` in `model/src/read_path.cpp` and its comment in `model/include/fecim/read_path.h`.
- **Specs:** `03-lane-b-array/activation-buffer-spec.md` §3, §4, §6; `mac-array-spec.md` §8 and §12 test 10.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

Timing has to match the weight path exactly (activation-buffer-spec §4):

| Cycle | Weight path (in each lane) | Activation path (here) |
|---|---|---|
| N | `seq_cnt` → weight M9K address | `act_addr` → activation M9K address |
| N+1 | M9K out → alignment register | M9K out → **IR multiply** → broadcast register |
| N+2 | add noise, multiply | `act_bcast` valid at every lane |

```systemverilog
// storage
(* ramstyle = "M9K" *) logic [7:0] amem [0:TILE_ROWS-1];     // activations, no reset
logic [7:0] atten_rom [0:TILE_ROWS-1];                       // registers, reset to 8'd255

// writes (no device effects on either: activations are drive voltages)
if (bulk_we && bulk_target == TGT_ACT)   amem[bulk_addr[6:0]]      <= bulk_data;
if (bulk_we && bulk_target == TGT_ATTEN) atten_rom[bulk_addr[6:0]] <= bulk_data;

// cycle N -> N+1 : registered memory read; remember which row it was
act_raw <= amem[act_addr];
row_d   <= act_addr;

// cycle N+1 : attenuate (combinational), then register for broadcast
logic signed [8:0]  a9, k9;                 // zero-extended: signed-positive 9-bit operands
logic signed [17:0] p;
assign a9 = {1'b0, act_raw};
assign k9 = {1'b0, atten_rom[row_d]};
assign p  = a9 * k9;                        // 9x9 signed x signed, packs in half a block
assign act_atten = noise_en.ir ? p[15:8] : act_raw;      // (act * coeff) >> 8
act_bcast <= act_atten;                     // high-fanout register: 64 loads
```

Worked example: activation 200, coefficient 230 (about 0.90): `200 × 230 = 46000`, `>> 8` gives 179.

## Acceptance checks

- Clean path: a value written with `WRITE_ACT` at row r appears on `act_bcast` exactly two cycles after `act_addr = r`, matching what `mac_lane` and `model/cosim/run_l0.cpp` assume.
- IR on: every case in `tb/golden/ir_drop/` passes.
- IR off: `act_bcast` equals the stored activation regardless of what's in `atten_rom`.
- `atten_rom` resets to all 255, and a `WRITE_ATTEN` followed by a compute uses the new values.
- Broadcast integrity: with all weights set to 1, every column's result is identical (run this in B7).
- Lint waivers removed; lint clean.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Reset coefficients aren't the identity.** 255 means 255/256, so "IR on with the reset table" is slightly different from "IR off". The identity is `NOISE_EN.ir = 0`. The model does the same.
- **The M9K has no reset.** Activations from an earlier, longer vector stay in memory. That's by design; the driver always writes the full vector.
- **Timing.** M9K output → 9×9 multiply → register in one cycle is a real path. If A7 shows it failing, the fix is a pipeline stage on **both** the activation and weight paths with `LANE_PIPE_DEPTH = 4`. Adding a stage here alone misaligns every row.
- Both multiplier operands must be signed (zero-extended), or Quartus won't pack this multiply with another one.
- `bulk_addr` is 16 bits; only the low 7 are the row. Decide what an out-of-range row does (the parser should have rejected it) and keep it consistent with the model.

## Files to read first (attach or paste these if you're using a chatbot)

- `rtl/fecim_pkg.sv`, `rtl/fecim_top.sv`
- `rtl/array/act_buffer.sv`, `rtl/array/mac_lane.sv`
- `model/include/fecim/read_path.h`, `model/src/read_path.cpp`, `model/cosim/run_l0.cpp`
- `tb/golden/ir_drop/`, `tb/sv/tb_mac_lane.sv`, `tb/run_sims.sh`
- `docs/plans and specs/03-lane-b-array/activation-buffer-spec.md`
- `docs/plans and specs/03-lane-b-array/mac-array-spec.md` (§8)
- `docs/plans and specs/01-contract/protocol.md` (§4.2, §4.2b)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

