# B2 — act_buffer with IR-drop attenuation

| | |
|---|---|
| **Owner** | Megan Mendez |
| **Due** | Fri 20 Nov |
| **Board bucket** | Bucket 3 — Lane B |
| **Board task** | B2: `act_buffer` + IR attenuation (`atten_rom`, `WRITE_ATTEN`) |
| **Needs first** | K4, C2 (IR golden vectors, due Wed 18) |
| **Unblocks** | B7, C4, C5, A5 |
| **AI version** | `B2_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

In a crossbar, the input vector is applied as voltages on the row wires. `act_buffer` is our version of those row drivers: it stores the 128 input values (activations) and, during a compute, hands one to all 64 lanes each cycle, in step with the weights the lanes are reading.

It also models **IR drop**, our fifth non-ideality. Real wires have resistance. Current flowing along a wire loses voltage on the way (V = I × R), so a cell far from the driver sees a slightly weaker signal than a cell near it. We model that as a per-row scale factor a little below 1.

The neat part is where the multiply goes. Scaling each product in each lane would cost 64 multipliers. But the scale factor depends only on the row, and so does the activation, so scaling the activation once *before* it's broadcast gives exactly the same sums: Σ α·(w·a) = Σ w·(α·a). One multiplier instead of sixty-four. On a chip where multipliers are the scarcest resource, that's the difference between fitting and not.

The report has to say honestly that this is an approximation of the physics. A rigorous IR-drop model solves the whole resistor network; ours is a fixed attenuation per row.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Implement:** `rtl/array/act_buffer.sv` (skeleton).
- **Ports (already wired in `fecim_top`):** bulk stream in (`bulk_we`, `bulk_target`, `bulk_addr`, `bulk_data`), `noise_en` (uses `.ir`), `act_addr[6:0]` from `control_fsm`, `act_bcast[7:0]` out to `mac_array`.
- **New testbench:** `tb/sv/tb_act_buffer.sv`, in `tb/run_sims.sh` and CI.
- **Golden vectors (from C2):** `tb/golden/ir_drop/`.
- **Reference:** `ir_attenuate()` in `model/src/read_path.cpp` and its comment in `model/include/fecim/read_path.h`.
- **Specs:** `03-lane-b-array/activation-buffer-spec.md` §3, §4, §6; `mac-array-spec.md` §8 and §12 test 10.

## 3. How to build it

Timing has to match the weight path exactly (activation-buffer-spec §4):

| Cycle | Weight path (in each lane) | Activation path (here) |
|---|---|---|
| N | `seq_cnt` → weight M9K address | `act_addr` → activation M9K address |
| N+1 | M9K out → alignment register | M9K out → **IR multiply** → broadcast register |
| N+2 | add noise, multiply | `act_bcast` valid at every lane |

```systemverilog
// storage
(* ramstyle = "M9K" *) logic [7:0] amem [0:TILE_ROWS-1];     // activations, no reset
logic [7:0] atten_rom [0:TILE_ROWS-1];                       // registers, reset to 8'd255

// writes (no device effects on either: activations are drive voltages)
if (bulk_we && bulk_target == TGT_ACT)   amem[bulk_addr[6:0]]      <= bulk_data;
if (bulk_we && bulk_target == TGT_ATTEN) atten_rom[bulk_addr[6:0]] <= bulk_data;

// cycle N -> N+1 : registered memory read; remember which row it was
act_raw <= amem[act_addr];
row_d   <= act_addr;

// cycle N+1 : attenuate (combinational), then register for broadcast
logic signed [8:0]  a9, k9;                 // zero-extended: signed-positive 9-bit operands
logic signed [17:0] p;
assign a9 = {1'b0, act_raw};
assign k9 = {1'b0, atten_rom[row_d]};
assign p  = a9 * k9;                        // 9x9 signed x signed, packs in half a block
assign act_atten = noise_en.ir ? p[15:8] : act_raw;      // (act * coeff) >> 8
act_bcast <= act_atten;                     // high-fanout register: 64 loads
```

Worked example: activation 200, coefficient 230 (about 0.90): `200 × 230 = 46000`, `>> 8` gives 179.

## 4. How you know it's done

- Clean path: a value written with `WRITE_ACT` at row r appears on `act_bcast` exactly two cycles after `act_addr = r`, matching what `mac_lane` and `model/cosim/run_l0.cpp` assume.
- IR on: every case in `tb/golden/ir_drop/` passes.
- IR off: `act_bcast` equals the stored activation regardless of what's in `atten_rom`.
- `atten_rom` resets to all 255, and a `WRITE_ATTEN` followed by a compute uses the new values.
- Broadcast integrity: with all weights set to 1, every column's result is identical (run this in B7).
- Lint waivers removed; lint clean.

## 5. Watch out for

- **Reset coefficients aren't the identity.** 255 means 255/256, so "IR on with the reset table" is slightly different from "IR off". The identity is `NOISE_EN.ir = 0`. The model does the same.
- **The M9K has no reset.** Activations from an earlier, longer vector stay in memory. That's by design; the driver always writes the full vector.
- **Timing.** M9K output → 9×9 multiply → register in one cycle is a real path. If A7 shows it failing, the fix is a pipeline stage on **both** the activation and weight paths with `LANE_PIPE_DEPTH = 4`. Adding a stage here alone misaligns every row.
- Both multiplier operands must be signed (zero-extended), or Quartus won't pack this multiply with another one.
- `bulk_addr` is 16 bits; only the low 7 are the row. Decide what an out-of-range row does (the parser should have rejected it) and keep it consistent with the model.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

