# B3 — write_path stages 2 and 3: D2D variation and stuck-at faults

| | |
|---|---|
| **Owner** | Megan Mendez |
| **Due** | Sat 21 Nov |
| **Board bucket** | Bucket 3 — Lane B |
| **Board task** | B3: `write_path` stages 2–3 — D2D + stuck-at |
| **Needs first** | B1, C1 (golden vectors) |
| **Unblocks** | C5 (L1/L2), A5 re-fit, D8 sweeps |
| **AI version** | `B3_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

No two memory cells come out of a fab identical. Program the same value into two cells and they land on slightly different conductances. That's **device-to-device (D2D) variation**. And a small fraction of cells don't respond at all: they're **stuck**, either dead at zero or pinned at maximum. These are the second and third non-idealities, and for real ferroelectric devices they're often what limits accuracy.

Both are *permanent properties of a cell*. The same cell must misbehave the same way every time it's written, the way a physical defect would. A random number generator can't give us that. Instead we compute a **hash of the cell's address**: a fixed, scrambled number that depends only on which cell it is and on a global seed. No storage needed, perfectly repeatable, and writing a new seed is like swapping in a different physical chip.

The order of the three write stages mirrors real programming: the circuit aims for a level (quantize), the cell misses by a bit (D2D), and a dead cell ignores the whole thing (stuck-at overrides).

Getting one detail wrong here is catastrophic: if the variation add wraps around instead of saturating, a weight of +127 plus a small positive error becomes −128. That flips a strong positive weight to a strong negative one, which no real device would do.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Implement:** stages 2 and 3 inside `rtl/write/write_path.sv` (the pass-through stages left by B1).
- **Hash function:** `fecim_pkg::cell_hash16(addr, seed)`, already in the package. Seeds: `SEED_D2D`, `SEED_STUCK`.
- **Testbench:** extend `tb/sv/tb_write_path.sv`.
- **Golden vectors (from C1):** `tb/golden/write_path/`, including an exhaustive hash table.
- **Reference:** `d2d_offset()` and `apply_stuck()` in `model/src/write_path.cpp`; signatures and rules in `model/include/fecim/write_path.h`.
- **Spec:** `03-lane-b-array/write-path-spec.md` §5, §6, §9.

## 3. How to build it

```systemverilog
// The global cell address is the bulk address itself: col*128 + row.
assign cell_addr = {2'b00, addr[13:0]};
assign h_d2d     = cell_hash16(cell_addr, noise_seed[15:0] ^ SEED_D2D);
assign h_stuck   = cell_hash16(cell_addr, noise_seed[15:0] ^ SEED_STUCK);

// ---- stage 2: D2D. Two hash bytes summed -> triangular distribution, +/-255
logic [8:0]         ih_sum;
logic signed [8:0]  ih9, sigma9;
logic signed [17:0] d2d_scaled;
logic signed [10:0] w_sum;
assign ih_sum     = h_d2d[7:0] + h_d2d[15:8];                 // 0..510
assign ih9        = $signed({1'b0, ih_sum}) - 9'sd255;        // -255..+255
assign sigma9     = $signed({1'b0, d2d_sigma[7:0]});          // signed-positive
assign d2d_scaled = (ih9 * sigma9) >>> 8;                     // scale = D2D_SIGMA / 256
assign w_sum      = $signed({{3{w_q[7]}}, w_q}) + d2d_scaled[10:0];
assign w_var      = (w_sum >  127) ?  8'sd127 :
                    (w_sum < -128) ? -8'sd128 : w_sum[7:0];   // SATURATE, never wrap
assign w2         = noise_en.d2d ? w_var : w_q;

// ---- stage 3: stuck-at. Overrides everything before it.
assign stuck_hit = (h_stuck < stuck_rate[15:0]);              // rate = stuck_rate / 65536
assign w_rail    = h_d2d[15] ? -8'sd127 : 8'sd127;            // sign from the D2D hash
assign w3        = (noise_en.stuck && stuck_hit)
                 ? (stuck_rate[16] ? w_rail : 8'sd0)          // mode 1 = rail, mode 0 = zero
                 : w2;
```

Spread the hash across pipeline stages: each `cell_hash16` contains two 16×16 multiplies. The write path has thousands of idle cycles between UART bytes, so pipeline generously, but keep the total latency equal for every enable combination.

Test the hash first, alone. If the RTL hash and the C++ hash differ in one bit, nothing after it can match.

## 4. How you know it's done

- Hash equivalence: all 65,536 addresses × 8 seeds match the C++ `cell_hash16` (exhaustive, from the golden file).
- All D2D, stuck-at-zero, stuck-at-rail and combined cases in `tb/golden/write_path/` pass.
- Saturation: weights of ±127 with the largest positive and negative offsets never change sign.
- Determinism: the same cell and value written 100 times gives one result; a new `NOISE_SEED` changes it.
- Monotone faults: with the seed fixed, raising `stuck_rate` only adds stuck cells, never removes one.
- Latency unchanged from B1 for every `NOISE_EN` combination.
- After merging, Zhiting re-runs the fit (A5): this adds four multiplier blocks.

## 5. Watch out for

- **Which way the rail sign goes** (`h_d2d[15]` set means negative or positive) isn't stated in the spec. The sketch above is a guess. Read `apply_stuck()` in the model and copy its choice; the golden vectors will catch a mismatch.
- **The rail sign uses the D2D hash even when D2D is disabled.** That's intentional: every bit of the stuck hash is used up by the threshold compare.
- **Triangular, not Gaussian.** Two bytes are summed because the 16-bit hash only has two. This was a deliberate trade to save multiplier blocks, and the report discloses it. Keep the comment that says so.
- **`noise_seed` is sampled when a weight is written.** Changing the seed later doesn't re-randomize weights already stored. The host has to reload weights after a reseed; tell Natalie.
- Saturation limits are +127 and −128 for D2D (as in the model header), while stuck-at-rail uses ±127.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

