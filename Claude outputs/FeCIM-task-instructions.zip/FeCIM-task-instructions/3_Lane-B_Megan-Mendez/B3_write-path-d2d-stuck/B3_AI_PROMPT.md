# AI prompt — B3: write_path stages 2 and 3: D2D variation and stuck-at faults

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **B3 — write_path stages 2 and 3: D2D variation and stuck-at faults**, owned by Megan Mendez, due Sat 21 Nov.

Fill in stages 2 and 3 of `write_path`: device-to-device variation and stuck-at faults, both derived from `cell_hash16` of the global cell address, and extend the testbench to cover them from the golden vectors.

The C++ functions `d2d_offset()` and `apply_stuck()` are the reference; match them bit for bit, including the sign convention for stuck-at-rail and the saturation limits. Verify the hash against the exhaustive golden table before anything else and report that result separately. Keep the pipeline latency identical across every enable combination, and keep every multiply's operand widths as the spec gives them, because the multiplier-block budget depends on it.

Editable files: `rtl/write/write_path.sv`, `tb/sv/tb_write_path.sv`. In your reply, list the pipeline stage in which each operation happens and the multiplier count you expect Quartus to infer.

## Where the work goes

- **Implement:** stages 2 and 3 inside `rtl/write/write_path.sv` (the pass-through stages left by B1).
- **Hash function:** `fecim_pkg::cell_hash16(addr, seed)`, already in the package. Seeds: `SEED_D2D`, `SEED_STUCK`.
- **Testbench:** extend `tb/sv/tb_write_path.sv`.
- **Golden vectors (from C1):** `tb/golden/write_path/`, including an exhaustive hash table.
- **Reference:** `d2d_offset()` and `apply_stuck()` in `model/src/write_path.cpp`; signatures and rules in `model/include/fecim/write_path.h`.
- **Spec:** `03-lane-b-array/write-path-spec.md` §5, §6, §9.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```systemverilog
// The global cell address is the bulk address itself: col*128 + row.
assign cell_addr = {2'b00, addr[13:0]};
assign h_d2d     = cell_hash16(cell_addr, noise_seed[15:0] ^ SEED_D2D);
assign h_stuck   = cell_hash16(cell_addr, noise_seed[15:0] ^ SEED_STUCK);

// ---- stage 2: D2D. Two hash bytes summed -> triangular distribution, +/-255
logic [8:0]         ih_sum;
logic signed [8:0]  ih9, sigma9;
logic signed [17:0] d2d_scaled;
logic signed [10:0] w_sum;
assign ih_sum     = h_d2d[7:0] + h_d2d[15:8];                 // 0..510
assign ih9        = $signed({1'b0, ih_sum}) - 9'sd255;        // -255..+255
assign sigma9     = $signed({1'b0, d2d_sigma[7:0]});          // signed-positive
assign d2d_scaled = (ih9 * sigma9) >>> 8;                     // scale = D2D_SIGMA / 256
assign w_sum      = $signed({{3{w_q[7]}}, w_q}) + d2d_scaled[10:0];
assign w_var      = (w_sum >  127) ?  8'sd127 :
                    (w_sum < -128) ? -8'sd128 : w_sum[7:0];   // SATURATE, never wrap
assign w2         = noise_en.d2d ? w_var : w_q;

// ---- stage 3: stuck-at. Overrides everything before it.
assign stuck_hit = (h_stuck < stuck_rate[15:0]);              // rate = stuck_rate / 65536
assign w_rail    = h_d2d[15] ? -8'sd127 : 8'sd127;            // sign from the D2D hash
assign w3        = (noise_en.stuck && stuck_hit)
                 ? (stuck_rate[16] ? w_rail : 8'sd0)          // mode 1 = rail, mode 0 = zero
                 : w2;
```

Spread the hash across pipeline stages: each `cell_hash16` contains two 16×16 multiplies. The write path has thousands of idle cycles between UART bytes, so pipeline generously, but keep the total latency equal for every enable combination.

Test the hash first, alone. If the RTL hash and the C++ hash differ in one bit, nothing after it can match.

## Acceptance checks

- Hash equivalence: all 65,536 addresses × 8 seeds match the C++ `cell_hash16` (exhaustive, from the golden file).
- All D2D, stuck-at-zero, stuck-at-rail and combined cases in `tb/golden/write_path/` pass.
- Saturation: weights of ±127 with the largest positive and negative offsets never change sign.
- Determinism: the same cell and value written 100 times gives one result; a new `NOISE_SEED` changes it.
- Monotone faults: with the seed fixed, raising `stuck_rate` only adds stuck cells, never removes one.
- Latency unchanged from B1 for every `NOISE_EN` combination.
- After merging, Zhiting re-runs the fit (A5): this adds four multiplier blocks.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Which way the rail sign goes** (`h_d2d[15]` set means negative or positive) isn't stated in the spec. The sketch above is a guess. Read `apply_stuck()` in the model and copy its choice; the golden vectors will catch a mismatch.
- **The rail sign uses the D2D hash even when D2D is disabled.** That's intentional: every bit of the stuck hash is used up by the threshold compare.
- **Triangular, not Gaussian.** Two bytes are summed because the 16-bit hash only has two. This was a deliberate trade to save multiplier blocks, and the report discloses it. Keep the comment that says so.
- **`noise_seed` is sampled when a weight is written.** Changing the seed later doesn't re-randomize weights already stored. The host has to reload weights after a reseed; tell Natalie.
- Saturation limits are +127 and −128 for D2D (as in the model header), while stuck-at-rail uses ±127.

## Files to read first (attach or paste these if you're using a chatbot)

- `rtl/fecim_pkg.sv`
- `rtl/write/write_path.sv` (after B1), `tb/sv/tb_write_path.sv`
- `model/include/fecim/write_path.h`, `model/src/write_path.cpp`, `model/src/primitives.cpp`
- `tb/golden/write_path/`
- `docs/plans and specs/03-lane-b-array/write-path-spec.md`
- `docs/plans and specs/01-contract/protocol.md` (§6.3, §6.6)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

