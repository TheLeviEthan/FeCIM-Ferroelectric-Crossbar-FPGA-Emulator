# AI prompt — B6: result_buffer with results_valid and result_seq

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **B6 — result_buffer with results_valid and result_seq**, owned by Megan Mendez, due Fri 20 Nov.

Implement `result_buffer`: an inferred 128 × 32 simple dual-port memory with a registered read, the `results_valid` flag, and a new 8-bit `result_seq` counter output, plus a self-checking testbench.

The `result_seq` port doesn't exist in the skeleton; add it, and describe the wiring change needed in `fecim_top.sv` and `config_regs.sv` (both owned by Lane A) so that `STATUS[15:8]` reports it. Write the memory so Quartus infers an M9K block: no reset on the array, synchronous write, synchronous read. Editable files: `rtl/result/result_buffer.sv`, `tb/sv/tb_result_buffer.sv` (new), `tb/run_sims.sh`, `.github/workflows/ci.yml`.

## Where the work goes

- **Implement:** `rtl/result/result_buffer.sv` (skeleton).
- **Port change (K4):** add `output logic [7:0] result_seq` and connect it through `fecim_top.sv` to `config_regs`, where `STATUS[15:8]` is currently hard-coded to zero.
- **Wired today:** `we` = `drain_we`, `waddr` = `drain_addr`, `wdata` = `adc_out`, `raddr` / `rdata` to `readout_ser`, plus `clear_results`, `run_start`, `compute_done`, `results_valid`.
- **New testbench:** `tb/sv/tb_result_buffer.sv`, in `tb/run_sims.sh` and CI.
- **Specs:** `03-lane-b-array/result-buffer-spec.md` §2–4 and §9 tests 1, 2, 7, 8; `01-contract/protocol.md` §6.4.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```systemverilog
// 128 x 32 simple dual-port memory -> one M9K
(* ramstyle = "M9K" *) logic [ACC_W-1:0] rmem [0:TILE_COLS-1];

always_ff @(posedge clk) begin
    if (we) rmem[waddr] <= wdata;        // drain: one word per cycle
    rdata <= rmem[raddr];                // registered read, one cycle of latency
end

always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        results_valid <= 1'b0;
        result_seq    <= '0;
    end else begin
        if (clear_results || run_start) results_valid <= 1'b0;
        else if (compute_done)          results_valid <= 1'b1;
        if (compute_done)               result_seq    <= result_seq + 8'd1;   // wraps at 255
    end
end
```

Write addressing comes from the FSM as `{pass, drain_cnt}`: pass 0 fills addresses 0 to 63 and pass 1 fills 64 to 127. The buffer just stores what it's given, so its own testbench should write a distinct value to every address and read all 128 back.

Results persist until the next compute; nothing clears the memory itself.

## Acceptance checks

- 128 distinct values written through the write port read back from the right addresses.
- A two-pass sequence: pass 1 lands in 64–127 and doesn't disturb 0–63.
- `results_valid` goes low on `run_start` and on `clear_results`, and high on `compute_done`.
- `result_seq` advances by exactly one per `compute_done`, doesn't change on a read, and wraps from 255 to 0.
- `STATUS[15:8]` read through `GET_CONFIG` shows the counter (check with Zhiting once wired).
- The memory is inferred as one M9K in the fit report.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Does `CTRL[1]` (clear results) zero the memory?** The spec leaves it open (§10.4). This sheet clears only `results_valid`. Ethan's model has to behave the same way for a `READ_RESULT` after a clear, so tell him what you ship.
- **The drain-ordering question in A1** (whether the chain shifts in the same cycle as the write) decides whether column k lands at address k. Your buffer can't detect that by itself; it's tested in B7 with the real FSM and lanes.
- Keep the data width at `ACC_W` (32). The M9K's native 256×32 mode makes it free, and 24 bits overflows once read noise is on.
- The read port is shared with the display (see A3), so don't add an output register beyond the one-cycle memory read without telling Zhiting.

## Files to read first (attach or paste these if you're using a chatbot)

- `rtl/fecim_pkg.sv`, `rtl/fecim_top.sv`
- `rtl/result/result_buffer.sv`, `rtl/control/config_regs.sv`
- `rtl/array/mac_lane.sv` (an example of the M9K inference style used in this repo)
- `tb/sv/tb_mac_lane.sv`, `tb/run_sims.sh`
- `docs/plans and specs/03-lane-b-array/result-buffer-spec.md`
- `docs/plans and specs/01-contract/protocol.md` (§6.4)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

