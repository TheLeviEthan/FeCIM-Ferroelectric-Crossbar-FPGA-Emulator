# B6 — result_buffer with results_valid and result_seq

| | |
|---|---|
| **Owner** | Megan Mendez |
| **Due** | Fri 20 Nov |
| **Board bucket** | Bucket 3 — Lane B |
| **Board task** | B6: `result_buffer` |
| **Needs first** | K4 (adds the `result_seq` output), A1 (drain strobes) |
| **Unblocks** | A3 re-test, B7, C5, D2 (sequence check) |
| **AI version** | `B6_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

When a compute finishes, the 128 column sums exist for a moment as they shift out of the lanes. `result_buffer` catches them and holds them, so the host can read them whenever it likes, and read them again if a reply gets lost on the serial link.

It also keeps two small pieces of bookkeeping that protect the integrity of every experiment:

- **`results_valid`** says whether the buffer holds results from a finished compute or stale data.
- **`result_seq`** is a counter that goes up by one on every finished compute. Picture a lost reply: the host asked for a compute, the board did it, the "done" message was corrupted, and the host retries. Without a counter, the host can't tell whether the compute ran once, twice, or not at all, and might read results that belong to the previous input. That would be one wrong answer in thousands, invisible in testing, and enough to make a sweep irreproducible. With the counter, the driver checks that it advanced by exactly one.

It's a small module, but it's the last stop before data leaves the chip, so an off-by-one here silently shifts every column.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Implement:** `rtl/result/result_buffer.sv` (skeleton).
- **Port change (K4):** add `output logic [7:0] result_seq` and connect it through `fecim_top.sv` to `config_regs`, where `STATUS[15:8]` is currently hard-coded to zero.
- **Wired today:** `we` = `drain_we`, `waddr` = `drain_addr`, `wdata` = `adc_out`, `raddr` / `rdata` to `readout_ser`, plus `clear_results`, `run_start`, `compute_done`, `results_valid`.
- **New testbench:** `tb/sv/tb_result_buffer.sv`, in `tb/run_sims.sh` and CI.
- **Specs:** `03-lane-b-array/result-buffer-spec.md` §2–4 and §9 tests 1, 2, 7, 8; `01-contract/protocol.md` §6.4.

## 3. How to build it

```systemverilog
// 128 x 32 simple dual-port memory -> one M9K
(* ramstyle = "M9K" *) logic [ACC_W-1:0] rmem [0:TILE_COLS-1];

always_ff @(posedge clk) begin
    if (we) rmem[waddr] <= wdata;        // drain: one word per cycle
    rdata <= rmem[raddr];                // registered read, one cycle of latency
end

always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        results_valid <= 1'b0;
        result_seq    <= '0;
    end else begin
        if (clear_results || run_start) results_valid <= 1'b0;
        else if (compute_done)          results_valid <= 1'b1;
        if (compute_done)               result_seq    <= result_seq + 8'd1;   // wraps at 255
    end
end
```

Write addressing comes from the FSM as `{pass, drain_cnt}`: pass 0 fills addresses 0 to 63 and pass 1 fills 64 to 127. The buffer just stores what it's given, so its own testbench should write a distinct value to every address and read all 128 back.

Results persist until the next compute; nothing clears the memory itself.

## 4. How you know it's done

- 128 distinct values written through the write port read back from the right addresses.
- A two-pass sequence: pass 1 lands in 64–127 and doesn't disturb 0–63.
- `results_valid` goes low on `run_start` and on `clear_results`, and high on `compute_done`.
- `result_seq` advances by exactly one per `compute_done`, doesn't change on a read, and wraps from 255 to 0.
- `STATUS[15:8]` read through `GET_CONFIG` shows the counter (check with Zhiting once wired).
- The memory is inferred as one M9K in the fit report.

## 5. Watch out for

- **Does `CTRL[1]` (clear results) zero the memory?** The spec leaves it open (§10.4). This sheet clears only `results_valid`. Ethan's model has to behave the same way for a `READ_RESULT` after a clear, so tell him what you ship.
- **The drain-ordering question in A1** (whether the chain shifts in the same cycle as the write) decides whether column k lands at address k. Your buffer can't detect that by itself; it's tested in B7 with the real FSM and lanes.
- Keep the data width at `ACC_W` (32). The M9K's native 256×32 mode makes it free, and 24 bits overflows once read noise is on.
- The read port is shared with the display (see A3), so don't add an output register beyond the one-cycle memory read without telling Zhiting.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

