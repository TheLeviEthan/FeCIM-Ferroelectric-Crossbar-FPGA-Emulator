# B7 — tb_ab_integration on the real modules

| | |
|---|---|
| **Owner** | Megan Mendez (Zhiting Li reviews) |
| **Due** | Mon 23 Nov |
| **Board bucket** | Bucket 3 — Lane B |
| **Board task** | B7: `tb_ab_integration` on real modules |
| **Needs first** | A1, B1, B2, B4, B5, B6 merged; A4 if available |
| **Unblocks** | C5 confidence, G3 |
| **AI version** | `B7_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Lane A builds the part that says *when* things happen. Lane B builds the part that does the arithmetic. Each can pass its own tests and the two can still fail to work together, because each side tested against its own idea of the other. Off-by-one-cycle mistakes at a boundary like this are the classic failure of a team project: a seam nobody owns is a seam nobody tests.

This testbench is the contract between the two lanes. Until now it has exercised stand-in stubs for both sides. This task swaps the stubs for the real sequencer, the real write path, the real lanes and the real result buffer, and runs complete matrix-vector multiplies through them.

The tests are chosen to localize bugs, not just detect them. A one-hot input with an identity-like matrix tells you *which* row or column is shifted. A matrix whose only non-zero rows are the last three tells you whether the sequencer waited long enough for the pipeline. Random data would only tell you that something, somewhere, is wrong.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Edit:** `tb/integration/tb_ab_integration.sv`. Keep `lane_a_stub.sv` and `lane_b_stub.sv` in the folder for reference.
- **New target in `tb/run_sims.sh`:** for example `tb_ab_real`, whose source list is the package plus `rtl/control/control_fsm.sv`, `rtl/write/write_path.sv`, `rtl/array/act_buffer.sv`, `rtl/array/mac_array.sv`, `rtl/array/mac_lane.sv`, `rtl/array/read_noise.sv`, `rtl/array/adc_quant.sv`, `rtl/result/result_buffer.sv`, `rtl/result/argmax_unit.sv` and the testbench. Add it to the CI `sim` job.
- **Drive it at the seam:** the testbench plays the parser and config registers (drives `bulk_*`, `start_compute`, and the config values) and reads the result buffer's read port.
- **Specs:** `02-lane-a-interface/top-level-spec.md` §7.1–7.2; `control-fsm-spec.md` §10 tests 1–6; `03-lane-b-array/result-buffer-spec.md` §9 tests 1–2.

## 3. How to build it

```text
task write_weight(row, col, w):   pulse bulk_we with target=TGT_WEIGHTS, addr = col*128 + row
task write_act(row, a):           pulse bulk_we with target=TGT_ACT,     addr = row
task compute():                   pulse start_compute; wait for compute_done
task read_result(col) -> value:   set raddr = col; wait one cycle; sample rdata

reference (clean path, in the testbench):
    expected[c] = sum over r < active_rows of  signed(w[r][c]) * unsigned(a[r])
```

Tests, in this order (each one narrows down a different bug):

1. **One-hot.** `w[r][c] = 1` when `r == c`, else 0. Activation is 0 everywhere except one row `k` = 200. Expect column `k` = 200 and every other column 0. Sweep `k` across all 128 rows.
2. **Pipeline drain.** Only rows 125, 126 and 127 are non-zero. If the FSM leaves `ACC` early, results come out zero or short.
3. **Drain ordering.** Activation all 1; column `c` has a single weight equal to `c − 64`. Expect `result[c] = c − 64`. A mirrored or shifted chain is obvious at a glance.
4. **Multi-pass.** Check that pass 1 (columns 64–127) didn't overwrite pass 0.
5. **Tile sizes.** `TILE_CFG` = 8×8, 32×32, 48×48, 64×64, 128×128; only `active_rows` rows contribute.
6. **Random, clean.** Random weights and activations, 50 runs, against the reference loop.
7. **One all-non-idealities run** against expected values exported from the C++ model (ask Ethan for a hex file from `model_exact`).

## 4. How you know it's done

- Tests 1–6 pass on the real modules with no stub in the default target.
- Test 7 matches the model's exported results word for word.
- The answer to the `shift_en` question from A1 is settled by test 3 and the spec sentence is corrected.
- The target runs in `tb/run_sims.sh` and in CI.
- Zhiting has reviewed and approved the PR.

## 5. Watch out for

- **This is where the A/B timing assumptions meet.** Expect the first run to fail. Use test 1 to find which side is off by a cycle before touching either module.
- A bug found here is fixed by the owner of the module it's in. If it's in `control_fsm`, describe it to Zhiting; don't patch it in the testbench.
- `top-level-spec.md` calls this file `tb/sv/tb_seam.sv`. The repo's name, `tb/integration/tb_ab_integration.sv`, is the one to keep; fix the spec reference.
- Weights must be written before `start_compute`, and the write path has a four-cycle latency: wait for the last `lane_we` before starting.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

