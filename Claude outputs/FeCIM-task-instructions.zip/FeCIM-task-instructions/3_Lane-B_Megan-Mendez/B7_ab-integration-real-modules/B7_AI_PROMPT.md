# AI prompt — B7: tb_ab_integration on the real modules

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **B7 — tb_ab_integration on the real modules**, owned by Megan Mendez (Zhiting Li reviews), due Mon 23 Nov.

Convert the A/B integration testbench from stubs to the real RTL modules and add the directed tests that localize seam bugs.

The testbench should instantiate the real `control_fsm`, `write_path`, `act_buffer`, `mac_array`, `adc_quant`, `result_buffer` and `argmax_unit`, drive them the way `packet_parser` and `config_regs` would, and check complete matrix-vector products against a reference loop written in the testbench. Order the tests so that the first failure identifies whether the fault is in sequencing, address decode, pipeline depth or drain order, and make each failure message name the row, column, expected and actual values.

Editable files: `tb/integration/tb_ab_integration.sv`, `tb/run_sims.sh`, `.github/workflows/ci.yml`. Don't modify any file under `rtl/`: when the testbench exposes an RTL bug, report which module and line you believe is wrong and why.

## Where the work goes

- **Edit:** `tb/integration/tb_ab_integration.sv`. Keep `lane_a_stub.sv` and `lane_b_stub.sv` in the folder for reference.
- **New target in `tb/run_sims.sh`:** for example `tb_ab_real`, whose source list is the package plus `rtl/control/control_fsm.sv`, `rtl/write/write_path.sv`, `rtl/array/act_buffer.sv`, `rtl/array/mac_array.sv`, `rtl/array/mac_lane.sv`, `rtl/array/read_noise.sv`, `rtl/array/adc_quant.sv`, `rtl/result/result_buffer.sv`, `rtl/result/argmax_unit.sv` and the testbench. Add it to the CI `sim` job.
- **Drive it at the seam:** the testbench plays the parser and config registers (drives `bulk_*`, `start_compute`, and the config values) and reads the result buffer's read port.
- **Specs:** `02-lane-a-interface/top-level-spec.md` §7.1–7.2; `control-fsm-spec.md` §10 tests 1–6; `03-lane-b-array/result-buffer-spec.md` §9 tests 1–2.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```text
task write_weight(row, col, w):   pulse bulk_we with target=TGT_WEIGHTS, addr = col*128 + row
task write_act(row, a):           pulse bulk_we with target=TGT_ACT,     addr = row
task compute():                   pulse start_compute; wait for compute_done
task read_result(col) -> value:   set raddr = col; wait one cycle; sample rdata

reference (clean path, in the testbench):
    expected[c] = sum over r < active_rows of  signed(w[r][c]) * unsigned(a[r])
```

Tests, in this order (each one narrows down a different bug):

1. **One-hot.** `w[r][c] = 1` when `r == c`, else 0. Activation is 0 everywhere except one row `k` = 200. Expect column `k` = 200 and every other column 0. Sweep `k` across all 128 rows.
2. **Pipeline drain.** Only rows 125, 126 and 127 are non-zero. If the FSM leaves `ACC` early, results come out zero or short.
3. **Drain ordering.** Activation all 1; column `c` has a single weight equal to `c − 64`. Expect `result[c] = c − 64`. A mirrored or shifted chain is obvious at a glance.
4. **Multi-pass.** Check that pass 1 (columns 64–127) didn't overwrite pass 0.
5. **Tile sizes.** `TILE_CFG` = 8×8, 32×32, 48×48, 64×64, 128×128; only `active_rows` rows contribute.
6. **Random, clean.** Random weights and activations, 50 runs, against the reference loop.
7. **One all-non-idealities run** against expected values exported from the C++ model (ask Ethan for a hex file from `model_exact`).

## Acceptance checks

- Tests 1–6 pass on the real modules with no stub in the default target.
- Test 7 matches the model's exported results word for word.
- The answer to the `shift_en` question from A1 is settled by test 3 and the spec sentence is corrected.
- The target runs in `tb/run_sims.sh` and in CI.
- Zhiting has reviewed and approved the PR.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **This is where the A/B timing assumptions meet.** Expect the first run to fail. Use test 1 to find which side is off by a cycle before touching either module.
- A bug found here is fixed by the owner of the module it's in. If it's in `control_fsm`, describe it to Zhiting; don't patch it in the testbench.
- `top-level-spec.md` calls this file `tb/sv/tb_seam.sv`. The repo's name, `tb/integration/tb_ab_integration.sv`, is the one to keep; fix the spec reference.
- Weights must be written before `start_compute`, and the write path has a four-cycle latency: wait for the last `lane_we` before starting.

## Files to read first (attach or paste these if you're using a chatbot)

- `rtl/fecim_pkg.sv`, `rtl/fecim_top.sv` (the reference wiring)
- All of: `rtl/control/control_fsm.sv`, `rtl/write/write_path.sv`, `rtl/array/act_buffer.sv`, `rtl/array/mac_array.sv`, `rtl/array/mac_lane.sv`, `rtl/array/read_noise.sv`, `rtl/array/adc_quant.sv`, `rtl/result/result_buffer.sv`, `rtl/result/argmax_unit.sv`
- `tb/integration/tb_ab_integration.sv`, `tb/integration/lane_a_stub.sv`, `tb/integration/lane_b_stub.sv`
- `tb/run_sims.sh`
- `docs/plans and specs/02-lane-a-interface/top-level-spec.md` (§7)
- `docs/plans and specs/02-lane-a-interface/control-fsm-spec.md` (§10)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

