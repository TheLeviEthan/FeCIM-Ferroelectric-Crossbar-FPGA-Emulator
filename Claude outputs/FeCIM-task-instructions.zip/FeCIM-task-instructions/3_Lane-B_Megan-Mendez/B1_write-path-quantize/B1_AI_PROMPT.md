# AI prompt — B1: write_path stage 1: quantize and lane-select decode

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **B1 — write_path stage 1: quantize and lane-select decode**, owned by Megan Mendez, due Wed 18 Nov.

Implement stage 1 of `write_path`: the weight-write pipeline with address decode, conductance quantization and a latency-matched bypass, plus a self-checking testbench driven by the committed golden vectors.

Build the complete four-stage pipeline structure now, leaving the D2D and stuck-at stages as registered pass-throughs with clear `TODO(B3)` markers, so later work doesn't alter latency. The C++ function `quantize_weight()` is the reference: your RTL must agree with it for every input and every register value, including nonsense register pairs. Add the `noise_seed` input port that the skeleton is missing.

Editable files: `rtl/write/write_path.sv`, the `u_write_path` instance in `rtl/fecim_top.sv`, `tb/sv/tb_write_path.sv` (new), `tb/run_sims.sh`, `.github/workflows/ci.yml`. If the golden vector files don't exist yet, ask for them or for their format; don't invent a format.

## Where the work goes

- **Implement:** `rtl/write/write_path.sv` (skeleton; outputs tied to zero).
- **Port change (K4):** add `input logic [31:0] noise_seed`. Stages 2 and 3 (task B3) need it for the cell hash, and it isn't in the skeleton. Connect it in `rtl/fecim_top.sv`, instance `u_write_path`.
- **Outputs:** `lane_we`, `lane_sel[5:0]`, `lane_waddr[7:0]` = `{pass, row}`, `lane_wdata[7:0]`. `mac_array.sv` rebuilds the global address from these and each `mac_lane` decodes its own columns.
- **New testbench:** `tb/sv/tb_write_path.sv`, in `tb/run_sims.sh` and CI. It reads Ethan's vector files with `$readmemh`.
- **Golden vectors (from C1):** `tb/golden/write_path/`.
- **Reference implementation:** `model/src/write_path.cpp`, function `quantize_weight()`, and the long comment in `model/include/fecim/write_path.h`.
- **Spec:** `03-lane-b-array/write-path-spec.md` §1, §3, §4, §6, §9.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

Build the full four-stage pipeline now, with stages 2 and 3 as pass-throughs, so the latency never changes when B3 fills them in.

```text
stage 0 (register inputs):  valid = bulk_we && (bulk_target == TGT_WEIGHTS)
                            addr  = bulk_addr;  w = bulk_data
stage 1 (quantize):         w1 = noise_en.quant ? quantize(w) : w
stage 2 (D2D, task B3):     w2 = w1
stage 3 (stuck, B3):        w3 = w2
write:                      lane_we = valid (delayed 4 cycles, with addr and data)
```

Address decode is all wire slices (control-fsm-spec §3.1), at 128 rows and 64 lanes:

```systemverilog
row        = addr[6:0];              // addr = col*128 + row
col        = addr[13:7];
lane_sel   = col[5:0];               // col mod 64
pass       = col[6];                 // col div 64
lane_waddr = {pass, row};
```

Quantization (write-path-spec §4.1), exactly as the model does it:

```systemverilog
logic [8:0]  u, level;
logic [16:0] scaled;
assign u      = {1'b0, w} + 9'd128;             // int8 -> 0..255  (same as w ^ 8'h80)
assign level  = (u * quant_levels) >> 8;        // which of N bins   (9x9 multiply)
assign scaled = (level * quant_mult) >> 8;      // bin -> code       (9x16 multiply)
assign w_q    = scaled[7:0] - 8'd128;           // back to int8
```

`quant_mult` is a register the host computes as `round(255 × 256 / (N − 1))`. Use the register; don't recompute it.

A quick hand check with N = 2 (`quant_mult` = 65280): `w = 5` gives `u = 133`, `level = (133 × 2) >> 8 = 1`, `scaled = 65280 >> 8 = 255`, `w_q = 127`. Any weight ≥ 0 becomes +127 and any weight < 0 becomes −128.

## Acceptance checks

- Every case in `tb/golden/write_path/` for quantization passes: N ∈ {2, 3, 5, 8, 255}, quant on and off.
- With all `NOISE_EN` bits clear, all 256 input values come out unchanged (bypass exactness; this is what the L0 gate relies on).
- Latency from `bulk_we` to `lane_we` is the same number of cycles with quantization on and off.
- `bulk_target` = `TGT_ACT` or `TGT_ATTEN` never produces a `lane_we`.
- Back-to-back `bulk_we` on consecutive cycles works (the co-simulation feeds bytes much faster than a UART does).
- Lint waivers and the "SKELETON" header removed; lint clean.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **N = 255 isn't "no quantization".** With N = 255 every weight above −128 comes back one lower. The identity is `NOISE_EN.quant = 0`, which is why the bypass has to be exact.
- **Keep only `scaled[7:0]`.** A mismatched `quant_levels` / `quant_mult` pair wraps modulo 256 in the model, and the RTL must do the same nonsense. Don't add clamping or range checks.
- **Carry the address down the pipeline.** The write happens four cycles after `bulk_we`; using the parser's live `bulk_addr` at the write port is a bug that only shows on back-to-back writes.
- **The two spec errata from October** (a zero-extension error and a 9-bit product truncation in the spec's own code) were found when the model was written. Trust `write_path.cpp` and the golden vectors over a spec snippet, and report any difference you find so the spec gets fixed.
- For odd N the middle level is −1, not 0, and for some N the top level is +126. Those are properties of the formula; reproduce them.

## Files to read first (attach or paste these if you're using a chatbot)

- `rtl/fecim_pkg.sv`, `rtl/fecim_top.sv`
- `rtl/write/write_path.sv`
- `rtl/array/mac_array.sv`, `rtl/array/mac_lane.sv` (how the write address is consumed)
- `model/include/fecim/write_path.h`, `model/src/write_path.cpp`
- `tb/golden/write_path/` (README and vector files), `tb/sv/tb_mac_lane.sv` (how vectors are read)
- `tb/run_sims.sh`
- `docs/plans and specs/03-lane-b-array/write-path-spec.md`
- `docs/plans and specs/02-lane-a-interface/control-fsm-spec.md` (§3)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

