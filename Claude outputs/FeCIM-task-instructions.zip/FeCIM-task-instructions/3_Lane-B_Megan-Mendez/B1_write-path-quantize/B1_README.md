# B1 — write_path stage 1: quantize and lane-select decode

| | |
|---|---|
| **Owner** | Megan Mendez |
| **Due** | Wed 18 Nov |
| **Board bucket** | Bucket 3 — Lane B |
| **Board task** | B1: `write_path` stage 1 — quantize + lane-select decode |
| **Needs first** | K4 (adds `noise_seed` port), C1 (golden vectors, due Tue 17) |
| **Unblocks** | B3, B7, C4, C5, A5 |
| **AI version** | `B1_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

A neural-network weight is a number. A ferroelectric memory cell stores it as a conductance, and a real cell can't hold just any conductance: it has a small number of stable levels, often 4 to 8. So when a weight is "programmed" into the array, it gets rounded to the nearest level the device can actually hold. That rounding is **conductance quantization**, and it's the first of our six non-idealities.

`write_path` is where it happens. Every weight byte that arrives from the host passes through this module on its way to a lane's memory. With quantization switched off, the byte goes through untouched. With it on, the byte is snapped to one of N levels, where N comes from a register the host sets from a published device paper (N = 8 for our calibrated parameter set).

The module also does the address bookkeeping: the host numbers cells as `column × 128 + row`, and this module works out which of the 64 lanes owns that column.

There's **one** write path shared by all lanes, because weights arrive one byte at a time. That's what makes it affordable: about 6 multiplier blocks once, instead of 448 if every lane had its own.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Implement:** `rtl/write/write_path.sv` (skeleton; outputs tied to zero).
- **Port change (K4):** add `input logic [31:0] noise_seed`. Stages 2 and 3 (task B3) need it for the cell hash, and it isn't in the skeleton. Connect it in `rtl/fecim_top.sv`, instance `u_write_path`.
- **Outputs:** `lane_we`, `lane_sel[5:0]`, `lane_waddr[7:0]` = `{pass, row}`, `lane_wdata[7:0]`. `mac_array.sv` rebuilds the global address from these and each `mac_lane` decodes its own columns.
- **New testbench:** `tb/sv/tb_write_path.sv`, in `tb/run_sims.sh` and CI. It reads Ethan's vector files with `$readmemh`.
- **Golden vectors (from C1):** `tb/golden/write_path/`.
- **Reference implementation:** `model/src/write_path.cpp`, function `quantize_weight()`, and the long comment in `model/include/fecim/write_path.h`.
- **Spec:** `03-lane-b-array/write-path-spec.md` §1, §3, §4, §6, §9.

## 3. How to build it

Build the full four-stage pipeline now, with stages 2 and 3 as pass-throughs, so the latency never changes when B3 fills them in.

```text
stage 0 (register inputs):  valid = bulk_we && (bulk_target == TGT_WEIGHTS)
                            addr  = bulk_addr;  w = bulk_data
stage 1 (quantize):         w1 = noise_en.quant ? quantize(w) : w
stage 2 (D2D, task B3):     w2 = w1
stage 3 (stuck, B3):        w3 = w2
write:                      lane_we = valid (delayed 4 cycles, with addr and data)
```

Address decode is all wire slices (control-fsm-spec §3.1), at 128 rows and 64 lanes:

```systemverilog
row        = addr[6:0];              // addr = col*128 + row
col        = addr[13:7];
lane_sel   = col[5:0];               // col mod 64
pass       = col[6];                 // col div 64
lane_waddr = {pass, row};
```

Quantization (write-path-spec §4.1), exactly as the model does it:

```systemverilog
logic [8:0]  u, level;
logic [16:0] scaled;
assign u      = {1'b0, w} + 9'd128;             // int8 -> 0..255  (same as w ^ 8'h80)
assign level  = (u * quant_levels) >> 8;        // which of N bins   (9x9 multiply)
assign scaled = (level * quant_mult) >> 8;      // bin -> code       (9x16 multiply)
assign w_q    = scaled[7:0] - 8'd128;           // back to int8
```

`quant_mult` is a register the host computes as `round(255 × 256 / (N − 1))`. Use the register; don't recompute it.

A quick hand check with N = 2 (`quant_mult` = 65280): `w = 5` gives `u = 133`, `level = (133 × 2) >> 8 = 1`, `scaled = 65280 >> 8 = 255`, `w_q = 127`. Any weight ≥ 0 becomes +127 and any weight < 0 becomes −128.

## 4. How you know it's done

- Every case in `tb/golden/write_path/` for quantization passes: N ∈ {2, 3, 5, 8, 255}, quant on and off.
- With all `NOISE_EN` bits clear, all 256 input values come out unchanged (bypass exactness; this is what the L0 gate relies on).
- Latency from `bulk_we` to `lane_we` is the same number of cycles with quantization on and off.
- `bulk_target` = `TGT_ACT` or `TGT_ATTEN` never produces a `lane_we`.
- Back-to-back `bulk_we` on consecutive cycles works (the co-simulation feeds bytes much faster than a UART does).
- Lint waivers and the "SKELETON" header removed; lint clean.

## 5. Watch out for

- **N = 255 isn't "no quantization".** With N = 255 every weight above −128 comes back one lower. The identity is `NOISE_EN.quant = 0`, which is why the bypass has to be exact.
- **Keep only `scaled[7:0]`.** A mismatched `quant_levels` / `quant_mult` pair wraps modulo 256 in the model, and the RTL must do the same nonsense. Don't add clamping or range checks.
- **Carry the address down the pipeline.** The write happens four cycles after `bulk_we`; using the parser's live `bulk_addr` at the write port is a bug that only shows on back-to-back writes.
- **The two spec errata from October** (a zero-extension error and a 9-bit product truncation in the spec's own code) were found when the model was written. Trust `write_path.cpp` and the golden vectors over a spec snippet, and report any difference you find so the spec gets fixed.
- For odd N the middle level is −1, not 0, and for some N the top level is +126. Those are properties of the formula; reproduce them.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

