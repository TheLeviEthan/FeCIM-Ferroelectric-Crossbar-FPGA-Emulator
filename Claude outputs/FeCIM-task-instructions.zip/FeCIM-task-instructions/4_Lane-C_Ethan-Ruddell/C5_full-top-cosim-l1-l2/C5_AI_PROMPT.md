# AI prompt — C5: Full-top co-simulation with a virtual UART: L1 and L2

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **C5 — Full-top co-simulation with a virtual UART: L1 and L2**, owned by Ethan Ruddell, due Mon 23 Nov.

Build the full-design co-simulation: a Verilator harness around `fecim_top` that feeds protocol frames in through a bit-accurate virtual UART, applies the same frames to the C++ model, and compares every reply byte for byte. Include a Python stimulus generator that produces the request frames with the host package's own encoder and covers the verification matrix (clean, each non-ideality alone, all together, several tile sizes, and the protocol's error paths).

Design for diagnosability: every mismatch should print the frame index, the command, the byte offset and both values, and for `READ_RESULT` the column index. Design for speed: raise the baud rate at the start of each run as the real driver does, and bias random cases toward small tiles.

Identify, before writing code, every reply field the model can't predict (link error flags and counters) and say how you'll handle each. You may not be able to run Verilator; if so, mark the code as uncompiled and give exact build and run commands. Editable files: `model/cosim/` and `.github/workflows/ci.yml`. Don't modify `rtl/` or `sw/fecim/`; report bugs you find there with the evidence.

## Where the work goes

- **New harness:** `model/cosim/run_top.cpp`, Verilating all of `rtl/` with `--top-module fecim_top`.
- **Stimulus generator:** new `model/cosim/gen_top_stimulus.py`, which uses Natalie's encoder (`sw/fecim/protocol.py`, `build_packet`) to write request frames to a binary file. That way the host's encoder is tested against the real parser.
- **Makefile / README:** `run_top` target in `model/cosim/Makefile` (both branches), usage in `model/cosim/README.md`.
- **Model side:** `ModelExact::set_reg`, `write_weight`, `write_activation`, `write_atten`, `start_compute` / `step`, `results`, `argmax` (from C3).
- **Specs:** `04-lane-c-verification/model-verification-design.md` §3, §5.1, §6; `01-contract/protocol.md` (all).

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```text
gen_top_stimulus.py  ->  stim.bin : a list of request frames, each [A5][CMD][LEN:2][PAYLOAD][CRC8]

run_top:
    reset DUT; model = ModelExact()
    for each frame in stim.bin:
        uart_send(dut, frame)                      # bit-bang ARDUINO_IO0: start, 8 data LSB-first, stop
        reply = uart_receive(dut)                  # sample ARDUINO_IO1 until the full frame arrives
        expect = model_reply(model, frame)         # decode the same frame, apply it to the model,
                                                   #   build [5A][STATUS][LEN:2][PAYLOAD][CRC8]
        compare reply == expect, byte for byte     # on mismatch: print command, offset, both values
```

`model_reply` is a small switch on the command byte:

```text
SET_CONFIG   -> model.set_reg(reg, value)            reply: status only
GET_CONFIG   -> model.get_reg(reg)                   reply: 4 bytes
WRITE_*      -> model.write_weight / _activation / _atten for each data byte
COMPUTE      -> model.start_compute(); step until !busy
READ_RESULT  -> model.results()[start .. start+count)    int32 little-endian
READ_ARGMAX  -> model.argmax()                       10 bytes
IDENTIFY     -> the constant identify block (error counters: compare as zero)
```

**Speed.** The virtual UART is bit-accurate, so it's as slow as a real one unless you raise the baud rate. Start each run the way the real driver does: `IDENTIFY` at the reset rate, then `SET_CONFIG BAUD_INC` to a large value so a byte takes a few hundred clock cycles or fewer. Keep most random cases on small tiles (8×8, 32×32) and reuse one weight load for several activation vectors.

**Test matrix** (`model-verification-design.md` §6.1), generated by the Python script:

| Level | Configurations |
|---|---|
| L0 | clean, 128×128 |
| L1 | quant only, N ∈ {2, 3, 5, 8, 255} · D2D only, σ ∈ {0, 8, 32, 255} · read noise only · stuck only, rate ∈ {0, 1 %, 10 %}, both modes · ADC only, bits ∈ {4, 8, 16, 24} · IR only |
| L2 | all six enabled, 100+ random settings and seeds |
| Sizes | 8×8, 32×32, 48×48, 128×128 |

Reseed (`CTRL[2]`) before every compute, in the stimulus, so runs are reproducible.

## Acceptance checks

- `run_top` passes the whole matrix: L0, every L1 row, L2 with at least 100 random configurations, and all four tile sizes.
- Error paths match too: a frame with a bad CRC, an unknown command, a read-only register write, and an out-of-range `READ_RESULT`.
- The live-bug demo works on the full top: one character changed in the RTL (for example the activation sign-extension in `mac_lane.sv`) makes `run_top` fail and name the command and column.
- A short subset runs in CI in a few minutes; the full matrix command and runtime are in the README.
- A 30-second backup recording of a passing run and of the live bug exists.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Expect disagreements about the protocol's corners,** and expect some of them to be the model's fault. Each mismatch is a three-way question (RTL, model, spec). Resolve it from the spec, fix whichever side is wrong through its owner, and if the spec is silent, write the answer into the spec.
- **`STATUS` and the identify block contain link-level fields** (last error, error counters) that the model can't know. Compare them against expected constants or mask them, and say which in the README.
- **Weights must be rewritten after changing a write-time setting** (quant levels, D2D sigma, stuck rate, seed, or their enables). The stimulus generator has to order frames that way, exactly as the real driver will.
- **The baud switch reply** (see A2) may arrive at the old or new rate. Handle whichever rule Zhiting implements, in one place.
- If bit-level UART proves too slow for the full matrix, an alternative is to force bytes in at the parser's `rx_data` / `rx_valid` using `--public-flat-rw`. It's faster but skips the UART, so keep at least one bit-level run.

## Files to read first (attach or paste these if you're using a chatbot)

- `model/cosim/run_l0.cpp`, `model/cosim/Makefile`, `model/cosim/README.md`
- `model/include/fecim/model_exact.h`, `model/include/fecim/params.h`, `model/include/fecim/primitives.h`
- `rtl/fecim_pkg.sv`, `rtl/fecim_top.sv`, `rtl/uart/` (all three files), `rtl/packet/packet_parser.sv`, `rtl/packet/packet_tx.sv`, `rtl/control/config_regs.sv`
- `sw/fecim/protocol.py`, `sw/fecim/codec.py`
- `tb/golden/gen_packet_vectors.py` (an existing use of the encoder)
- `docs/plans and specs/01-contract/protocol.md`
- `docs/plans and specs/04-lane-c-verification/model-verification-design.md`

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

