# AI prompt — C3: ModelExact::step() and the full-array sequencer

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **C3 — ModelExact::step() and the full-array sequencer**, owned by Ethan Ruddell, due Fri 20 Nov.

Implement the cycle-accurate half of the bit-exact C++ model: `ModelExact::step()` and the members around it (sequencer state, per-lane pipeline registers, result buffer, argmax with runner-up, `results_valid`, `result_seq`, cycle counter, and the register-level `set_reg` / `get_reg` interface).

The model must be a clock-edge twin of the RTL: after N calls to `step()`, each lane's observable state equals the RTL's after N clock edges. Structure `step()` as "compute all next values from current values, then commit", mirroring non-blocking assignment. Derive the pipeline alignment from `mac_lane.sv`, `act_buffer.sv` and `control_fsm.sv` as they exist in the files you're given; if `control_fsm.sv` is still a skeleton, derive it from `control-fsm-spec.md` §4 and list every assumption for the RTL owner to confirm.

Add tests that prove `compute()` equals the stepped path for every configuration. Editable files: everything under `model/`. Don't touch `rtl/` or `sw/`.

## Where the work goes

- **Implement:** every member still in the "interface stub" block of `model/src/model_exact.cpp`: `start_compute()`, `step()`, `state()`, `busy()`, `seq_cnt()`, `lane()`, `cycle_count()`, `results()`, `argmax()`, `set_reg()`, `get_reg()`. Declarations and contracts are in `model/include/fecim/model_exact.h`.
- **Add private state** to the class: FSM state and counters, per-lane pipeline registers, the result buffer, the argmax tracker, `results_valid`, `result_seq`.
- **Unit tests:** new `model/tests/test_model_step.cpp` in `model/CMakeLists.txt`; update `test_model_exact_stub.cpp`.
- **Mirror of:** `rtl/control/control_fsm.sv` (A1), `rtl/array/mac_lane.sv`, `rtl/array/act_buffer.sv`, `rtl/result/result_buffer.sv`, `rtl/result/argmax_unit.sv`, `rtl/control/config_regs.sv`.
- **Specs:** `02-lane-a-interface/control-fsm-spec.md` §4, §6; `03-lane-b-array/activation-buffer-spec.md` §4; `result-buffer-spec.md` §3–5; `04-lane-c-verification/model-verification-design.md` §5.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

The technique that makes a C++ model match clocked hardware: **compute every next value from the current values, then commit them all at once.** That's what non-blocking assignment (`<=`) means in SystemVerilog. If you update variables in place, a later line sees a value that the hardware wouldn't see until the next cycle.

```cpp
struct LaneState {                 // one mac_lane's registers
    std::int8_t   w_rd, w_align;   // M9K output, alignment register
    std::int8_t   noise_q;         // registered noise sample
    std::int32_t  prod, acc;
    std::uint32_t lfsr;
};
struct Seq {                       // control_fsm + act_buffer registers
    CtrlState st; int pass, row, hold, drain; std::uint32_t cyc;
    bool v1, v2, v3;               // acc_en delayed 1, 2, 3 cycles
    std::uint8_t act_raw, act_bcast;
};

void ModelExact::step() {
    Seq       s  = seq_;           // next-state copies
    auto      ln = lanes_;
    // 1. outputs of the FSM this cycle, from seq_ (current state)
    const bool acc_en = (seq_.st == CTRL_ACC) && (seq_.row < cfg_.active_rows);
    // 2. lane pipeline, reading only lanes_ / seq_ (current), writing ln / s (next)
    for (int l = 0; l < NUM_LANES; ++l) {
        if (seq_.v3)            ln[l].acc  = lanes_[l].acc + lanes_[l].prod;          // N+3
        if (seq_.v2)            ln[l].prod = w_n(lanes_[l]) * int(seq_.act_bcast);    // N+2
        ln[l].w_align = lanes_[l].w_rd;                                               // N+1
        ln[l].noise_q = read_noise_q(lanes_[l].lfsr, cfg_.read_sigma);                // N+1
        if (acc_en) { ln[l].w_rd = weight(seq_.pass, seq_.row, l);                    // N
                      ln[l].lfsr = lfsr_step(lanes_[l].lfsr); }
        // acc_clear and the drain shift take the place of the accumulate when active
    }
    // 3. FSM next state, drain into result buffer + argmax, cycle counter
    // 4. commit
    seq_ = s; lanes_ = ln;
}
```

Work through the first three rows on paper against `mac_lane.sv` before trusting it: the accumulator must first change at the end of cycle N+3 for a row issued in cycle N.

`set_reg` / `get_reg` follow the register map in `params.h` (`CfgAddr`):

```text
REG_CTRL      write: bit0 soft reset, bit1 clear results, bit2 reseed (strobes, nothing stored)
REG_TILE_CFG  [15:0] active_rows, [31:16] active_cols
REG_STATUS    read-only: [3:0] state, [4] busy, [5] last error (0 here), [6] results_valid,
              [15:8] result_seq
REG_CYCLE_CNT read-only
write to STATUS / CYCLE_CNT, or any address not in the map (incl. 0x10-0x1F): ST_ADDR_RANGE
```

Then make the equivalence a test: for every configuration, `compute()` must equal "`start_compute()`, `step()` until `!busy()`, `results()`".

## Acceptance checks

- `compute()` equals the `step()` path for: clean, each non-ideality alone, all together; tile sizes 8×8, 32×32, 48×48, 64×64, 128×128; `active_cols` = 48 and 100.
- `cycle_count()` is 392 for the full tile and `passes × (1 + rows + 3 + 64)` in general, and equals `CYCLE_CNT` from Zhiting's `tb_control_fsm`.
- `argmax()` matches a brute-force scan over `results()`, with ties going to the lowest index and columns ≥ `active_cols` ignored.
- Stepping while idle changes nothing, including the LFSRs.
- `set_reg` / `get_reg`: reset defaults, read-only and reserved addresses return `ST_ADDR_RANGE`, `CTRL` strobes work, `STATUS` fields are right before, during and after a compute.
- No stub left that throws "not implemented".

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **This mirrors A1, so it inherits A1's open choices.** Agree four things with Zhiting and Megan and write them down: what `CYCLE_CNT` counts; whether the drain shifts in the same cycle as the first write; what `argmax_second` is when only one column is active; whether `CTRL[1]` zeroes the result memory or only clears `results_valid`.
- **Soft reset.** Decide with Zhiting (A8) what `CTRL[0]` resets. The sensible rule keeps all config registers and returns the sequencer to idle.
- **`LaneProbe::w_n` is combinational in the RTL** (`w_align + noise_q` in cycle N+2). Decide which cycle's value `lane(l).w_n` reports and document it, so the harness compares like with like.
- If `LANE_PIPE_DEPTH` becomes 4 (A7's fallback), this is one of the places that changes. Write the pipeline so the depth isn't hard-coded in more than one spot.
- `last error` in `STATUS[5]` comes from the UART and parser on the board. The model has no link, so it reads 0; mask that bit in hardware comparisons (C8).

## Files to read first (attach or paste these if you're using a chatbot)

- `model/include/fecim/model_exact.h`, `model/src/model_exact.cpp`, `model/include/fecim/params.h`
- `model/include/fecim/read_path.h`, `model/src/read_path.cpp`, `model/src/write_path.cpp`, `model/src/primitives.cpp`
- `model/tests/` (all), `model/CMakeLists.txt`
- `rtl/fecim_pkg.sv`, `rtl/control/control_fsm.sv`, `rtl/control/config_regs.sv`, `rtl/array/mac_lane.sv`, `rtl/array/read_noise.sv`, `rtl/array/act_buffer.sv`, `rtl/array/adc_quant.sv`, `rtl/result/result_buffer.sv`, `rtl/result/argmax_unit.sv` (read-only reference)
- `docs/plans and specs/02-lane-a-interface/control-fsm-spec.md`
- `docs/plans and specs/03-lane-b-array/activation-buffer-spec.md`, `result-buffer-spec.md`
- `docs/plans and specs/04-lane-c-verification/model-verification-design.md`
- `docs/plans and specs/01-contract/protocol.md` (§6)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

