# C3 — ModelExact::step() and the full-array sequencer

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Fri 20 Nov |
| **Board bucket** | Bucket 4 — Lane C |
| **Board task** | C3: `ModelExact::step()` + full-array MVM sequencer |
| **Needs first** | C2; A1's timeline agreed with Zhiting |
| **Unblocks** | C4, C5, D3 (register-level sim backend), A1 cross-check |
| **AI version** | `C3_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

So far the model answers "what are the final results?". That's enough to check an answer, but not to find a bug. If the hardware's column 37 is wrong, the final numbers don't say whether the weight was read wrong, the noise was wrong, the multiply was wrong, or the sequencer dropped a row.

`step()` makes the model a clock-by-clock twin of the hardware. The co-simulation harness clocks the real RTL once, calls `step()` once, and compares the inside of every lane: the noisy weight, the product, the accumulator. The first cycle where they differ names the lane, the cycle and the pipeline stage. A two-day debugging session becomes a two-minute one.

It also gives two things the rest of the team is waiting on. The model can predict `CYCLE_CNT`, which turns our 7.84 µs latency claim into a checked number. And it gains a register-level interface (`set_reg` / `get_reg`), so Natalie's `sim` backend can drive the model with exactly the same register writes the board receives.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Implement:** every member still in the "interface stub" block of `model/src/model_exact.cpp`: `start_compute()`, `step()`, `state()`, `busy()`, `seq_cnt()`, `lane()`, `cycle_count()`, `results()`, `argmax()`, `set_reg()`, `get_reg()`. Declarations and contracts are in `model/include/fecim/model_exact.h`.
- **Add private state** to the class: FSM state and counters, per-lane pipeline registers, the result buffer, the argmax tracker, `results_valid`, `result_seq`.
- **Unit tests:** new `model/tests/test_model_step.cpp` in `model/CMakeLists.txt`; update `test_model_exact_stub.cpp`.
- **Mirror of:** `rtl/control/control_fsm.sv` (A1), `rtl/array/mac_lane.sv`, `rtl/array/act_buffer.sv`, `rtl/result/result_buffer.sv`, `rtl/result/argmax_unit.sv`, `rtl/control/config_regs.sv`.
- **Specs:** `02-lane-a-interface/control-fsm-spec.md` §4, §6; `03-lane-b-array/activation-buffer-spec.md` §4; `result-buffer-spec.md` §3–5; `04-lane-c-verification/model-verification-design.md` §5.

## 3. How to build it

The technique that makes a C++ model match clocked hardware: **compute every next value from the current values, then commit them all at once.** That's what non-blocking assignment (`<=`) means in SystemVerilog. If you update variables in place, a later line sees a value that the hardware wouldn't see until the next cycle.

```cpp
struct LaneState {                 // one mac_lane's registers
    std::int8_t   w_rd, w_align;   // M9K output, alignment register
    std::int8_t   noise_q;         // registered noise sample
    std::int32_t  prod, acc;
    std::uint32_t lfsr;
};
struct Seq {                       // control_fsm + act_buffer registers
    CtrlState st; int pass, row, hold, drain; std::uint32_t cyc;
    bool v1, v2, v3;               // acc_en delayed 1, 2, 3 cycles
    std::uint8_t act_raw, act_bcast;
};

void ModelExact::step() {
    Seq       s  = seq_;           // next-state copies
    auto      ln = lanes_;
    // 1. outputs of the FSM this cycle, from seq_ (current state)
    const bool acc_en = (seq_.st == CTRL_ACC) && (seq_.row < cfg_.active_rows);
    // 2. lane pipeline, reading only lanes_ / seq_ (current), writing ln / s (next)
    for (int l = 0; l < NUM_LANES; ++l) {
        if (seq_.v3)            ln[l].acc  = lanes_[l].acc + lanes_[l].prod;          // N+3
        if (seq_.v2)            ln[l].prod = w_n(lanes_[l]) * int(seq_.act_bcast);    // N+2
        ln[l].w_align = lanes_[l].w_rd;                                               // N+1
        ln[l].noise_q = read_noise_q(lanes_[l].lfsr, cfg_.read_sigma);                // N+1
        if (acc_en) { ln[l].w_rd = weight(seq_.pass, seq_.row, l);                    // N
                      ln[l].lfsr = lfsr_step(lanes_[l].lfsr); }
        // acc_clear and the drain shift take the place of the accumulate when active
    }
    // 3. FSM next state, drain into result buffer + argmax, cycle counter
    // 4. commit
    seq_ = s; lanes_ = ln;
}
```

Work through the first three rows on paper against `mac_lane.sv` before trusting it: the accumulator must first change at the end of cycle N+3 for a row issued in cycle N.

`set_reg` / `get_reg` follow the register map in `params.h` (`CfgAddr`):

```text
REG_CTRL      write: bit0 soft reset, bit1 clear results, bit2 reseed (strobes, nothing stored)
REG_TILE_CFG  [15:0] active_rows, [31:16] active_cols
REG_STATUS    read-only: [3:0] state, [4] busy, [5] last error (0 here), [6] results_valid,
              [15:8] result_seq
REG_CYCLE_CNT read-only
write to STATUS / CYCLE_CNT, or any address not in the map (incl. 0x10-0x1F): ST_ADDR_RANGE
```

Then make the equivalence a test: for every configuration, `compute()` must equal "`start_compute()`, `step()` until `!busy()`, `results()`".

## 4. How you know it's done

- `compute()` equals the `step()` path for: clean, each non-ideality alone, all together; tile sizes 8×8, 32×32, 48×48, 64×64, 128×128; `active_cols` = 48 and 100.
- `cycle_count()` is 392 for the full tile and `passes × (1 + rows + 3 + 64)` in general, and equals `CYCLE_CNT` from Zhiting's `tb_control_fsm`.
- `argmax()` matches a brute-force scan over `results()`, with ties going to the lowest index and columns ≥ `active_cols` ignored.
- Stepping while idle changes nothing, including the LFSRs.
- `set_reg` / `get_reg`: reset defaults, read-only and reserved addresses return `ST_ADDR_RANGE`, `CTRL` strobes work, `STATUS` fields are right before, during and after a compute.
- No stub left that throws "not implemented".

## 5. Watch out for

- **This mirrors A1, so it inherits A1's open choices.** Agree four things with Zhiting and Megan and write them down: what `CYCLE_CNT` counts; whether the drain shifts in the same cycle as the first write; what `argmax_second` is when only one column is active; whether `CTRL[1]` zeroes the result memory or only clears `results_valid`.
- **Soft reset.** Decide with Zhiting (A8) what `CTRL[0]` resets. The sensible rule keeps all config registers and returns the sequencer to idle.
- **`LaneProbe::w_n` is combinational in the RTL** (`w_align + noise_q` in cycle N+2). Decide which cycle's value `lane(l).w_n` reports and document it, so the harness compares like with like.
- If `LANE_PIPE_DEPTH` becomes 4 (A7's fallback), this is one of the places that changes. Write the pipeline so the depth isn't hard-coded in more than one spot.
- `last error` in `STATUS[5]` comes from the UART and parser on the board. The model has no link, so it reads 0; mask that bit in hardware comparisons (C8).

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

