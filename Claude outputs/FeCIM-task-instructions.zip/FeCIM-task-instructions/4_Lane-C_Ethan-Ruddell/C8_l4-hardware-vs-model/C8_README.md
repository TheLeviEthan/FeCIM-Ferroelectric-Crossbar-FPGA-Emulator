# C8 — L4 script: hardware equals model_exact at a matched seed

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Tue 24 Nov |
| **Board bucket** | Bucket 4 — Lane C |
| **Board task** | C8: L4 script — hardware ≡ `model_exact` at matched seed |
| **Needs first** | D2 (driver), D3 (sim backend), C5 |
| **Unblocks** | G4, A8 (soak), D6, D8 |
| **AI version** | `C8_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Simulation proves the design is right on paper. L4 proves the *board* is right: the physical FPGA, programmed with the real bitstream, running at 50 MHz over a real cable, produces exactly the numbers the model predicts.

This is the step that licenses our central claim. We want to say that when accuracy drops as read noise goes up, the drop is caused by the modelled device physics. That's only true if the hardware does precisely what the model says and nothing else: no timing errors, no dropped bytes, no mis-wired lane. A bit-for-bit match, for every non-ideality, at the same seed, is the evidence.

The script is deliberately simple: give the same configuration, weights and inputs to the board and to the model, and compare every column. You don't have a board, so it's written to be run by Zhiting and Natalie, and to work against the `sim` backend so it can be tested before any hardware computes.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **New script:** `sw/examples/check_hw_vs_model.py` (optionally exposed later as a `fecim check-hw` command).
- **Uses:** the public `Crossbar` API from `sw/fecim/crossbar.py` with `backend="fpga"` (D2) and `backend="sim"` (D3).
- **Importable function:** `check_hw_vs_model(xbar_hw, xbar_ref, cfg, W, x) -> bool`, so Zhiting's soak test (A8) and the sweep code can call it.
- **Matrix it runs:** `04-lane-c-verification/model-verification-design.md` §6.1, the "Hardware" column.
- **Output:** a table on the terminal and a log file under `results/l4/`.

## 3. How to build it

```python
def apply(xbar, cfg, W, x):
    xbar.set_tile(cfg.rows, cfg.cols)
    xbar.set_quantization(cfg.levels); xbar.set_variation(reg=cfg.d2d_sigma)
    xbar.set_read_noise(reg=cfg.read_sigma); xbar.set_faults(reg=cfg.stuck_rate)
    xbar.set_adc(bits=cfg.adc_bits); xbar.set_ir_drop(coeffs=cfg.atten)
    xbar.enable(cfg.enables)
    xbar.seed(cfg.seed)                 # writes NOISE_SEED, then pulses CTRL[2]
    xbar.load_weights_raw(W)            # AFTER config: write-time effects use it
    xbar.write_activations_raw(x)
    xbar.seed(cfg.seed)                 # reseed right before compute, on both sides
    xbar.compute()
    return xbar.read_results(), xbar.read_argmax(), xbar.cycle_count()

def check_hw_vs_model(hw, ref, cfg, W, x):
    y_hw, am_hw, cyc_hw = apply(hw, cfg, W, x)
    y_rf, am_rf, cyc_rf = apply(ref, cfg, W, x)
    ok = (y_hw == y_rf).all() and am_hw == am_rf and cyc_hw == cyc_rf
    if not ok: print_diff_table(y_hw, y_rf)      # column, expected, actual, difference
    return ok
```

Use raw integer weights and activations (`int8`, `uint8`) here, not the float mapping layer: this is a datapath check, and the mapping is tested elsewhere.

The main program loops over the matrix: clean; each non-ideality alone at the listed settings; all six together with 20 or more random settings; tile sizes 8×8, 32×32, 48×48, 128×128. It prints one line per case and a final `PASS n/n`, and exits non-zero on any failure.

Test the script itself before a board exists by running `sim` against `sim` (must pass), then against a deliberately different configuration (must fail and show the diff).

## 4. How you know it's done

- `python sw/examples/check_hw_vs_model.py --backend sim` passes (model against itself) and a deliberately mismatched run fails with a readable per-column table.
- On a board: every row of the matrix passes bit-exact, including all six non-idealities together, and `CYCLE_CNT` equals the model's prediction (392 for the full tile).
- `READ_ARGMAX` (index, value, runner-up) matches as well as `READ_RESULT`.
- The log from the first full passing hardware run is committed under `results/l4/` with the commit hash and `BUILD_ID`.
- Usage is in the README, and Zhiting and Natalie have each run it on their board.

## 5. Watch out for

- **Order matters, on both sides identically.** Configure and seed first, then load weights (quantization, D2D and stuck-at are applied as weights are written), then reseed immediately before `compute()` so the read-noise sequence starts from the same state.
- **Method names above are placeholders** for whatever D2 and D3 expose. Agree the handful of raw-access calls with Natalie; the spec's public API takes physical units, and this script needs register-level access (the `set_config` escape hatch is fine).
- **Mask what the model can't know:** `STATUS[5]` (last link error) and the identify block's error counters.
- A failure on hardware that passes in C5's simulation points at timing (A7), the bitstream version (check `BUILD_ID`), or the link (check the error counters), in that order.
- You can't run the hardware side yourself. Send Zhiting and Natalie the exact command and ask for the log file back.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

