# AI prompt — C8: L4 script: hardware equals model_exact at a matched seed

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **C8 — L4 script: hardware equals model_exact at a matched seed**, owned by Ethan Ruddell, due Tue 24 Nov.

Write the hardware-versus-model check: a Python script and importable function that applies one configuration, weight matrix and activation vector to two `Crossbar` instances (the FPGA backend and the `sim` backend), runs a compute on each with matched seeding, and compares every result column, the argmax record and the cycle count bit for bit. Add a main program that loops over the verification matrix and reports pass/fail per case with a per-column diff table on failure.

Use the host package's API as it actually exists in the files you're given; where a register-level call you need isn't exposed, say which one and propose the smallest addition for the package's owner to make. The ordering of configuration, seeding, weight loading and reseeding is part of the correctness of this check, so explain it in comments. Editable files: `sw/examples/check_hw_vs_model.py` (new) and the repo `README.md` usage section. Don't modify files under `sw/fecim/` (Lane D).

## Where the work goes

- **New script:** `sw/examples/check_hw_vs_model.py` (optionally exposed later as a `fecim check-hw` command).
- **Uses:** the public `Crossbar` API from `sw/fecim/crossbar.py` with `backend="fpga"` (D2) and `backend="sim"` (D3).
- **Importable function:** `check_hw_vs_model(xbar_hw, xbar_ref, cfg, W, x) -> bool`, so Zhiting's soak test (A8) and the sweep code can call it.
- **Matrix it runs:** `04-lane-c-verification/model-verification-design.md` §6.1, the "Hardware" column.
- **Output:** a table on the terminal and a log file under `results/l4/`.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```python
def apply(xbar, cfg, W, x):
    xbar.set_tile(cfg.rows, cfg.cols)
    xbar.set_quantization(cfg.levels); xbar.set_variation(reg=cfg.d2d_sigma)
    xbar.set_read_noise(reg=cfg.read_sigma); xbar.set_faults(reg=cfg.stuck_rate)
    xbar.set_adc(bits=cfg.adc_bits); xbar.set_ir_drop(coeffs=cfg.atten)
    xbar.enable(cfg.enables)
    xbar.seed(cfg.seed)                 # writes NOISE_SEED, then pulses CTRL[2]
    xbar.load_weights_raw(W)            # AFTER config: write-time effects use it
    xbar.write_activations_raw(x)
    xbar.seed(cfg.seed)                 # reseed right before compute, on both sides
    xbar.compute()
    return xbar.read_results(), xbar.read_argmax(), xbar.cycle_count()

def check_hw_vs_model(hw, ref, cfg, W, x):
    y_hw, am_hw, cyc_hw = apply(hw, cfg, W, x)
    y_rf, am_rf, cyc_rf = apply(ref, cfg, W, x)
    ok = (y_hw == y_rf).all() and am_hw == am_rf and cyc_hw == cyc_rf
    if not ok: print_diff_table(y_hw, y_rf)      # column, expected, actual, difference
    return ok
```

Use raw integer weights and activations (`int8`, `uint8`) here, not the float mapping layer: this is a datapath check, and the mapping is tested elsewhere.

The main program loops over the matrix: clean; each non-ideality alone at the listed settings; all six together with 20 or more random settings; tile sizes 8×8, 32×32, 48×48, 128×128. It prints one line per case and a final `PASS n/n`, and exits non-zero on any failure.

Test the script itself before a board exists by running `sim` against `sim` (must pass), then against a deliberately different configuration (must fail and show the diff).

## Acceptance checks

- `python sw/examples/check_hw_vs_model.py --backend sim` passes (model against itself) and a deliberately mismatched run fails with a readable per-column table.
- On a board: every row of the matrix passes bit-exact, including all six non-idealities together, and `CYCLE_CNT` equals the model's prediction (392 for the full tile).
- `READ_ARGMAX` (index, value, runner-up) matches as well as `READ_RESULT`.
- The log from the first full passing hardware run is committed under `results/l4/` with the commit hash and `BUILD_ID`.
- Usage is in the README, and Zhiting and Natalie have each run it on their board.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Order matters, on both sides identically.** Configure and seed first, then load weights (quantization, D2D and stuck-at are applied as weights are written), then reseed immediately before `compute()` so the read-noise sequence starts from the same state.
- **Method names above are placeholders** for whatever D2 and D3 expose. Agree the handful of raw-access calls with Natalie; the spec's public API takes physical units, and this script needs register-level access (the `set_config` escape hatch is fine).
- **Mask what the model can't know:** `STATUS[5]` (last link error) and the identify block's error counters.
- A failure on hardware that passes in C5's simulation points at timing (A7), the bitstream version (check `BUILD_ID`), or the link (check the error counters), in that order.
- You can't run the hardware side yourself. Send Zhiting and Natalie the exact command and ask for the log file back.

## Files to read first (attach or paste these if you're using a chatbot)

- `sw/fecim/crossbar.py`, `sw/fecim/backends/` (or `sw/fecim/drivers/`), `sw/fecim/protocol.py`, `sw/fecim/codec.py`
- `sw/examples/demo_pipeline.py` (existing style)
- `model/include/fecim/model_exact.h`
- `docs/plans and specs/05-lane-d-host/host-driver-spec.md` (§5, §6)
- `docs/plans and specs/04-lane-c-verification/model-verification-design.md` (§3, §6)
- `docs/plans and specs/01-contract/protocol.md` (§6)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

