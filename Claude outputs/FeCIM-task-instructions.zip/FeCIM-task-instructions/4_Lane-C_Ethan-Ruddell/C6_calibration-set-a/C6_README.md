# C6 — Calibration: parameter set A documented, with register mapping and provenance

| | |
|---|---|
| **Owner** | Ethan Ruddell (co-owned with Natalie Poche) |
| **Due** | Mon 23 Nov |
| **Board bucket** | Bucket 4 — Lane C |
| **Board task** | C6: Calibration — set A documented, register mapping, provenance (week-7 gate) |
| **Needs first** | C2 (knows which registers exist and their scales) |
| **Unblocks** | D4, D8, C9, P3 slide |
| **AI version** | `C6_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

An emulator with made-up noise settings is a toy. What makes FeCIM an engineering tool is that its settings come from a real device: when we say "8 levels, this much variation", those numbers trace to a published FeFET paper, through arithmetic anyone can check.

This task writes that chain down for parameter set A (Chatterjee et al., IEEE TED 2022). For each register: what the paper reports, which figure it's from, the conversion, and the resulting register value. A reader should be able to open the paper, find the number, redo the arithmetic and get our register value.

Just as important is being honest about what the paper *doesn't* give us. It reports no read noise and no stuck-cell rate, and it says nothing about wire resistance or ADC resolution, because those aren't properties of a single device. For each gap we either borrow a value from another source and label the set "composite", or sweep the parameter and present a band. Presenting every number with equal confidence would make a careful reader trust none of them.

This is the plan's calibration gate, and all four of us sign off on it, because the headline plots are only as credible as this page.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Write:** `docs/plans and specs/06-physics-calibration/device-model.md` — fill the Set A row in §7 and add a section with the full derivation table.
- **Raw data file (already exists, stays in raw device units):** `sw/fecim/parameter_sets/dualport_fefet_mlc.yaml`.
- **Source notes:** `docs/plans and specs/06-physics-calibration/literature-survey.md` §2 (set A extraction) and §4 (candidates for gaps).
- **Conversion math:** `docs/plans and specs/06-physics-calibration/cell-physics-derivation.md` §4.
- **Code path that applies it:** Natalie's D4 (`load_parameter_set`). Agree the numbers below with her so her tests pin the same values.

## 3. How to build it

The identity everything rests on: a threshold-voltage error maps to a weight error by `Δw [LSB] = 255 × ΔV_th / MW`, where MW is the memory window.

**From set A directly** (MW = 2.7 V, σ_Vth = 78.75 mV, 8 levels):

| Register | Source quantity | Arithmetic | Value | Confidence |
|---|---|---|---|---|
| `QUANT_LEVELS` | 8 states at P(error) < 1 % (Fig. 15d) | direct | **8** | direct (lower bound: 16 fails) |
| `QUANT_MULT` | — | `round(255 × 256 / 7)` | **9326** | exact |
| `D2D_SIGMA` | σ_Vth, MW | σ_w = 255 × 0.07875 / 2.7 = 7.44 LSB; `round(2.450 × 7.44)` | **18** | derived |

**Not in set A** (each needs a decision recorded in the document):

| Register | Situation | Recommended handling |
|---|---|---|
| `READ_SIGMA` | The paper is static-only; no cycle-to-cycle data | Sweep. As a reference point, De et al. report 17.7 mV; with set A's MW that's 1.67 LSB, `round(6.93 × 1.67)` = 12. Using it makes the set **composite**, so label it. |
| `STUCK_RATE` | No yield data | Sweep, e.g. 0 to 5 %; `STUCK_RATE = round(65536 × p)` |
| `atten_rom` (IR drop) | A circuit property, not a device property | Design choice: `α_i = 1 − κ·i/M`, coefficient `min(255, round(256·α_i))`; sweep κ. State the wire-resistance assumption behind the κ range. |
| `ADC_BITS` | A converter choice | Design choice: sweep 4 to 12 bits |

Write the section in this order: the provenance rule (one paragraph), the direct table, the gaps table, a "how to reproduce" note pointing at the YAML and at `load_parameter_set`, and the list of assumptions:

1. Set A is **TCAD-simulated**, calibrated to measured 22 nm FDSOI data; it isn't a measured array.
2. σ is the worst-case state (the LVT end); other states are tighter.
3. A signed weight is modelled as one quantity, not as a differential pair of cells.
4. D2D is triangular, not Gaussian.
5. IR drop is a per-row attenuation, not a resistor-network solution.

## 4. How you know it's done

- Every register value in the document has a source (paper, figure or section), the conversion arithmetic, and a confidence label from `device-model.md` §3.
- Recomputing each value by hand from the YAML gives the documented number.
- Anything borrowed from a second source is labelled composite, and anything unreported is listed as swept with its range.
- The five assumptions above are stated.
- Natalie's `load_parameter_set("dualport_fefet_mlc")` produces the same register values (D4's test).
- All four teammates have approved the PR.

## 5. Watch out for

- **Don't put register values in the YAML.** The files hold raw device quantities so a conversion change never leaves stale numbers behind (`device-model.md` §4).
- **`sw/fecim/plan-d.yml` is actually the `gf28_hkmg` parameter set** (Soliman et al., Nat. Commun. 2023: MW 1.2 V, 4 levels, σ 38 mV) saved under the wrong name and folder. It's set B's raw data. Ask Natalie to move it to `sw/fecim/parameter_sets/gf28_hkmg.yaml` (D1); documenting set B is optional for this deadline.
- The D2D register is an integer, so the realized σ is `0.408 × 18 = 7.35 LSB`, about 1 % below the target. Say so; C9 measures it.
- `QUANT_LEVELS = 8` is a lower bound from the paper (it tested 2, 4, 8, 16). The sweep over levels shows what 9 to 15 would give.
- Check the citation details against the paper itself before they go in a slide.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

