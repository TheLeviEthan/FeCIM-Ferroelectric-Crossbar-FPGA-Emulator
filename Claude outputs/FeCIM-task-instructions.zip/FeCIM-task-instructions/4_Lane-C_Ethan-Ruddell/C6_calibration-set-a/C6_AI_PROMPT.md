# AI prompt — C6: Calibration: parameter set A documented, with register mapping and provenance

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **C6 — Calibration: parameter set A documented, with register mapping and provenance**, owned by Ethan Ruddell (co-owned with Natalie Poche), due Mon 23 Nov.

Write the calibration documentation for parameter set A: the traceable chain from the published device quantities in `dualport_fefet_mlc.yaml` to FeCIM register values, with confidence labels, the handling of every parameter the source doesn't report, and an explicit list of modelling assumptions.

Use only the quantities present in the YAML and the survey notes you're given; redo each conversion from `cell-physics-derivation.md` §4 and show the arithmetic. Where the source is silent, don't supply a number of your own: recommend a sweep range and say what would justify it, or mark the value as borrowed and the set as composite. Keep the distinction between simulated (TCAD) and measured data visible throughout.

Editable files: `docs/plans and specs/06-physics-calibration/device-model.md`. If you find an inconsistency between the YAML, the survey and the existing text of `device-model.md`, list it instead of silently picking one.

## Where the work goes

- **Write:** `docs/plans and specs/06-physics-calibration/device-model.md` — fill the Set A row in §7 and add a section with the full derivation table.
- **Raw data file (already exists, stays in raw device units):** `sw/fecim/parameter_sets/dualport_fefet_mlc.yaml`.
- **Source notes:** `docs/plans and specs/06-physics-calibration/literature-survey.md` §2 (set A extraction) and §4 (candidates for gaps).
- **Conversion math:** `docs/plans and specs/06-physics-calibration/cell-physics-derivation.md` §4.
- **Code path that applies it:** Natalie's D4 (`load_parameter_set`). Agree the numbers below with her so her tests pin the same values.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

The identity everything rests on: a threshold-voltage error maps to a weight error by `Δw [LSB] = 255 × ΔV_th / MW`, where MW is the memory window.

**From set A directly** (MW = 2.7 V, σ_Vth = 78.75 mV, 8 levels):

| Register | Source quantity | Arithmetic | Value | Confidence |
|---|---|---|---|---|
| `QUANT_LEVELS` | 8 states at P(error) < 1 % (Fig. 15d) | direct | **8** | direct (lower bound: 16 fails) |
| `QUANT_MULT` | — | `round(255 × 256 / 7)` | **9326** | exact |
| `D2D_SIGMA` | σ_Vth, MW | σ_w = 255 × 0.07875 / 2.7 = 7.44 LSB; `round(2.450 × 7.44)` | **18** | derived |

**Not in set A** (each needs a decision recorded in the document):

| Register | Situation | Recommended handling |
|---|---|---|
| `READ_SIGMA` | The paper is static-only; no cycle-to-cycle data | Sweep. As a reference point, De et al. report 17.7 mV; with set A's MW that's 1.67 LSB, `round(6.93 × 1.67)` = 12. Using it makes the set **composite**, so label it. |
| `STUCK_RATE` | No yield data | Sweep, e.g. 0 to 5 %; `STUCK_RATE = round(65536 × p)` |
| `atten_rom` (IR drop) | A circuit property, not a device property | Design choice: `α_i = 1 − κ·i/M`, coefficient `min(255, round(256·α_i))`; sweep κ. State the wire-resistance assumption behind the κ range. |
| `ADC_BITS` | A converter choice | Design choice: sweep 4 to 12 bits |

Write the section in this order: the provenance rule (one paragraph), the direct table, the gaps table, a "how to reproduce" note pointing at the YAML and at `load_parameter_set`, and the list of assumptions:

1. Set A is **TCAD-simulated**, calibrated to measured 22 nm FDSOI data; it isn't a measured array.
2. σ is the worst-case state (the LVT end); other states are tighter.
3. A signed weight is modelled as one quantity, not as a differential pair of cells.
4. D2D is triangular, not Gaussian.
5. IR drop is a per-row attenuation, not a resistor-network solution.

## Acceptance checks

- Every register value in the document has a source (paper, figure or section), the conversion arithmetic, and a confidence label from `device-model.md` §3.
- Recomputing each value by hand from the YAML gives the documented number.
- Anything borrowed from a second source is labelled composite, and anything unreported is listed as swept with its range.
- The five assumptions above are stated.
- Natalie's `load_parameter_set("dualport_fefet_mlc")` produces the same register values (D4's test).
- All four teammates have approved the PR.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Don't put register values in the YAML.** The files hold raw device quantities so a conversion change never leaves stale numbers behind (`device-model.md` §4).
- **`sw/fecim/plan-d.yml` is actually the `gf28_hkmg` parameter set** (Soliman et al., Nat. Commun. 2023: MW 1.2 V, 4 levels, σ 38 mV) saved under the wrong name and folder. It's set B's raw data. Ask Natalie to move it to `sw/fecim/parameter_sets/gf28_hkmg.yaml` (D1); documenting set B is optional for this deadline.
- The D2D register is an integer, so the realized σ is `0.408 × 18 = 7.35 LSB`, about 1 % below the target. Say so; C9 measures it.
- `QUANT_LEVELS = 8` is a lower bound from the paper (it tested 2, 4, 8, 16). The sweep over levels shows what 9 to 15 would give.
- Check the citation details against the paper itself before they go in a slide.

## Files to read first (attach or paste these if you're using a chatbot)

- `docs/plans and specs/06-physics-calibration/device-model.md`
- `docs/plans and specs/06-physics-calibration/cell-physics-derivation.md`
- `docs/plans and specs/06-physics-calibration/literature-survey.md`
- `sw/fecim/parameter_sets/dualport_fefet_mlc.yaml`, `sw/fecim/parameter_sets/README.md`, `sw/fecim/plan-d.yml`
- `docs/plans and specs/01-contract/protocol.md` (§6.3, §6.5)
- `docs/plans and specs/00-plan/fecim-plan.md` (§3.9)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

