# C2 — Read noise, IR drop and ADC in the model, plus golden vectors

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Wed 18 Nov |
| **Board bucket** | Bucket 4 — Lane C |
| **Board task** | C2: Read noise, IR drop, ADC in the model + golden vectors |
| **Needs first** | C1 (same patterns and helpers) |
| **Unblocks** | B2, B4, B5, C3, C5, D8 |
| **AI version** | `C2_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

C1 covered the effects that happen when a weight is *written*. This task covers the three that happen when the array is *read*, on every compute:

- **Read noise:** each time a cell is sensed, the measurement is a little off, and differently each time.
- **IR drop:** rows farther along a resistive wire get a weaker drive signal.
- **ADC quantization:** the column's answer is measured with a limited number of bits.

Once these are in, the model covers all six non-idealities, which is the semester-1 deliverable in software. And as with C1, the golden vectors that come out of it are what let Megan build three RTL modules against a fixed target in parallel.

Read noise is the delicate one. It comes from a pseudo-random generator in each lane, and the model has to produce the *same* random numbers in the *same* order as the hardware, or nothing matches. That forces the model's compute loop to walk rows and lanes in the hardware's order, and it forces one precise decision about timing that you and Megan have to make together.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Implement:** `read_noise_q()`, `ir_attenuate()` and `adc_quantize()` in `model/src/read_path.cpp` (signatures and rules in `model/include/fecim/read_path.h`; bodies throw today).
- **Use them:** `ModelExact::compute()` in `model/src/model_exact.cpp`. Add per-lane LFSR state to the class (`model/include/fecim/model_exact.h`, private section) and implement `ModelExact::reseed()`.
- **Primitives already done:** `lfsr_step()` and `lane_seed()` in `model/src/primitives.cpp`.
- **Unit tests:** new `model/tests/test_read_path.cpp` in `model/CMakeLists.txt`; update `test_model_exact_stub.cpp`.
- **Golden vectors:** new folders `tb/golden/read_noise/`, `tb/golden/ir_drop/`, `tb/golden/adc/`, each with an independent Python generator (`--check` mode), a README, and a C++ replay test.
- **Specs:** `03-lane-b-array/mac-array-spec.md` §5, §8, §9; `activation-buffer-spec.md` §6.2; `01-contract/protocol.md` §6.3, §6.5, §6.6.

## 3. How to build it

```cpp
std::int8_t read_noise_q(std::uint32_t lfsr, std::uint8_t read_sigma) {
    const int sum    = int(lfsr & 0xFF) + int((lfsr >> 8) & 0xFF)
                     + int((lfsr >> 16) & 0xFF) + int(lfsr >> 24);       // 0..1020
    const int ih9    = asr(sum - 510, 1);                                // -255..+255
    const int scaled = asr(ih9 * int(read_sigma), 9);                    // scale = reg / 512
    return std::int8_t(scaled > 127 ? 127 : scaled < -127 ? -127 : scaled);
}

std::uint8_t ir_attenuate(std::uint8_t act, std::uint8_t coeff) {
    return std::uint8_t((unsigned(act) * unsigned(coeff)) >> 8);         // Q0.8
}

std::int32_t adc_quantize(std::int32_t acc, std::uint8_t adc_bits) {
    const int sh = adc_bits >= ACC_USED_W ? 0 : ACC_USED_W - int(adc_bits);
    if (sh == 0) return acc;
    const std::int64_t code = asr64(std::int64_t(acc) + (std::int64_t(1) << (sh - 1)), sh);
    return std::int32_t(code * (std::int64_t(1) << sh));                 // multiply: no UB on negatives
}
```

`asr` is the explicit arithmetic-shift helper from C1, and `asr64` is the same thing for `std::int64_t`.

The compute loop must follow the hardware's order, because every lane's LFSR advances once per issued row:

```cpp
const int passes = (cfg.active_cols + NUM_LANES - 1) / NUM_LANES;
for (int p = 0; p < passes; ++p) {
    std::array<std::int32_t, NUM_LANES> acc{};                 // CLEAR at the start of each pass
    for (int r = 0; r < cfg.active_rows; ++r) {
        std::uint8_t a = act_[r];
        if (cfg.noise_en & NOISE_IR) a = ir_attenuate(a, atten_[r]);
        for (int l = 0; l < NUM_LANES; ++l) {
            lfsr_[l] = lfsr_step(lfsr_[l]);                    // every lane, every issued row
            int w_n = weights_[widx(r, p * NUM_LANES + l)];
            if (cfg.noise_en & NOISE_READ) w_n += read_noise_q(lfsr_[l], cfg.read_sigma);
            acc[l] += w_n * int(a);
        }
    }
    for (int l = 0; l < NUM_LANES; ++l) {                      // DRAIN, through the shared ADC
        const int c = p * NUM_LANES + l;
        const std::int32_t y = (cfg.noise_en & NOISE_ADC) ? adc_quantize(acc[l], adc_bits) : acc[l];
        if (c < cfg.active_cols) results[c] = y;
    }
}
```

Constructor and `reseed()`: `lfsr_[l] = lane_seed(noise_seed, l)`. At construction the seed register is 0.

**Vector files** (suggested):

```text
read_noise/  per lane in {0, 5, 63}: seed, sigma, then N noise_q samples in issue order,
             including one case with a reseed in the middle and one with seed 0
ir_drop/     all 256 x 256 (act, coeff) pairs -> attenuated value (65,536 bytes)
adc/         (acc, adc_bits) -> out, for bits in {0, 4, 8, 16, 23, 24, 31}, both signs, edges
```

## 4. How you know it's done

- `./build/model_tests` passes with tests for each function alone and for `compute()` with each effect alone and all together.
- With every enable clear, `compute()` returns exactly what it did before this change (compare against `model_ideal` over 1,000 random cases).
- `ADC_BITS` ≥ 24 is an exact no-op; ADC mean error over random inputs is near zero.
- Reproducibility: `reseed()`, compute, `reseed()`, compute gives identical results; two computes without a reseed between them differ when read noise is on.
- All three generators pass `--check`, and the replay tests agree with the model.
- No `NOISE_EN` bit throws any more.
- The read-noise alignment sentence (below) is agreed with Megan and written into `mac-array-spec.md` §5.5.

## 5. Watch out for

- **The alignment decision.** This sketch uses the LFSR state *after* the step triggered by a row for that row's noise sample, so the first row uses `lfsr_step(seed)`. That's the natural reading of the RTL in the spec (the LFSR advances on the edge ending cycle N; the sample is computed in N+1). Confirm with Megan before generating vectors. If you two pick the other convention, change one line here and one in her RTL.
- **Lanes advance even when their column is beyond `active_cols`**, and (per the spec's RTL) even when `NOISE_READ` is off. The loop above does both. If you gate either one, a later compute in the same session diverges from the hardware.
- **State persists across computes.** `lfsr_` must be a class member, not a local.
- **`NOISE_SEED` changes don't reload the LFSRs.** Only construction, `reseed()` and (later) `set_reg(REG_CTRL, 4)` do.
- **Neither default is an identity.** IR on with the reset table (all 255) scales by 255/256, and `adc_bits` below 24 always quantizes. "Off" means the enable bit is clear.
- `(x + half) >> sh` rounds negative ties toward +∞. That's what the RTL expression does, so keep it; don't replace it with a symmetric rounding helper.
- `fecim_demo` (`model/examples/demo_mvm.cpp`) and the CI step that runs it should still work; check whether the demo relied on a throw.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

