# AI prompt — C2: Read noise, IR drop and ADC in the model, plus golden vectors

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **C2 — Read noise, IR drop and ADC in the model, plus golden vectors**, owned by Ethan Ruddell, due Wed 18 Nov.

Implement the three read-time non-idealities in the bit-exact C++ model (read noise, IR drop, ADC quantization), restructure `ModelExact::compute()` to apply them in the hardware's order with persistent per-lane LFSR state, and generate golden vector files for each.

The model header comments give the arithmetic; follow them exactly, in integers only, and be explicit about shifts of negative values (C++17 leaves `>>` on negatives implementation-defined and `<<` on negatives undefined). The compute loop must iterate pass-major, row-minor, advancing every lane's LFSR once per issued row, because the RTL does. State, in a comment where the LFSR is stepped, which LFSR state is used for a row's noise sample, and call that out in your reply as a convention the RTL owner must confirm.

Write each golden-vector generator as an independent pure-Python implementation with a `--check` mode, following `tb/golden/mac_lane/`. Editable files: everything under `model/`, new folders `tb/golden/read_noise/`, `tb/golden/ir_drop/`, `tb/golden/adc/`, `.github/workflows/ci.yml`, and `docs/plans and specs/03-lane-b-array/mac-array-spec.md` §5.5 only to record the alignment convention. Don't touch `rtl/`.

## Where the work goes

- **Implement:** `read_noise_q()`, `ir_attenuate()` and `adc_quantize()` in `model/src/read_path.cpp` (signatures and rules in `model/include/fecim/read_path.h`; bodies throw today).
- **Use them:** `ModelExact::compute()` in `model/src/model_exact.cpp`. Add per-lane LFSR state to the class (`model/include/fecim/model_exact.h`, private section) and implement `ModelExact::reseed()`.
- **Primitives already done:** `lfsr_step()` and `lane_seed()` in `model/src/primitives.cpp`.
- **Unit tests:** new `model/tests/test_read_path.cpp` in `model/CMakeLists.txt`; update `test_model_exact_stub.cpp`.
- **Golden vectors:** new folders `tb/golden/read_noise/`, `tb/golden/ir_drop/`, `tb/golden/adc/`, each with an independent Python generator (`--check` mode), a README, and a C++ replay test.
- **Specs:** `03-lane-b-array/mac-array-spec.md` §5, §8, §9; `activation-buffer-spec.md` §6.2; `01-contract/protocol.md` §6.3, §6.5, §6.6.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```cpp
std::int8_t read_noise_q(std::uint32_t lfsr, std::uint8_t read_sigma) {
    const int sum    = int(lfsr & 0xFF) + int((lfsr >> 8) & 0xFF)
                     + int((lfsr >> 16) & 0xFF) + int(lfsr >> 24);       // 0..1020
    const int ih9    = asr(sum - 510, 1);                                // -255..+255
    const int scaled = asr(ih9 * int(read_sigma), 9);                    // scale = reg / 512
    return std::int8_t(scaled > 127 ? 127 : scaled < -127 ? -127 : scaled);
}

std::uint8_t ir_attenuate(std::uint8_t act, std::uint8_t coeff) {
    return std::uint8_t((unsigned(act) * unsigned(coeff)) >> 8);         // Q0.8
}

std::int32_t adc_quantize(std::int32_t acc, std::uint8_t adc_bits) {
    const int sh = adc_bits >= ACC_USED_W ? 0 : ACC_USED_W - int(adc_bits);
    if (sh == 0) return acc;
    const std::int64_t code = asr64(std::int64_t(acc) + (std::int64_t(1) << (sh - 1)), sh);
    return std::int32_t(code * (std::int64_t(1) << sh));                 // multiply: no UB on negatives
}
```

`asr` is the explicit arithmetic-shift helper from C1, and `asr64` is the same thing for `std::int64_t`.

The compute loop must follow the hardware's order, because every lane's LFSR advances once per issued row:

```cpp
const int passes = (cfg.active_cols + NUM_LANES - 1) / NUM_LANES;
for (int p = 0; p < passes; ++p) {
    std::array<std::int32_t, NUM_LANES> acc{};                 // CLEAR at the start of each pass
    for (int r = 0; r < cfg.active_rows; ++r) {
        std::uint8_t a = act_[r];
        if (cfg.noise_en & NOISE_IR) a = ir_attenuate(a, atten_[r]);
        for (int l = 0; l < NUM_LANES; ++l) {
            lfsr_[l] = lfsr_step(lfsr_[l]);                    // every lane, every issued row
            int w_n = weights_[widx(r, p * NUM_LANES + l)];
            if (cfg.noise_en & NOISE_READ) w_n += read_noise_q(lfsr_[l], cfg.read_sigma);
            acc[l] += w_n * int(a);
        }
    }
    for (int l = 0; l < NUM_LANES; ++l) {                      // DRAIN, through the shared ADC
        const int c = p * NUM_LANES + l;
        const std::int32_t y = (cfg.noise_en & NOISE_ADC) ? adc_quantize(acc[l], adc_bits) : acc[l];
        if (c < cfg.active_cols) results[c] = y;
    }
}
```

Constructor and `reseed()`: `lfsr_[l] = lane_seed(noise_seed, l)`. At construction the seed register is 0.

**Vector files** (suggested):

```text
read_noise/  per lane in {0, 5, 63}: seed, sigma, then N noise_q samples in issue order,
             including one case with a reseed in the middle and one with seed 0
ir_drop/     all 256 x 256 (act, coeff) pairs -> attenuated value (65,536 bytes)
adc/         (acc, adc_bits) -> out, for bits in {0, 4, 8, 16, 23, 24, 31}, both signs, edges
```

## Acceptance checks

- `./build/model_tests` passes with tests for each function alone and for `compute()` with each effect alone and all together.
- With every enable clear, `compute()` returns exactly what it did before this change (compare against `model_ideal` over 1,000 random cases).
- `ADC_BITS` ≥ 24 is an exact no-op; ADC mean error over random inputs is near zero.
- Reproducibility: `reseed()`, compute, `reseed()`, compute gives identical results; two computes without a reseed between them differ when read noise is on.
- All three generators pass `--check`, and the replay tests agree with the model.
- No `NOISE_EN` bit throws any more.
- The read-noise alignment sentence (below) is agreed with Megan and written into `mac-array-spec.md` §5.5.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **The alignment decision.** This sketch uses the LFSR state *after* the step triggered by a row for that row's noise sample, so the first row uses `lfsr_step(seed)`. That's the natural reading of the RTL in the spec (the LFSR advances on the edge ending cycle N; the sample is computed in N+1). Confirm with Megan before generating vectors. If you two pick the other convention, change one line here and one in her RTL.
- **Lanes advance even when their column is beyond `active_cols`**, and (per the spec's RTL) even when `NOISE_READ` is off. The loop above does both. If you gate either one, a later compute in the same session diverges from the hardware.
- **State persists across computes.** `lfsr_` must be a class member, not a local.
- **`NOISE_SEED` changes don't reload the LFSRs.** Only construction, `reseed()` and (later) `set_reg(REG_CTRL, 4)` do.
- **Neither default is an identity.** IR on with the reset table (all 255) scales by 255/256, and `adc_bits` below 24 always quantizes. "Off" means the enable bit is clear.
- `(x + half) >> sh` rounds negative ties toward +∞. That's what the RTL expression does, so keep it; don't replace it with a symmetric rounding helper.
- `fecim_demo` (`model/examples/demo_mvm.cpp`) and the CI step that runs it should still work; check whether the demo relied on a throw.

## Files to read first (attach or paste these if you're using a chatbot)

- `model/include/fecim/read_path.h`, `model/src/read_path.cpp`
- `model/include/fecim/model_exact.h`, `model/src/model_exact.cpp`, `model/src/model_ideal.cpp`
- `model/include/fecim/params.h`, `model/include/fecim/primitives.h`, `model/src/primitives.cpp`
- `model/tests/` (all), `model/CMakeLists.txt`, `model/examples/demo_mvm.cpp`
- `tb/golden/mac_lane/gen_mac_lane_vectors.py`, `tb/golden/mac_lane/README.md`
- `rtl/array/mac_lane.sv`, `rtl/array/read_noise.sv`, `rtl/fecim_pkg.sv` (read-only reference)
- `docs/plans and specs/03-lane-b-array/mac-array-spec.md` (§5, §8, §9)
- `docs/plans and specs/01-contract/protocol.md` (§6)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

