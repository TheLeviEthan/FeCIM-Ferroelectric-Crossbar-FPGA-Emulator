# C1 — model_exact D2D and stuck-at, plus write-path golden vectors

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Tue 17 Nov |
| **Board bucket** | Bucket 4 — Lane C |
| **Board task** | C1: `model_exact` D2D + stuck-at + write-path golden vectors |
| **Needs first** | nothing (start immediately) |
| **Unblocks** | B1, B3, C5, D4, D8 |
| **AI version** | `C1_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

The C++ model is the project's answer key. Megan's RTL is "correct" only if it produces exactly the numbers this model produces, and the hardware is "correct" only if it matches too. So the model has to exist *before* the RTL, and it has to be right, because nothing else checks it except its own tests.

This task adds the second and third non-idealities to the model. **Device-to-device variation** gives every cell a fixed, repeatable error in the conductance it lands on. **Stuck-at faults** make a fraction of cells ignore what's written. Both are derived from a hash of the cell's address, so they're permanent properties of a cell without storing anything.

The second half of the task is what unblocks the team: **golden vectors**. These are files of "for this input and these register settings, the stored weight must be exactly this". Megan's testbench reads them, so her RTL has a pass/fail target that doesn't depend on anyone's interpretation of the spec. This is also what makes AI-drafted RTL safe to use: the vectors, not the author, decide whether it's right.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Implement:** `cell_addr()`, `d2d_offset()` and `apply_stuck()` in `model/src/write_path.cpp`. Their signatures and rules are already written in `model/include/fecim/write_path.h`; the bodies currently throw.
- **Chain them:** `ModelExact::write_weight()` in `model/src/model_exact.cpp`, at the two `TODO(lane C, week 3)` comments.
- **Stop compute() refusing them:** in `ModelExact::compute()`, `kImplemented` is `NOISE_QUANT` only. D2D and stuck-at are baked into stored weights, so add `NOISE_D2D | NOISE_STUCK`.
- **Unit tests:** `model/tests/test_write_path.cpp`. Update `model/tests/test_model_exact_stub.cpp`, which expects these to throw.
- **Golden vectors:** new folder `tb/golden/write_path/` with `gen_write_path_vectors.py`, a `README.md`, and the generated `.hex` files. Follow the existing pattern in `tb/golden/mac_lane/`: an **independent Python generator** with a `--check` mode, and a C++ test that replays the files through the model.
- **Replay test:** new `model/tests/test_write_path_vectors.cpp`, added to `model/CMakeLists.txt`.
- **CI:** add `python3 tb/golden/write_path/gen_write_path_vectors.py --check` beside the existing `mac_lane` check.
- **Spec:** `03-lane-b-array/write-path-spec.md` §3, §5, §9.

## 3. How to build it

```cpp
// Arithmetic shift right that's explicit about negatives. In C++17, `>>` on a
// negative int is implementation-defined, so don't rely on it silently.
constexpr int asr(int x, int n) { return x >= 0 ? (x >> n) : ~((~x) >> n); }

std::uint16_t cell_addr(int row, int col) {
    return static_cast<std::uint16_t>(col * TILE_ROWS + row);       // same index as bulk_addr
}

std::int8_t d2d_offset(std::int8_t w_q, std::uint16_t addr,
                       std::uint32_t noise_seed, std::uint8_t d2d_sigma) {
    const std::uint16_t h = cell_hash16(addr, std::uint16_t(noise_seed) ^ SEED_D2D);
    const int ih9    = int(h & 0xFF) + int(h >> 8) - 255;           // triangular, -255..+255
    const int scaled = asr(ih9 * int(d2d_sigma), 8);                // scale = reg / 256
    const int sum    = int(w_q) + scaled;
    return std::int8_t(sum > 127 ? 127 : sum < -128 ? -128 : sum);  // saturate, never wrap
}

std::int8_t apply_stuck(std::int8_t w_var, std::uint16_t addr,
                        std::uint32_t noise_seed, std::uint32_t stuck_rate) {
    const std::uint16_t h_stuck = cell_hash16(addr, std::uint16_t(noise_seed) ^ SEED_STUCK);
    if (h_stuck >= (stuck_rate & 0xFFFFu)) return w_var;            // not stuck
    if (((stuck_rate >> 16) & 1u) == 0) return 0;                   // mode 0: stuck-at-zero
    const std::uint16_t h_d2d = cell_hash16(addr, std::uint16_t(noise_seed) ^ SEED_D2D);
    return (h_d2d & 0x8000u) ? std::int8_t(-127) : std::int8_t(127);   // mode 1: rail
}

// ModelExact::write_weight -- stage order is the physical programming order
if (cfg_.noise_en & NOISE_QUANT) w = quantize_weight(w, quant_levels, cfg_.quant_mult);
if (cfg_.noise_en & NOISE_D2D)   w = d2d_offset(w, cell_addr(row, col), cfg_.noise_seed, cfg_.d2d_sigma);
if (cfg_.noise_en & NOISE_STUCK) w = apply_stuck(w, cell_addr(row, col), cfg_.noise_seed, cfg_.stuck_rate);
```

**Golden vector files** (suggested; one case per line of words, like `tb/golden/mac_lane/cases.hex`):

```text
write_cases.hex :  word 0 = number of cases, then 9 words per case
    cell_addr  w_in  noise_en  quant_levels  quant_mult  d2d_sigma  noise_seed  stuck_rate  w_expected
hash_seed0.hex  :  cell_hash16(addr, 0 ^ SEED_D2D) for all 65,536 addresses
hash_sums.hex   :  for 8 seeds x 2 salts, a running XOR and sum over all 65,536 outputs
```

Cover: quant only (N ∈ {2, 3, 5, 8, 255}); D2D only (σ ∈ {0, 8, 32, 255}); stuck-at-zero and stuck-at-rail (rate ∈ {0, 1 %, 10 %, 100 %}); all three together; bypass; weights at ±127 and −128; several seeds including 0.

The generator re-implements the arithmetic in plain Python integers. It must not call the C++ model: two independent implementations agreeing is the point.

**Mutation check** before you ship: break the model on purpose and confirm a test fails each time. Use a wrapping add instead of saturation, the lane-local address instead of the global one, `>> 9` instead of `>> 8`, `h_stuck <=` instead of `<`, and the rail sign taken from `h_stuck`.

## 4. How you know it's done

- `./build/model_tests` passes with new tests for: triangular shape and zero mean of the D2D offset, saturation at both ends, determinism per seed, stuck fraction ≈ `rate / 65536`, rail versus zero, and "stuck overrides D2D and quant".
- Each of the five mutations above makes at least one test fail.
- `gen_write_path_vectors.py --check` passes, and `test_write_path_vectors.cpp` replays every case through `ModelExact` with zero mismatches.
- With all enables clear, `write_weight` is still a pure pass-through (the L0 gate depends on it).
- The vector files, their README (format, how to regenerate) and the CI check are merged **by Tuesday night**, even if more unit tests follow on Wednesday.
- Megan has confirmed she can read the files with `$readmemh`.

## 5. Watch out for

- **You're defining the rail sign.** The spec says "sign from `h_d2d[15]`" without saying which way. This sheet uses bit set → −127. Whatever you ship, write it into `write-path-spec.md` §5.3 so Megan's RTL has a sentence to follow, not just a vector to match.
- **Saturation limits differ by stage:** D2D saturates to +127 / −128 (per your own header), stuck-at-rail forces ±127.
- **The rail sign needs the D2D hash even when D2D is disabled.** Don't gate that hash on `NOISE_D2D`.
- **Weights are transformed at write time with the config in effect then.** Changing `NOISE_SEED` or `D2D_SIGMA` afterwards doesn't touch stored weights. That's correct and matches the RTL; make sure a test pins it, because the sweep harness (D5) relies on reloading weights after such changes.
- The exhaustive hash table for all eight seeds would be about 2.6 MB of text. One full table plus per-seed checksums keeps the repo small and still catches any single-bit difference.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

