# AI prompt — C1: model_exact D2D and stuck-at, plus write-path golden vectors

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **C1 — model_exact D2D and stuck-at, plus write-path golden vectors**, owned by Ethan Ruddell, due Tue 17 Nov.

Implement device-to-device variation and stuck-at faults in the bit-exact C++ model, and generate the golden vector files that the RTL write path will be tested against.

Three parts: (1) fill in `cell_addr`, `d2d_offset` and `apply_stuck` in `model/src/write_path.cpp` exactly as their header comments specify, chain them in `ModelExact::write_weight`, and widen the implemented-mask in `compute()`; (2) add unit tests, update the stub test that expects a throw, and run a mutation check (introduce each listed bug, confirm a test fails, revert) and report the result per mutation; (3) write `tb/golden/write_path/gen_write_path_vectors.py` as an independent pure-Python implementation with a `--check` mode, the vector files, a README describing the format, a C++ replay test, and the CI step.

Integer arithmetic only: no floating point, no `<cmath>`. Be explicit about arithmetic right shifts of negative values. Editable files: everything under `model/`, `tb/golden/write_path/` (new), `.github/workflows/ci.yml`, and `docs/plans and specs/03-lane-b-array/write-path-spec.md` only to record the stuck-at-rail sign convention. Don't touch `rtl/`.

## Where the work goes

- **Implement:** `cell_addr()`, `d2d_offset()` and `apply_stuck()` in `model/src/write_path.cpp`. Their signatures and rules are already written in `model/include/fecim/write_path.h`; the bodies currently throw.
- **Chain them:** `ModelExact::write_weight()` in `model/src/model_exact.cpp`, at the two `TODO(lane C, week 3)` comments.
- **Stop compute() refusing them:** in `ModelExact::compute()`, `kImplemented` is `NOISE_QUANT` only. D2D and stuck-at are baked into stored weights, so add `NOISE_D2D | NOISE_STUCK`.
- **Unit tests:** `model/tests/test_write_path.cpp`. Update `model/tests/test_model_exact_stub.cpp`, which expects these to throw.
- **Golden vectors:** new folder `tb/golden/write_path/` with `gen_write_path_vectors.py`, a `README.md`, and the generated `.hex` files. Follow the existing pattern in `tb/golden/mac_lane/`: an **independent Python generator** with a `--check` mode, and a C++ test that replays the files through the model.
- **Replay test:** new `model/tests/test_write_path_vectors.cpp`, added to `model/CMakeLists.txt`.
- **CI:** add `python3 tb/golden/write_path/gen_write_path_vectors.py --check` beside the existing `mac_lane` check.
- **Spec:** `03-lane-b-array/write-path-spec.md` §3, §5, §9.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```cpp
// Arithmetic shift right that's explicit about negatives. In C++17, `>>` on a
// negative int is implementation-defined, so don't rely on it silently.
constexpr int asr(int x, int n) { return x >= 0 ? (x >> n) : ~((~x) >> n); }

std::uint16_t cell_addr(int row, int col) {
    return static_cast<std::uint16_t>(col * TILE_ROWS + row);       // same index as bulk_addr
}

std::int8_t d2d_offset(std::int8_t w_q, std::uint16_t addr,
                       std::uint32_t noise_seed, std::uint8_t d2d_sigma) {
    const std::uint16_t h = cell_hash16(addr, std::uint16_t(noise_seed) ^ SEED_D2D);
    const int ih9    = int(h & 0xFF) + int(h >> 8) - 255;           // triangular, -255..+255
    const int scaled = asr(ih9 * int(d2d_sigma), 8);                // scale = reg / 256
    const int sum    = int(w_q) + scaled;
    return std::int8_t(sum > 127 ? 127 : sum < -128 ? -128 : sum);  // saturate, never wrap
}

std::int8_t apply_stuck(std::int8_t w_var, std::uint16_t addr,
                        std::uint32_t noise_seed, std::uint32_t stuck_rate) {
    const std::uint16_t h_stuck = cell_hash16(addr, std::uint16_t(noise_seed) ^ SEED_STUCK);
    if (h_stuck >= (stuck_rate & 0xFFFFu)) return w_var;            // not stuck
    if (((stuck_rate >> 16) & 1u) == 0) return 0;                   // mode 0: stuck-at-zero
    const std::uint16_t h_d2d = cell_hash16(addr, std::uint16_t(noise_seed) ^ SEED_D2D);
    return (h_d2d & 0x8000u) ? std::int8_t(-127) : std::int8_t(127);   // mode 1: rail
}

// ModelExact::write_weight -- stage order is the physical programming order
if (cfg_.noise_en & NOISE_QUANT) w = quantize_weight(w, quant_levels, cfg_.quant_mult);
if (cfg_.noise_en & NOISE_D2D)   w = d2d_offset(w, cell_addr(row, col), cfg_.noise_seed, cfg_.d2d_sigma);
if (cfg_.noise_en & NOISE_STUCK) w = apply_stuck(w, cell_addr(row, col), cfg_.noise_seed, cfg_.stuck_rate);
```

**Golden vector files** (suggested; one case per line of words, like `tb/golden/mac_lane/cases.hex`):

```text
write_cases.hex :  word 0 = number of cases, then 9 words per case
    cell_addr  w_in  noise_en  quant_levels  quant_mult  d2d_sigma  noise_seed  stuck_rate  w_expected
hash_seed0.hex  :  cell_hash16(addr, 0 ^ SEED_D2D) for all 65,536 addresses
hash_sums.hex   :  for 8 seeds x 2 salts, a running XOR and sum over all 65,536 outputs
```

Cover: quant only (N ∈ {2, 3, 5, 8, 255}); D2D only (σ ∈ {0, 8, 32, 255}); stuck-at-zero and stuck-at-rail (rate ∈ {0, 1 %, 10 %, 100 %}); all three together; bypass; weights at ±127 and −128; several seeds including 0.

The generator re-implements the arithmetic in plain Python integers. It must not call the C++ model: two independent implementations agreeing is the point.

**Mutation check** before you ship: break the model on purpose and confirm a test fails each time. Use a wrapping add instead of saturation, the lane-local address instead of the global one, `>> 9` instead of `>> 8`, `h_stuck <=` instead of `<`, and the rail sign taken from `h_stuck`.

## Acceptance checks

- `./build/model_tests` passes with new tests for: triangular shape and zero mean of the D2D offset, saturation at both ends, determinism per seed, stuck fraction ≈ `rate / 65536`, rail versus zero, and "stuck overrides D2D and quant".
- Each of the five mutations above makes at least one test fail.
- `gen_write_path_vectors.py --check` passes, and `test_write_path_vectors.cpp` replays every case through `ModelExact` with zero mismatches.
- With all enables clear, `write_weight` is still a pure pass-through (the L0 gate depends on it).
- The vector files, their README (format, how to regenerate) and the CI check are merged **by Tuesday night**, even if more unit tests follow on Wednesday.
- Megan has confirmed she can read the files with `$readmemh`.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **You're defining the rail sign.** The spec says "sign from `h_d2d[15]`" without saying which way. This sheet uses bit set → −127. Whatever you ship, write it into `write-path-spec.md` §5.3 so Megan's RTL has a sentence to follow, not just a vector to match.
- **Saturation limits differ by stage:** D2D saturates to +127 / −128 (per your own header), stuck-at-rail forces ±127.
- **The rail sign needs the D2D hash even when D2D is disabled.** Don't gate that hash on `NOISE_D2D`.
- **Weights are transformed at write time with the config in effect then.** Changing `NOISE_SEED` or `D2D_SIGMA` afterwards doesn't touch stored weights. That's correct and matches the RTL; make sure a test pins it, because the sweep harness (D5) relies on reloading weights after such changes.
- The exhaustive hash table for all eight seeds would be about 2.6 MB of text. One full table plus per-seed checksums keeps the repo small and still catches any single-bit difference.

## Files to read first (attach or paste these if you're using a chatbot)

- `model/include/fecim/write_path.h`, `model/src/write_path.cpp`
- `model/include/fecim/model_exact.h`, `model/src/model_exact.cpp`
- `model/include/fecim/params.h`, `model/include/fecim/primitives.h`, `model/src/primitives.cpp`
- `model/tests/test_write_path.cpp`, `model/tests/test_model_exact_stub.cpp`, `model/tests/test_harness.h`, `model/tests/test_mac_lane_vectors.cpp`, `model/CMakeLists.txt`
- `tb/golden/mac_lane/gen_mac_lane_vectors.py` and `tb/golden/mac_lane/README.md` (the pattern to follow)
- `rtl/fecim_pkg.sv` (for `cell_hash16` and the seeds)
- `.github/workflows/ci.yml`
- `docs/plans and specs/03-lane-b-array/write-path-spec.md`

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

