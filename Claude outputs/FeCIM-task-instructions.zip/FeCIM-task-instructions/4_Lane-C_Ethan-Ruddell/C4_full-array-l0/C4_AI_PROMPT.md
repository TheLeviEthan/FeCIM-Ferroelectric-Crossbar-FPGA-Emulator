# AI prompt — C4: Full-array L0: Verilated mac_array against the model, 1,000 matrices

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **C4 — Full-array L0: Verilated mac_array against the model, 1,000 matrices**, owned by Ethan Ruddell, due Sat 21 Nov.

Extend the L0 co-simulation gate from one MAC lane to the full 64-lane `mac_array`: a Verilator harness that programs the same random weights into the RTL and the C++ model, runs a full two-pass matrix-vector multiply on both in lockstep, compares every lane's internal state every cycle, and finally checks RTL == `model_exact` == `model_ideal`.

Model the new harness on `model/cosim/run_l0.cpp` and reuse its conventions (seeded RNG, argument handling, failure messages, exit code). Use `--public-flat-rw` to read lane internals so the RTL is untouched. Add the Makefile target in both build branches and document usage.

You may not be able to run Verilator. If not, deliver the code, state clearly that it's uncompiled, and list the exact commands to build and run it along with the most likely compile errors (especially around generated signal names) and how to fix them. Editable files: `model/cosim/` and `.github/workflows/ci.yml`. Don't touch `rtl/`.

## Where the work goes

- **New harness:** `model/cosim/run_l0_array.cpp`, modelled on `model/cosim/run_l0.cpp`.
- **Makefile:** a `run_l0_array` target in `model/cosim/Makefile`, Verilating `rtl/fecim_pkg.sv`, `rtl/array/mac_array.sv`, `rtl/array/mac_lane.sv`, `rtl/array/read_noise.sv` with `--top-module mac_array`. The Makefile has two branches (in-place build, and a staged build for paths containing a space); the new target needs both.
- **README:** add usage to `model/cosim/README.md`.
- **CI:** a short run in the `cosim` job (C7).
- **Specs:** `04-lane-c-verification/model-verification-design.md` §3.1, §5; `03-lane-b-array/mac-array-spec.md` §12 test 2.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```cpp
for (int m = 0; m < n_matrices; ++m) {
    // 1. program: same weights into DUT (lane_we / lane_sel / lane_waddr / lane_wdata) and model
    // 2. activations: the harness plays act_buffer, so it drives act_bcast with the 2-cycle delay
    // 3. run both, one clock at a time
    model.start_compute();
    while (model.busy()) {
        drive_dut_from_sequencer(dut, model);      // seq_cnt, acc_clear, acc_en, shift_en, act_bcast
        tick(dut);  model.step();  ++cycle;
        for (int l = 0; l < NUM_LANES; ++l) {
            const auto p = model.lane(l);          // compare upstream-first:
            check(dut_w_n(l)  == p.w_n,  "w_n",  l, cycle);   //   the first mismatch
            check(dut_prod(l) == p.prod, "prod", l, cycle);   //   explains the ones
            check(dut_acc(l)  == p.acc,  "acc",  l, cycle);   //   after it
        }
    }
    // 4. three-way check on the finished results
    check(model.results() == model_ideal_results);
}
```

Reading inside the lanes: build with Verilator's `--public-flat-rw`, which exposes internal signals through the generated root object without touching the RTL. The generated names for a generate block look like `mac_array__DOT__g_lane__BRA__5__KET____DOT__u_lane__DOT__acc`; wrap them in three small accessor functions so the rest of the harness stays readable.

On failure, print the matrix index, cycle, lane, signal, expected and actual, then stop.

Mutation check, as for the single-lane harness: inject a handful of bugs into a scratch copy of the RTL (sign-extend the activation, swap `lane_sel` bits, shorten the pipeline hold, reverse the drain direction) and confirm each is caught and reported at a sensible cycle.

## Acceptance checks

- `./model/cosim/run_l0_array 1 1000` passes: 1,000 random 128×128 matrices, `NOISE_EN = 0`, every lane compared every cycle, plus RTL == `model_exact` == `model_ideal` on the results.
- The same harness passes with tile sizes 8×8, 48×48 and 64×64.
- Each injected mutation is caught; the list and the reported cycle for each go in the PR description.
- Runtime is recorded in the README, and a short version (about 50 matrices) runs in CI.
- The staged-build branch of the Makefile works from a path containing a space.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **If per-cycle internal access fights you for more than an hour,** fall back to comparing each lane's accumulator as it emerges from the drain chain, and the results at the end. That still proves L0. Note in the README that it's end-of-pass comparison, and come back to per-cycle afterwards.
- **`mac_lane`'s ports change in B4** (noise inputs). Wait for that merge or expect to update the harness, and update the single-lane `run_l0.cpp` in the same PR.
- This harness plays the roles of `control_fsm` and `act_buffer`, so it does *not* test them. That's C5's job. Don't let a green L0 here be read as "the full design works".
- Keep the activation delay in one named constant next to a comment that points at `activation-buffer-spec.md` §4.

## Files to read first (attach or paste these if you're using a chatbot)

- `model/cosim/run_l0.cpp`, `model/cosim/Makefile`, `model/cosim/README.md`
- `model/include/fecim/model_exact.h`, `model/include/fecim/model_ideal.h`, `model/include/fecim/params.h`
- `rtl/fecim_pkg.sv`, `rtl/array/mac_array.sv`, `rtl/array/mac_lane.sv`, `rtl/array/read_noise.sv`
- `.github/workflows/ci.yml`
- `docs/plans and specs/04-lane-c-verification/model-verification-design.md`
- `docs/plans and specs/03-lane-b-array/mac-array-spec.md` (§12)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

