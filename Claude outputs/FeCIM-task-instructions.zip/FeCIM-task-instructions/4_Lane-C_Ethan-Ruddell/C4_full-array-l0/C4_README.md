# C4 — Full-array L0: Verilated mac_array against the model, 1,000 matrices

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Sat 21 Nov |
| **Board bucket** | Bucket 4 — Lane C |
| **Board task** | C4: Full-array L0: Verilated `mac_array` vs model, 1,000 × 128×128 |
| **Needs first** | C3; B4 merged (so the lane ports are final) |
| **Unblocks** | C5, G2, B8 test 2 |
| **AI version** | `C4_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

L0 is the gate everything else stands on: with every non-ideality switched off, the hardware array must compute *exactly* the same integers as the model, which must equal plain matrix arithmetic. If the clean path isn't exact, then every later statement of the form "this accuracy drop is caused by read noise" is unfounded, because the drop might just be a datapath bug.

We already have L0 for a single lane. This task extends it to all 64 lanes working together, over a thousand random full-size matrices, compared every clock cycle. That adds what a single lane can't show: that weights are routed to the right lane, that both passes work, and that the 64-stage drain chain delivers each column's sum to the right place.

Zero tolerance is the point. One mismatch in a hundred million comparisons is a bug, and this test is designed to find it and tell you where it is.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **New harness:** `model/cosim/run_l0_array.cpp`, modelled on `model/cosim/run_l0.cpp`.
- **Makefile:** a `run_l0_array` target in `model/cosim/Makefile`, Verilating `rtl/fecim_pkg.sv`, `rtl/array/mac_array.sv`, `rtl/array/mac_lane.sv`, `rtl/array/read_noise.sv` with `--top-module mac_array`. The Makefile has two branches (in-place build, and a staged build for paths containing a space); the new target needs both.
- **README:** add usage to `model/cosim/README.md`.
- **CI:** a short run in the `cosim` job (C7).
- **Specs:** `04-lane-c-verification/model-verification-design.md` §3.1, §5; `03-lane-b-array/mac-array-spec.md` §12 test 2.

## 3. How to build it

```cpp
for (int m = 0; m < n_matrices; ++m) {
    // 1. program: same weights into DUT (lane_we / lane_sel / lane_waddr / lane_wdata) and model
    // 2. activations: the harness plays act_buffer, so it drives act_bcast with the 2-cycle delay
    // 3. run both, one clock at a time
    model.start_compute();
    while (model.busy()) {
        drive_dut_from_sequencer(dut, model);      // seq_cnt, acc_clear, acc_en, shift_en, act_bcast
        tick(dut);  model.step();  ++cycle;
        for (int l = 0; l < NUM_LANES; ++l) {
            const auto p = model.lane(l);          // compare upstream-first:
            check(dut_w_n(l)  == p.w_n,  "w_n",  l, cycle);   //   the first mismatch
            check(dut_prod(l) == p.prod, "prod", l, cycle);   //   explains the ones
            check(dut_acc(l)  == p.acc,  "acc",  l, cycle);   //   after it
        }
    }
    // 4. three-way check on the finished results
    check(model.results() == model_ideal_results);
}
```

Reading inside the lanes: build with Verilator's `--public-flat-rw`, which exposes internal signals through the generated root object without touching the RTL. The generated names for a generate block look like `mac_array__DOT__g_lane__BRA__5__KET____DOT__u_lane__DOT__acc`; wrap them in three small accessor functions so the rest of the harness stays readable.

On failure, print the matrix index, cycle, lane, signal, expected and actual, then stop.

Mutation check, as for the single-lane harness: inject a handful of bugs into a scratch copy of the RTL (sign-extend the activation, swap `lane_sel` bits, shorten the pipeline hold, reverse the drain direction) and confirm each is caught and reported at a sensible cycle.

## 4. How you know it's done

- `./model/cosim/run_l0_array 1 1000` passes: 1,000 random 128×128 matrices, `NOISE_EN = 0`, every lane compared every cycle, plus RTL == `model_exact` == `model_ideal` on the results.
- The same harness passes with tile sizes 8×8, 48×48 and 64×64.
- Each injected mutation is caught; the list and the reported cycle for each go in the PR description.
- Runtime is recorded in the README, and a short version (about 50 matrices) runs in CI.
- The staged-build branch of the Makefile works from a path containing a space.

## 5. Watch out for

- **If per-cycle internal access fights you for more than an hour,** fall back to comparing each lane's accumulator as it emerges from the drain chain, and the results at the end. That still proves L0. Note in the README that it's end-of-pass comparison, and come back to per-cycle afterwards.
- **`mac_lane`'s ports change in B4** (noise inputs). Wait for that merge or expect to update the harness, and update the single-lane `run_l0.cpp` in the same PR.
- This harness plays the roles of `control_fsm` and `act_buffer`, so it does *not* test them. That's C5's job. Don't let a green L0 here be read as "the full design works".
- Keep the activation delay in one named constant next to a comment that points at `activation-buffer-spec.md` §4.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

