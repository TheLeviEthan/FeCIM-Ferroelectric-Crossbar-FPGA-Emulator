# C10 — Coverage matrix closed and the verification report

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Sat 28 Nov |
| **Board bucket** | Bucket 4 — Lane C |
| **Board task** | C10: Coverage matrix closed + verification report |
| **Needs first** | C4, C5, C8, C9, B8 |
| **Unblocks** | P2 (verification slide), X4 (final repo state) |
| **AI version** | `C10_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

A design isn't verified because its authors feel confident. It's verified when someone else can look at a list of what had to be true, see the test that checked each item, and see the evidence that the test passed.

The tool we'd normally use for that (functional coverage in a commercial simulator) isn't available in the free tools this project uses. So we do it by hand: a **coverage matrix**. Each row is a configuration (clean, each non-ideality alone, all together, several tile sizes). Each column is a kind of test (directed, random, corner case, on hardware). Each cell is either a link to the run that passed, or an honest explanation of why it's empty. "We tested a lot" becomes a table with no blanks.

The **verification report** tells the story around the table: the five levels of equivalence we defined and what each one proves, the bugs the process caught (including bugs in our own specs), and what we *didn't* verify. That last part is what makes the rest believable.

This is one of the course's required documents, and it's the backing for the verification slide.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Coverage matrix:** fill in `docs/plans and specs/04-lane-c-verification/model-verification-design.md` §6.1 and §6.2, or keep the filled copy as new `docs/verification/coverage-matrix.md` and link it from there.
- **Report:** new `docs/reports/verification-report.md`.
- **Evidence to link:** CI runs; `model/cosim/README.md` (commands and runtimes); `results/l4/` (hardware logs); `results/l3/summary.md`; `docs/verification/array-tests.md` (Megan's B8); `results/soak/` (Zhiting's A8).
- **Definitions:** `model-verification-design.md` §3 (L0–L4).

## 3. How to build it

**The matrix** (from §6.1). Each ✓ becomes a link plus the command that produced it:

| Config | Directed | Random ×1000 | Corner | Hardware |
|---|---|---|---|---|
| Clean, 128×128 | | | | |
| Quant only, N ∈ {2, 3, 5, 8, 255} | | | | |
| D2D only, σ ∈ {0, 8, 32, 255} | | | | |
| Read noise only | | | | |
| Stuck only, rate ∈ {0, 1 %, 10 %} | | | | |
| ADC only, bits ∈ {4, 8, 16, 32} | | | | |
| IR only | | | | |
| All enabled | | | | |
| Tile 8×8, 32×32, 48×48, 128×128 | | | n/a | |

Where each column's evidence comes from: *Directed* — golden-vector testbenches and B7; *Random* — C4 (clean) and C5 (L1/L2); *Corner* — §6.2's list mapped to named tests; *Hardware* — C8's log.

**Report outline:**

1. **Approach.** Two models (`model_ideal` as the plain-math oracle, `model_exact` as the RTL's bit-exact twin) and why.
2. **The equivalence hierarchy.** One paragraph each for L0, L1, L2, L4 (exact) and L3 (statistical), with what a failure at that level would mean.
3. **Coverage matrix,** with links.
4. **Array property tests** (B8's table): noise moments, decorrelation, headroom, drain order, ADC rounding, IR factorization.
5. **Statistical validation** (C9's summary), kept in its own section.
6. **Bugs found and how.** For example: the two errors in the write-path spec's own code found when the model was written; the mutation tests showing each harness catches injected bugs; whatever C5 and B7 turned up. For each: what, how it was caught, at which level.
7. **Robustness.** The soak test result.
8. **Known limitations.** What isn't verified or is approximated: IR drop as per-row attenuation; triangular D2D; read noise not a true Irwin–Hall distribution; single clock, one board model; anything left unticked in the matrix.
9. **How to reproduce.** The commands, the commit, the `BUILD_ID`.

## 4. How you know it's done

- Every cell of the matrix is a link to evidence at a stated commit, or an explained gap. No bare ticks.
- Every corner case in §6.2 maps to a named test.
- The report distinguishes exact levels from the statistical one everywhere they appear.
- Megan and Zhiting have each reviewed the sections that describe their modules and tests.
- A reader can run the commands in section 9 on a clean clone and get the same results.

## 5. Watch out for

- **The spec's matrix says "ADC only, bits ∈ {4, 8, 16, 32}".** `ADC_BITS` is a 5-bit register (0–31) and anything ≥ 24 is a no-op, so "32" can't be written. Use {4, 8, 16, 24} and correct the spec row.
- **Don't tick a cell from memory.** If the run isn't linked, re-run it. A coverage matrix with one cell that turns out to be wrong discredits the whole table.
- Evidence must be from the cutoff commit (or say which commit). Results from before a later RTL change don't count for the final build.
- Limitations aren't an apology. State them plainly; the design-corrections slide (P3) uses the same list.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

