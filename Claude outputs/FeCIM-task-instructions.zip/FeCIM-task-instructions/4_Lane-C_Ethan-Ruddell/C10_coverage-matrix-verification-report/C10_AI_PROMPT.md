# AI prompt — C10: Coverage matrix closed and the verification report

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **C10 — Coverage matrix closed and the verification report**, owned by Ethan Ruddell, due Sat 28 Nov.

Assemble the verification evidence into two documents: the filled-in coverage matrix and the verification report.

You'll be given the matrix template, the test logs or their summaries, and the supporting documents. For each matrix cell, cite the specific run (command, commit, result) that supports it; if the material you were given doesn't contain evidence for a cell, leave it marked as missing and list it, and don't infer a pass. Write the report for a reader who's a competent engineer but new to this project: define L0–L4 before using them, keep the statistical validation (L3) separate from the exact-equivalence levels, describe the bugs the process found, and state the limitations plainly.

Editable files: `docs/reports/verification-report.md` (new), `docs/verification/coverage-matrix.md` (new), and §6 of `model-verification-design.md`.

## Where the work goes

- **Coverage matrix:** fill in `docs/plans and specs/04-lane-c-verification/model-verification-design.md` §6.1 and §6.2, or keep the filled copy as new `docs/verification/coverage-matrix.md` and link it from there.
- **Report:** new `docs/reports/verification-report.md`.
- **Evidence to link:** CI runs; `model/cosim/README.md` (commands and runtimes); `results/l4/` (hardware logs); `results/l3/summary.md`; `docs/verification/array-tests.md` (Megan's B8); `results/soak/` (Zhiting's A8).
- **Definitions:** `model-verification-design.md` §3 (L0–L4).

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

**The matrix** (from §6.1). Each ✓ becomes a link plus the command that produced it:

| Config | Directed | Random ×1000 | Corner | Hardware |
|---|---|---|---|---|
| Clean, 128×128 | | | | |
| Quant only, N ∈ {2, 3, 5, 8, 255} | | | | |
| D2D only, σ ∈ {0, 8, 32, 255} | | | | |
| Read noise only | | | | |
| Stuck only, rate ∈ {0, 1 %, 10 %} | | | | |
| ADC only, bits ∈ {4, 8, 16, 32} | | | | |
| IR only | | | | |
| All enabled | | | | |
| Tile 8×8, 32×32, 48×48, 128×128 | | | n/a | |

Where each column's evidence comes from: *Directed* — golden-vector testbenches and B7; *Random* — C4 (clean) and C5 (L1/L2); *Corner* — §6.2's list mapped to named tests; *Hardware* — C8's log.

**Report outline:**

1. **Approach.** Two models (`model_ideal` as the plain-math oracle, `model_exact` as the RTL's bit-exact twin) and why.
2. **The equivalence hierarchy.** One paragraph each for L0, L1, L2, L4 (exact) and L3 (statistical), with what a failure at that level would mean.
3. **Coverage matrix,** with links.
4. **Array property tests** (B8's table): noise moments, decorrelation, headroom, drain order, ADC rounding, IR factorization.
5. **Statistical validation** (C9's summary), kept in its own section.
6. **Bugs found and how.** For example: the two errors in the write-path spec's own code found when the model was written; the mutation tests showing each harness catches injected bugs; whatever C5 and B7 turned up. For each: what, how it was caught, at which level.
7. **Robustness.** The soak test result.
8. **Known limitations.** What isn't verified or is approximated: IR drop as per-row attenuation; triangular D2D; read noise not a true Irwin–Hall distribution; single clock, one board model; anything left unticked in the matrix.
9. **How to reproduce.** The commands, the commit, the `BUILD_ID`.

## Acceptance checks

- Every cell of the matrix is a link to evidence at a stated commit, or an explained gap. No bare ticks.
- Every corner case in §6.2 maps to a named test.
- The report distinguishes exact levels from the statistical one everywhere they appear.
- Megan and Zhiting have each reviewed the sections that describe their modules and tests.
- A reader can run the commands in section 9 on a clean clone and get the same results.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **The spec's matrix says "ADC only, bits ∈ {4, 8, 16, 32}".** `ADC_BITS` is a 5-bit register (0–31) and anything ≥ 24 is a no-op, so "32" can't be written. Use {4, 8, 16, 24} and correct the spec row.
- **Don't tick a cell from memory.** If the run isn't linked, re-run it. A coverage matrix with one cell that turns out to be wrong discredits the whole table.
- Evidence must be from the cutoff commit (or say which commit). Results from before a later RTL change don't count for the final build.
- Limitations aren't an apology. State them plainly; the design-corrections slide (P3) uses the same list.

## Files to read first (attach or paste these if you're using a chatbot)

- `docs/plans and specs/04-lane-c-verification/model-verification-design.md`
- `model/cosim/README.md`, `tb/golden/*/README.md`
- `docs/verification/array-tests.md` (B8), `results/l3/summary.md` (C9), the `results/l4/` log (C8), the `results/soak/` log (A8)
- Links or summaries of the relevant CI runs
- `docs/plans and specs/01-contract/hardware-verification-errata.md`, `docs/plans and specs/00-plan/consistency-audit.md` (for the "bugs found" section)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

