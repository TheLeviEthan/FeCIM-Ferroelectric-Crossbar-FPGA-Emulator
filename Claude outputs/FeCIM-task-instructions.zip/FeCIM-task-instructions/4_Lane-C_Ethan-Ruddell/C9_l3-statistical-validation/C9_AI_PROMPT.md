# AI prompt — C9: L3 statistical validation

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **C9 — L3 statistical validation**, owned by Ethan Ruddell, due Fri 27 Nov.

Write the L3 statistical validation: a Python script that programs the emulated array using the calibrated settings for parameter set A, measures what was actually stored or read (level count and spacing, device-to-device spread and shape, stuck fraction, read-noise standard deviation, seed-to-seed spread), and compares each against the value expected from the published device data, with pass criteria stated up front.

Use the one-hot-activation trick to read stored weights back through the normal result path so the same script runs on the `sim` backend and on hardware. Produce a CSV, histogram images and a provenance JSON sidecar under `results/l3/`, plus a short Markdown summary table. Convert weight-LSB quantities back to the paper's units for the comparison, and keep statistical claims proportionate: report sample sizes and the tolerance used.

Use the host API as it exists in the files provided, and name any call you need that's missing. Editable files: `sw/examples/l3_validation.py` (new) and files under `results/l3/`.

## Where the work goes

- **New script:** `sw/examples/l3_validation.py`, using `Crossbar(backend="sim")` and, where a board is available, `backend="fpga"`.
- **Inputs:** `sw/fecim/parameter_sets/dualport_fefet_mlc.yaml` through `load_parameter_set` (D4), and the targets in `device-model.md` (C6).
- **Outputs:** `results/l3/` — CSV of measured statistics, histogram PNGs, a provenance JSON, and a short `summary.md` table for the slides and the verification report.
- **Specs:** `04-lane-c-verification/model-verification-design.md` §3 (L3 definition), §7.5 (sweeping what the literature doesn't pin down).

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

**Reading stored weights back, even from hardware.** With every read-time effect off, set one activation to 1 and all others to 0. Then `result[c] = w_stored[r][c]`, exactly. 128 computes read back the whole tile.

```python
def read_back_weights(xbar, rows, cols):
    W = np.zeros((rows, cols), dtype=np.int32)
    for r in range(rows):
        x = np.zeros(rows, dtype=np.uint8); x[r] = 1
        xbar.write_activations_raw(x); xbar.compute()
        W[r] = xbar.read_results()[:cols]
    return W
```

**Checks, with the pass criterion written down before running:**

| Property | Method | Expected | Pass if |
|---|---|---|---|
| Level count | quant only, N = 8; write all 256 values | exactly 8 distinct stored values, even spacing | exact |
| D2D spread | D2D only, σ reg = 18; program a mid-range value into all 16,384 cells; read back | σ_w = 0.408 × 18 = 7.35 LSB → 77.8 mV at MW = 2.7 V | within 3 % of 78.75 mV |
| D2D shape | same data | triangular: zero mean, bounded at ±(255 × 18 / 256) ≈ ±18 LSB | mean within ±0.2 LSB; no sample outside the bound |
| Stuck fraction | stuck only, rates 1 %, 5 %, 10 % | `rate / 65536` | within 3 binomial standard errors |
| Read-noise σ | read noise only; same compute repeated 1,000 times without reseeding; one-hot activation of 1 | σ = 0.144 × `READ_SIGMA` LSB | within 5 % |
| Seed-to-seed spread | repeat the D2D measurement for 10 seeds | — | report the range; it becomes the plot band |

Convert LSB back to device units with `ΔV_th = Δw × MW / 255` so the comparison is in the paper's units.

Use a mid-range programmed value (for example 0) for the D2D measurement. Near ±127 the saturation clips one tail and the measured σ shrinks; show that effect in one extra histogram, since it's a real property of the model.

Then, for the plots: for each sweep axis the paper doesn't fix (read noise, stuck rate, IR κ, ADC bits), record the range to sweep and the seed-to-seed spread at a few points.

## Acceptance checks

- Every row of the table has a measured value, the expected value, and pass or fail against a criterion that was written first.
- The measured D2D σ, converted to millivolts, is reported next to the paper's 78.75 mV.
- Histograms (model versus the target distribution) are in `results/l3/` with provenance: commit, parameter set, seeds, backend.
- If a board is available, the D2D and level-count checks are repeated on hardware and give identical stored weights to the `sim` backend.
- `results/l3/summary.md` is ready to paste into the verification report (C10) and the results slide (P2).

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Keep L3 visibly separate from L0–L2 and L4** in every table and slide. It's statistical, the others are exact.
- **Set A is simulated (TCAD) data.** "Our model reproduces the published σ" is a statement about fidelity to that paper, not to silicon. Say it that way.
- The register is an integer, so the realized σ is about 1 % below the target even with perfect arithmetic. That's expected; report it as register rounding.
- The triangular distribution has no tails beyond ±2.45 σ. If someone asks why extreme outliers never appear, that's the answer, and it's a disclosed modelling choice.
- For the read-noise check, don't reseed between repeats, or every repeat returns the same value.

## Files to read first (attach or paste these if you're using a chatbot)

- `sw/fecim/crossbar.py`, the backends, and the parameter-set loader from D4
- `sw/fecim/parameter_sets/dualport_fefet_mlc.yaml`
- `docs/plans and specs/06-physics-calibration/device-model.md`, `cell-physics-derivation.md` (§4)
- `docs/plans and specs/04-lane-c-verification/model-verification-design.md` (§3, §7)
- `docs/plans and specs/05-lane-d-host/application-spec.md` (§4.5, provenance format)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

