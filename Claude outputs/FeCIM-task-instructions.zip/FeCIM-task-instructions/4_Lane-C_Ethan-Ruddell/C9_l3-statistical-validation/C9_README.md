# C9 — L3 statistical validation

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Fri 27 Nov |
| **Board bucket** | Bucket 4 — Lane C |
| **Board task** | C9: L3 statistical validation |
| **Needs first** | C6 (calibration values), D3 or a board, D4 |
| **Unblocks** | C10, D8 (error bands), P2 |
| **AI version** | `C9_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

L0 through L4 ask "is the implementation correct?" and the answer is exact: bits match or they don't. L3 asks a different kind of question: "does the thing we implemented behave like the real device?" That can only be answered statistically.

Concretely: the paper says the device's threshold voltage varies with a standard deviation of 78.75 mV across a 2.7 V window. We converted that into `D2D_SIGMA = 18`. If we now program a few thousand emulated cells and measure the spread of what actually got stored, do we get 78.75 mV back? If we set 8 levels, do exactly 8 distinct values appear, evenly spaced? If we set a 1 % stuck rate, are about 1 % of cells stuck?

This closes the loop from paper to register and back to measured behaviour. It's a calibration check, not a correctness check, and the report keeps the two apart: an L2 failure would be an RTL bug, while an L3 failure would be a calibration problem. Mixing them in one table would blur what each one proves.

It also produces the uncertainty bands that go on the sweep plots.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **New script:** `sw/examples/l3_validation.py`, using `Crossbar(backend="sim")` and, where a board is available, `backend="fpga"`.
- **Inputs:** `sw/fecim/parameter_sets/dualport_fefet_mlc.yaml` through `load_parameter_set` (D4), and the targets in `device-model.md` (C6).
- **Outputs:** `results/l3/` — CSV of measured statistics, histogram PNGs, a provenance JSON, and a short `summary.md` table for the slides and the verification report.
- **Specs:** `04-lane-c-verification/model-verification-design.md` §3 (L3 definition), §7.5 (sweeping what the literature doesn't pin down).

## 3. How to build it

**Reading stored weights back, even from hardware.** With every read-time effect off, set one activation to 1 and all others to 0. Then `result[c] = w_stored[r][c]`, exactly. 128 computes read back the whole tile.

```python
def read_back_weights(xbar, rows, cols):
    W = np.zeros((rows, cols), dtype=np.int32)
    for r in range(rows):
        x = np.zeros(rows, dtype=np.uint8); x[r] = 1
        xbar.write_activations_raw(x); xbar.compute()
        W[r] = xbar.read_results()[:cols]
    return W
```

**Checks, with the pass criterion written down before running:**

| Property | Method | Expected | Pass if |
|---|---|---|---|
| Level count | quant only, N = 8; write all 256 values | exactly 8 distinct stored values, even spacing | exact |
| D2D spread | D2D only, σ reg = 18; program a mid-range value into all 16,384 cells; read back | σ_w = 0.408 × 18 = 7.35 LSB → 77.8 mV at MW = 2.7 V | within 3 % of 78.75 mV |
| D2D shape | same data | triangular: zero mean, bounded at ±(255 × 18 / 256) ≈ ±18 LSB | mean within ±0.2 LSB; no sample outside the bound |
| Stuck fraction | stuck only, rates 1 %, 5 %, 10 % | `rate / 65536` | within 3 binomial standard errors |
| Read-noise σ | read noise only; same compute repeated 1,000 times without reseeding; one-hot activation of 1 | σ = 0.144 × `READ_SIGMA` LSB | within 5 % |
| Seed-to-seed spread | repeat the D2D measurement for 10 seeds | — | report the range; it becomes the plot band |

Convert LSB back to device units with `ΔV_th = Δw × MW / 255` so the comparison is in the paper's units.

Use a mid-range programmed value (for example 0) for the D2D measurement. Near ±127 the saturation clips one tail and the measured σ shrinks; show that effect in one extra histogram, since it's a real property of the model.

Then, for the plots: for each sweep axis the paper doesn't fix (read noise, stuck rate, IR κ, ADC bits), record the range to sweep and the seed-to-seed spread at a few points.

## 4. How you know it's done

- Every row of the table has a measured value, the expected value, and pass or fail against a criterion that was written first.
- The measured D2D σ, converted to millivolts, is reported next to the paper's 78.75 mV.
- Histograms (model versus the target distribution) are in `results/l3/` with provenance: commit, parameter set, seeds, backend.
- If a board is available, the D2D and level-count checks are repeated on hardware and give identical stored weights to the `sim` backend.
- `results/l3/summary.md` is ready to paste into the verification report (C10) and the results slide (P2).

## 5. Watch out for

- **Keep L3 visibly separate from L0–L2 and L4** in every table and slide. It's statistical, the others are exact.
- **Set A is simulated (TCAD) data.** "Our model reproduces the published σ" is a statement about fidelity to that paper, not to silicon. Say it that way.
- The register is an integer, so the realized σ is about 1 % below the target even with perfect arithmetic. That's expected; report it as register rounding.
- The triangular distribution has no tails beyond ±2.45 σ. If someone asks why extreme outliers never appear, that's the answer, and it's a disclosed modelling choice.
- For the read-noise check, don't reseed between repeats, or every repeat returns the same value.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

