# AI prompt — C7: CI: full-top job, L0 blocking, all lint blocking

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **C7 — CI: full-top job, L0 blocking, all lint blocking**, owned by Ethan Ruddell, due Mon 23 Nov.

Update the GitHub Actions workflow so that CI enforces the project's verification gates: every registered testbench, every golden-vector freshness check, short versions of the full-array L0 and full-top L1/L2 co-simulations, and no non-blocking steps left.

Work from the workflow file and scripts as they exist; don't assume a testbench or Makefile target exists unless you can see it, and list any step you added whose target you couldn't confirm. Keep total runtime in mind and say what you expect each job to take. Editable files: `.github/workflows/ci.yml` only. If a check fails because of code in another lane, name the file and owner instead of weakening the check.

## Where the work goes

- **Edit:** `.github/workflows/ci.yml`. Current jobs: `lint`, `sim`, `model`, `cosim`, `python`.
- **Non-blocking today:** three lint steps carry `continue-on-error: true` (standalone lint of `mac_array`, `packet_parser`, `packet_tx`), each with a comment telling its owner to delete the line with their fix.
- **Testbench list:** the `sim` job runs `tb/run_sims.sh` with an explicit list of names; new testbenches aren't picked up automatically.
- **Local equivalents:** the commands in the Workflow section of this sheet.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

Changes, job by job:

```yaml
lint:
  # delete each `continue-on-error: true` once that module lints clean
  # add standalone lint steps for the newly implemented modules

sim:
  run: tb/run_sims.sh        # no argument list: run every registered testbench
  # (today it lists five names, and omits tb_uart_edge)

model:
  # after the existing mac_lane check, add one line per new generator:
  - run: python3 tb/golden/write_path/gen_write_path_vectors.py --check
  - run: python3 tb/golden/read_noise/gen_read_noise_vectors.py --check
  # ... ir_drop, adc

cosim:
  - run: make -C model/cosim run_l0_array && ./model/cosim/run_l0_array 1 50      # short L0
  - run: make -C model/cosim run_top && ./model/cosim/run_top stim_ci.bin         # short L1/L2

python:
  # already installs './sw[test]' and runs pytest, behind a gate that SKIPS the job while
  # sw/pyproject.toml is missing. Delete the gate (and the three `if:` conditions) once D1 merges.
```

Keep the whole workflow under about ten minutes. The full 1,000-matrix L0 and the full L1/L2 matrix stay as documented local commands; CI runs short versions of both.

Add the `run_top` step as non-blocking first (with a dated comment), and flip it to blocking the day C5 goes green.

Finally, protect `main`: in the repository settings, require the CI checks to pass before merging. That's a setting, not a file, so record that you did it in the PR description.

## Acceptance checks

- No `continue-on-error` remains in `ci.yml`, and the `python` job's skip gate is gone.
- Every testbench registered in `tb/run_sims.sh` runs in CI, including the ones added by A1, A3, A4, B1, B2, B5, B6, B7 and B8.
- All golden-vector generators are checked for freshness.
- Short full-array L0 and short full-top L1/L2 are blocking.
- `main` is green at the Sun 29 cutoff; a screenshot of that run is saved for the slides.
- Branch protection on `main` requires the checks.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Removing a `continue-on-error` line belongs to the module's owner.** `mac_array` is Megan's; `packet_parser` and `packet_tx` are Zhiting's. If their lint still fails, the fix is theirs; ask, don't patch around it.
- **The `sim` job doesn't run `tb_uart_edge` today.** The README says that testbench needed updating for `baud_gen`'s new port; Zhiting's branch (K2) should have fixed it. Check before switching CI to "run everything".
- Push and pull-request triggers both fire for PR commits, so most commits run the suite twice (there's a note in the file). Leave it unless minutes become a problem.
- CI pins Verilator 5.020 through the `ubuntu-24.04` image. If a harness needs a newer feature, that's a problem to solve in the harness.

## Files to read first (attach or paste these if you're using a chatbot)

- `.github/workflows/ci.yml`
- `tb/run_sims.sh`
- `model/cosim/Makefile`, `model/CMakeLists.txt`
- A listing of `tb/golden/` and `tb/sv/`
- `sw/pyproject.toml` (once D1 lands)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

