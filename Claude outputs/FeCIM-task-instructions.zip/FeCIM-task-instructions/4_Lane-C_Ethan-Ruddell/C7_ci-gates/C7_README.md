# C7 — CI: full-top job, L0 blocking, all lint blocking

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Mon 23 Nov |
| **Board bucket** | Bucket 4 — Lane C |
| **Board task** | C7: CI — full-top job, L0 blocking, all lint blocking |
| **Needs first** | C4, C5; each owner's lint fixes |
| **Unblocks** | X1 (green `main` at cutoff), P2 (CI screenshot) |
| **AI version** | `C7_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Four people are merging code every day for two weeks, much of it drafted with AI tools. Without an automatic check, the first sign that someone's change broke someone else's module is a failed demo.

Continuous integration (CI) is that automatic check. Every push and every pull request runs the whole test suite on a clean machine: lint, every testbench, the model's tests, the co-simulations, the golden-vector freshness checks and the Python tests. A red result blocks the merge. That's what lets us trust `main` at any moment, and it's the only way the rule "no RTL merges without its test passing" can be enforced instead of merely hoped for.

During the pre-alpha, a few checks were made non-blocking so that one lane's unfinished module didn't turn everything red. Those exemptions have to go now. A check that's allowed to fail isn't a check.

At the presentation, the green CI run on the final commit is the one-slide summary of the whole verification effort.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Edit:** `.github/workflows/ci.yml`. Current jobs: `lint`, `sim`, `model`, `cosim`, `python`.
- **Non-blocking today:** three lint steps carry `continue-on-error: true` (standalone lint of `mac_array`, `packet_parser`, `packet_tx`), each with a comment telling its owner to delete the line with their fix.
- **Testbench list:** the `sim` job runs `tb/run_sims.sh` with an explicit list of names; new testbenches aren't picked up automatically.
- **Local equivalents:** the commands in the Workflow section of this sheet.

## 3. How to build it

Changes, job by job:

```yaml
lint:
  # delete each `continue-on-error: true` once that module lints clean
  # add standalone lint steps for the newly implemented modules

sim:
  run: tb/run_sims.sh        # no argument list: run every registered testbench
  # (today it lists five names, and omits tb_uart_edge)

model:
  # after the existing mac_lane check, add one line per new generator:
  - run: python3 tb/golden/write_path/gen_write_path_vectors.py --check
  - run: python3 tb/golden/read_noise/gen_read_noise_vectors.py --check
  # ... ir_drop, adc

cosim:
  - run: make -C model/cosim run_l0_array && ./model/cosim/run_l0_array 1 50      # short L0
  - run: make -C model/cosim run_top && ./model/cosim/run_top stim_ci.bin         # short L1/L2

python:
  # already installs './sw[test]' and runs pytest, behind a gate that SKIPS the job while
  # sw/pyproject.toml is missing. Delete the gate (and the three `if:` conditions) once D1 merges.
```

Keep the whole workflow under about ten minutes. The full 1,000-matrix L0 and the full L1/L2 matrix stay as documented local commands; CI runs short versions of both.

Add the `run_top` step as non-blocking first (with a dated comment), and flip it to blocking the day C5 goes green.

Finally, protect `main`: in the repository settings, require the CI checks to pass before merging. That's a setting, not a file, so record that you did it in the PR description.

## 4. How you know it's done

- No `continue-on-error` remains in `ci.yml`, and the `python` job's skip gate is gone.
- Every testbench registered in `tb/run_sims.sh` runs in CI, including the ones added by A1, A3, A4, B1, B2, B5, B6, B7 and B8.
- All golden-vector generators are checked for freshness.
- Short full-array L0 and short full-top L1/L2 are blocking.
- `main` is green at the Sun 29 cutoff; a screenshot of that run is saved for the slides.
- Branch protection on `main` requires the checks.

## 5. Watch out for

- **Removing a `continue-on-error` line belongs to the module's owner.** `mac_array` is Megan's; `packet_parser` and `packet_tx` are Zhiting's. If their lint still fails, the fix is theirs; ask, don't patch around it.
- **The `sim` job doesn't run `tb_uart_edge` today.** The README says that testbench needed updating for `baud_gen`'s new port; Zhiting's branch (K2) should have fixed it. Check before switching CI to "run everything".
- Push and pull-request triggers both fire for PR commits, so most commits run the suite twice (there's a note in the file). Leave it unless minutes become a problem.
- CI pins Verilator 5.020 through the `ubuntu-24.04` image. If a harness needs a newer feature, that's a problem to solve in the harness.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

