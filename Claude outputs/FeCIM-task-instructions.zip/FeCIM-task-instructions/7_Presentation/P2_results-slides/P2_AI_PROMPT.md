# AI prompt — P2: Results slides: plots, resources, latency, verification

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **P2 — Results slides: plots, resources, latency, verification**, owned by Natalie Poche, due Sat 28 Nov.

Write the results section of the deck from the data provided: for each of up to five slides, a full-sentence title stating the claim, the key number, a description of the figure to use, and two or three sentences of speaker commentary. Then write three or four plain-language observations per plot, each backed by specific values from the data files.

Every number must come from the files given, quoted with its source file. If the data doesn't support a claim listed in the plan, say so and propose what the data does support. Don't describe simulated device data as measured.

## Where the work goes

- **Deck:** section 9 of the shared deck (see P1).
- **Plots:** `docs/img/plots/` (from D8's `make_plots.py`).
- **Numbers:** `results/*.csv` and `.json`; `docs/reports/utilization.md` (B9); `results/l4/` (C8); `docs/verification/coverage-matrix.md` (C10); `results/l3/summary.md` (C9).

## Steps the owner is following

Five slides at most:

| # | Claim the slide makes | Figure | Source |
|---|---|---|---|
| 1 | How accuracy falls with each device imperfection, and where a real device sits | 2×3 grid of sweeps, or the two most interesting, with the set-A marker and the float reference | D8 |
| 2 | Linear versus MLP, float versus ideal versus calibrated, on hardware | a small table with per-class accuracy; optionally the margin plot | D6, D7 |
| 3 | The design fits in half the chip's multipliers | table: logic elements, M9K, multiplier blocks, predicted versus measured versus available | B9 |
| 4 | A full multiply takes 392 cycles, 7.84 µs, as predicted | measured `CYCLE_CNT` beside the derivation; one line on the weight-load time for contrast | A1, C8 |
| 5 | Hardware equals model, for every configuration | the coverage matrix, with the hardware and `sim` curves overlaid | C10, D8 |

For each slide:

1. Write the title as the claim, in a full sentence.
2. Put the single most important number in large type.
3. Label axes in physical units and say what the band means (range across seeds).
4. Put the source file path and commit in the speaker notes.
5. Keep the L3 statistical check visibly separate from the exact-match levels on slide 5.

Then write two or three sentences of spoken commentary per slide: what to look at first, what it means, and what limits the conclusion.

## What done looks like

- Each slide states one claim in its title and shows the evidence for it.
- Every number matches a committed file, and the path and commit are in the notes.
- Plots are readable from the back of a room: large labels, few curves, clear legend.
- The set-A marker appears only on axes the paper reports.
- The slides are in the deck by Sat 28 for Sunday's rehearsal.

## Things to keep in mind

- **Say what kind of data set A is.** It's from a TCAD-simulated device calibrated to measured transistors. "A published FeFET parameter set" is accurate; "measured silicon" isn't.
- The ideal reference line is the run with every enable off, not the largest value on an axis.
- If a hardware result is missing, show the `sim` result and label it as such. Don't relabel it.
- Resist adding a sixth slide. Extra plots go in backup slides after the last one.

## What to give the model along with this prompt

- The result CSV and JSON files, or tables of their values
- The plots (or their descriptions) from `docs/img/plots/`
- `docs/reports/utilization.md`, `results/l3/summary.md`, the coverage matrix, the hardware-check log summary
- The calibration section of `device-model.md`

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

