# AI prompt — P3: Design-corrections and modelling-assumptions slide

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **P3 — Design-corrections and modelling-assumptions slide**, owned by Ethan Ruddell, due Wed 25 Nov.

Write the design-corrections and modelling-assumptions slide: a three-part layout (what was corrected, what changed in scope, what the model assumes) with concise wording for the slide itself, speaker notes of about 120 words, and one backup slide with supporting detail. Frame the corrections as evidence of rigor, in a factual tone.

Take every figure from the sources provided and keep the stated facts exact: 2.7 µs was superseded by 4.0 µs (32 lanes) and 7.84 µs (64 lanes, 392 cycles); the device has 144 multiplier blocks; operands are 9 bits; the accumulator is 32 bits. If the fit report or measurements you're given differ from a predicted value, use the measured value and note the difference.

## Where the work goes

- **Deck:** section 10 of the shared deck (see P1). One slide, plus a backup slide with detail if wanted.
- **Sources:** `docs/plans and specs/02-lane-a-interface/control-fsm-spec.md` §2 (latency); `01-contract/hardware-verification-errata.md` and `quartus/reports/dsp_pack_test.fit.summary` (multipliers); `03-lane-b-array/mac-array-spec.md` §2 and §5.4 (accumulator, clamp); `write-path-spec.md` §4–5 (differential pair, triangular); `06-physics-calibration/device-model.md` (provenance); `00-plan/fecim-plan.md` §3.6–3.9 (scope).

## Steps the owner is following

Lay the slide out in three columns.

**What we corrected**

| We first said | We found | We changed |
|---|---|---|
| A 64×64 multiply takes 2.7 µs | That counted only the accumulate cycles; clearing, pipeline drain and readout were missing | 4.0 µs (32 lanes) and 7.84 µs for the full 128×128, 64-lane tile: 392 cycles, derived and measured |
| The FPGA has 288 multipliers | It has 144 *blocks*; each does one 18×18 or two 9×9 multiplies, and 10-bit operands use a whole block | 9-bit operands everywhere, noise clamp ±127, a 16-bit cell hash, and triangular device variation, so 64 lanes fit |
| A 24-bit accumulator is enough | It overflows once read noise is added | 32 bits |

**What we changed in scope, and why**

- Calibration uses published FeFET data, not our own capacitor measurements. Published data reports conductance directly, which removes one assumption (converting polarization to conductance) and introduces another that we track explicitly: every parameter's source.
- Radiation effects are out of scope. Retention drift replaces them in semester 2.

**What our model assumes**

- IR drop is a fixed attenuation per row, not a solution of the resistor network.
- Device-to-device variation is triangular (two summed bytes), bounded, not Gaussian.
- Read noise is bell-shaped and bounded but isn't a textbook distribution; we report its measured moments.
- A signed weight is one quantity, not a differential pair of cells (conservative: it understates resolution).
- Set A's source is a simulated device calibrated to measured transistors.

Add anything cut at the Sat 28 checkpoint here, one factual line each.

Speak it as: "here's what we got wrong, how we found out, and what we did about it".

## What done looks like

- Each correction has a before value, an after value and a one-phrase reason, and each matches the cited spec section.
- Every assumption in the calibration document (C6) appears, in plain words.
- Nothing on the slide is apologetic or vague.
- No other slide in the deck contradicts it (search the deck for 2.7, 288 and "Gaussian").
- The speaker can explain each row in two sentences without notes.

## Things to keep in mind

- Keep the earlier, wrong figures only on this slide, clearly marked as superseded.
- "144 blocks, not 288 multipliers" is easy to garble out loud. Practise the sentence.
- Don't overclaim the fix: 9-bit operands made the design fit, and that cost some noise-model fidelity (the clamp, the triangular shape). Say both halves.
- If the fit report shows a multiplier count different from the predicted 72, use the measured number.

## What to give the model along with this prompt

- The three-column content above
- `control-fsm-spec.md` §2, `mac-array-spec.md` §2 and §5.4, `write-path-spec.md` §4–5
- The calibration section of `device-model.md` and `fecim-plan.md` §3.6–3.9
- The fit summary and measured `CYCLE_CNT`, when available
- Any items cut at the Sat 28 checkpoint

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

