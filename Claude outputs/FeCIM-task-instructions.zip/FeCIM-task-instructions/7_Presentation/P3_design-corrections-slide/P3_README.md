# P3 — Design-corrections and modelling-assumptions slide

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Wed 25 Nov |
| **Board bucket** | Bucket 7 — Presentation |
| **Board task** | Design-corrections and modelling-assumptions slide |
| **Needs first** | C6 (assumptions list) |
| **Unblocks** | P5, X3; also feeds C10's limitations section |
| **AI version** | `P3_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Every real engineering project gets things wrong along the way. What separates a careful team from a careless one is whether they found their own mistakes, fixed them properly, and are straight about what their model does and doesn't capture.

We have a good story here, and it should be told as a strength. We predicted a latency, worked through the actual sequence, found the prediction was too optimistic, and corrected it. We assumed the chip had twice as many multipliers as it does, discovered the design wouldn't fit, and redesigned the arithmetic so it does. Each correction has a number before, a number after, and a reason.

The same slide states our modelling assumptions. A reviewer who knows this field will ask "is your IR drop a real network solve?" and "is that noise Gaussian?". Answering before they ask shows that we know exactly where the edges of our model are. That's what makes the rest of the results credible.

## 2. Where the work goes

- **Deck:** section 10 of the shared deck (see P1). One slide, plus a backup slide with detail if wanted.
- **Sources:** `docs/plans and specs/02-lane-a-interface/control-fsm-spec.md` §2 (latency); `01-contract/hardware-verification-errata.md` and `quartus/reports/dsp_pack_test.fit.summary` (multipliers); `03-lane-b-array/mac-array-spec.md` §2 and §5.4 (accumulator, clamp); `write-path-spec.md` §4–5 (differential pair, triangular); `06-physics-calibration/device-model.md` (provenance); `00-plan/fecim-plan.md` §3.6–3.9 (scope).

## 3. How to do it

Lay the slide out in three columns.

**What we corrected**

| We first said | We found | We changed |
|---|---|---|
| A 64×64 multiply takes 2.7 µs | That counted only the accumulate cycles; clearing, pipeline drain and readout were missing | 4.0 µs (32 lanes) and 7.84 µs for the full 128×128, 64-lane tile: 392 cycles, derived and measured |
| The FPGA has 288 multipliers | It has 144 *blocks*; each does one 18×18 or two 9×9 multiplies, and 10-bit operands use a whole block | 9-bit operands everywhere, noise clamp ±127, a 16-bit cell hash, and triangular device variation, so 64 lanes fit |
| A 24-bit accumulator is enough | It overflows once read noise is added | 32 bits |

**What we changed in scope, and why**

- Calibration uses published FeFET data, not our own capacitor measurements. Published data reports conductance directly, which removes one assumption (converting polarization to conductance) and introduces another that we track explicitly: every parameter's source.
- Radiation effects are out of scope. Retention drift replaces them in semester 2.

**What our model assumes**

- IR drop is a fixed attenuation per row, not a solution of the resistor network.
- Device-to-device variation is triangular (two summed bytes), bounded, not Gaussian.
- Read noise is bell-shaped and bounded but isn't a textbook distribution; we report its measured moments.
- A signed weight is one quantity, not a differential pair of cells (conservative: it understates resolution).
- Set A's source is a simulated device calibrated to measured transistors.

Add anything cut at the Sat 28 checkpoint here, one factual line each.

Speak it as: "here's what we got wrong, how we found out, and what we did about it".

## 4. How you know it's done

- Each correction has a before value, an after value and a one-phrase reason, and each matches the cited spec section.
- Every assumption in the calibration document (C6) appears, in plain words.
- Nothing on the slide is apologetic or vague.
- No other slide in the deck contradicts it (search the deck for 2.7, 288 and "Gaussian").
- The speaker can explain each row in two sentences without notes.

## 5. Watch out for

- Keep the earlier, wrong figures only on this slide, clearly marked as superseded.
- "144 blocks, not 288 multipliers" is easy to garble out loud. Practise the sentence.
- Don't overclaim the fix: 9-bit operands made the design fit, and that cost some noise-model fidelity (the clamp, the triangular shape). Say both halves.
- If the fit report shows a multiplier count different from the predicted 72, use the measured number.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

