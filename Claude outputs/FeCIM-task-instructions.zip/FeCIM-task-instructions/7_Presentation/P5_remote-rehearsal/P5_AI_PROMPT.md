# AI prompt — P5: Remote rehearsal, timed, with slides and recorded demos

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **P5 — Remote rehearsal, timed, with slides and recorded demos**, owned by Ethan Ruddell, due Sun 29 Nov.

Help prepare and then debrief the rehearsal. Before it: produce a timing sheet (section, speaker, target time) from the deck outline and time limit, and a list of ten likely audience questions with two-sentence answers grounded in the project facts provided. After it: from the recorded section times and notes, say where to cut to fit the limit with 20 % spare, and turn the notes into an action list with owners. Use only facts given to you in the answers.

## Where the work goes

- **Call:** Teams, about an hour, Sunday before 18:00.
- **Material:** the shared deck, the demo recordings (P4), a stopwatch.
- **Log:** `docs/meetings/2026-11-29.md`.

## Steps the owner is following

1. **First pass, no stopping.** Run the whole talk exactly as it'll be given, recordings in place of demos. One person times each section and writes the times down. Nobody interrupts.
2. **Compare with the limit** (from K6). Aim to finish with 20 % to spare.
3. **Second pass, with notes.** Go back through, section by section. For each, ask:
   - Was the one main point clear in the first sentence?
   - Did anything get said twice by two people?
   - Was there a term the audience won't know that nobody explained?
   - Was the hand-off to the next speaker clean?
4. **Cut to fit.** If it's over time, remove slides. Speaking faster doesn't work. Backup slides are where cut material goes.
5. **Questions.** Each person asks the hardest question they can think of about someone else's section. Write down the questions and a two-sentence answer for each.
6. **Record the action list:** slide fixes due before 18:00, and who makes them.

Likely questions to prepare:

- Why emulate a crossbar digitally at all, when software simulators exist?
- How do you know the hardware isn't just wrong in a way that looks like noise?
- Is your device data measured or simulated?
- What would it take to run a larger network?
- What did AI tools do, and how did you check their work?

## What done looks like

- The full talk has been run once without stopping, and the per-section times are recorded.
- Total time is inside the limit with margin, after cuts.
- Each speaker knows their sections and their hand-off lines.
- A list of anticipated questions with short answers exists.
- Slide fixes are assigned and finished before the 18:00 cutoff.
- The log is committed.

## Things to keep in mind

- Run the first pass straight through. Stopping to fix things hides the true timing.
- The answer to "how did you check AI-drafted code?" is specific and strong: golden vectors written first, bit-exact co-simulation, mutation tests, human review of every PR. Have it ready.
- If someone can't attend, they record their section and it's played in order.
- Changes after 18:00 are limited to typos. Anything that changes a number has to come from the frozen commit.

## What to give the model along with this prompt

- The deck outline with speakers, and the time limit
- The project summary (repo `README.md`) and the design-corrections slide content
- The section timings and notes from the rehearsal, for the debrief

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

