# P5 — Remote rehearsal, timed, with slides and recorded demos

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Sun 29 Nov |
| **Board bucket** | Bucket 7 — Presentation |
| **Board task** | Remote rehearsal, timed (slides + recorded demos) |
| **Needs first** | P1–P4, G6 |
| **Unblocks** | X1 (final slide fixes before cutoff), X2 |
| **AI version** | `P5_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

A talk that hasn't been said out loud, against a clock, by the people who'll give it, isn't ready. Slides that look fine on screen turn out to take three minutes to explain. Hand-offs between speakers stumble. Two people explain the same thing in different words. None of that shows up until someone actually speaks it.

This rehearsal is the first of two. It's remote, on the Sunday before the cutoff, using the recordings in place of live demos. Its job is to fix the *talk*: the timing, the order, the hand-offs, the words. Monday's in-person dry run then only has to fix the *logistics*: boards, cables, laptops, the room.

Doing it before the merge cutoff matters too. If the rehearsal shows that a slide's number is wrong or a plot is unreadable, there's still time to regenerate it from the repository.

## 2. Where the work goes

- **Call:** Teams, about an hour, Sunday before 18:00.
- **Material:** the shared deck, the demo recordings (P4), a stopwatch.
- **Log:** `docs/meetings/2026-11-29.md`.

## 3. How to do it

1. **First pass, no stopping.** Run the whole talk exactly as it'll be given, recordings in place of demos. One person times each section and writes the times down. Nobody interrupts.
2. **Compare with the limit** (from K6). Aim to finish with 20 % to spare.
3. **Second pass, with notes.** Go back through, section by section. For each, ask:
   - Was the one main point clear in the first sentence?
   - Did anything get said twice by two people?
   - Was there a term the audience won't know that nobody explained?
   - Was the hand-off to the next speaker clean?
4. **Cut to fit.** If it's over time, remove slides. Speaking faster doesn't work. Backup slides are where cut material goes.
5. **Questions.** Each person asks the hardest question they can think of about someone else's section. Write down the questions and a two-sentence answer for each.
6. **Record the action list:** slide fixes due before 18:00, and who makes them.

Likely questions to prepare:

- Why emulate a crossbar digitally at all, when software simulators exist?
- How do you know the hardware isn't just wrong in a way that looks like noise?
- Is your device data measured or simulated?
- What would it take to run a larger network?
- What did AI tools do, and how did you check their work?

## 4. How you know it's done

- The full talk has been run once without stopping, and the per-section times are recorded.
- Total time is inside the limit with margin, after cuts.
- Each speaker knows their sections and their hand-off lines.
- A list of anticipated questions with short answers exists.
- Slide fixes are assigned and finished before the 18:00 cutoff.
- The log is committed.

## 5. Watch out for

- Run the first pass straight through. Stopping to fix things hides the true timing.
- The answer to "how did you check AI-drafted code?" is specific and strong: golden vectors written first, bit-exact co-simulation, mutation tests, human review of every PR. Have it ready.
- If someone can't attend, they record their section and it's played in order.
- Changes after 18:00 are limited to typos. Anything that changes a number has to come from the frozen commit.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

