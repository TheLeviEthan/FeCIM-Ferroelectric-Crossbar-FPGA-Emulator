# AI prompt — P1: Slide deck draft, by section owners

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **P1 — Slide deck draft, by section owners**, owned by Ethan Ruddell (each section has its own owner), due Wed 25 Nov.

Draft the presentation deck as slide-by-slide content: for each slide, a full-sentence title, three or four short bullets or a description of the figure, and speaker notes of about 60 to 90 words. Follow the section flow given, pitch the device-physics explanation at a computer-engineering audience that hasn't met ferroelectric devices, and keep within the stated time limit.

Use only facts and numbers from the material provided. Where a result isn't available yet, write a clearly labelled placeholder slide that says exactly which measurement is missing. List every placeholder at the end.

## Where the work goes

- **Deck:** the team's shared slide deck (start from the Design Draft deck; its twelve slides already have speaker notes).
- **Source material:** the repo `README.md` (architecture diagram), the pre-alpha "how it works" bullets, `docs/plans and specs/00-plan/fecim-plan.md`, the reports under `docs/reports/`.
- **Figures:** `docs/img/`, `docs/img/plots/` (from D8).

## Steps the owner is following

Suggested flow, with a section owner for each (assign at the Thu 19 meeting):

| # | Section | Slides | Suggested owner | The one thing it must get across |
|---|---|---|---|---|
| 1 | The problem | 1 | Ethan | Neural networks spend their energy moving data between memory and processor |
| 2 | Compute-in-memory and FeFET crossbars | 1–2 | Ethan | A memory array can do the multiply itself, but real devices are imperfect |
| 3 | What FeCIM is | 1 | Ethan | A digital emulator of that array on an FPGA, with the imperfections switchable one at a time |
| 4 | Architecture | 1 | Zhiting | Host, UART, parser, sequencer, 64 lanes, result buffer |
| 5 | Follow one request | 3–4 | Natalie → Zhiting → Megan | Packet out of Python, into the parser, through the write path and lanes, back out |
| 6 | The six non-idealities | 1–2 | Megan | What each one is physically and where it's injected |
| 7 | How we know it's right | 2 | Ethan | Model, golden vectors, co-simulation, hardware match; the live bug |
| 8 | Calibration | 1 | Ethan + Natalie | Register values trace to a published device |
| 9 | Results | 3–5 | Natalie | Accuracy versus each imperfection, with the real device marked (P2) |
| 10 | Design corrections and assumptions | 1 | Ethan | We found our own errors and fixed them (P3) |
| 11 | Semester 2 | 1 | all | Multi-tile, differential pairs, retention drift, three device technologies |

Rules for the draft:

1. One idea per slide, stated in the title as a full sentence ("Two 9-bit multiplies fit in one block, so 64 lanes use half the chip"), not a label ("Multipliers").
2. Every number carries its source in the speaker notes: the file and commit it came from.
3. A placeholder slide is fine in the draft. Label it with exactly what's missing and who's producing it.
4. Section 5 follows the data, in the same order as the pre-alpha demo: host, interface, array, verification.
5. Fit the time limit from K6 with about 20 % to spare. As a guide, allow one minute per slide.

## What done looks like

- A complete draft exists in the shared deck by Wed 25, with every section present, even if some slides are labelled placeholders.
- Each section has a named owner and speaker.
- Every number on a slide has its source in the notes.
- The slide count fits the time limit with margin.
- The draft is ready to walk through on the Fri 27 call.

## Things to keep in mind

- Don't open with device physics. Open with the problem, and bring in the physics as the constraint.
- The audience should hear "392 cycles, 7.84 µs" once, with the correction story. Make sure no slide still says 2.7 µs.
- "Bit-exact" means something specific here: identical integers for the same seed. Say it once, plainly, and then use it consistently.
- If a live demo isn't allowed, section 5 and section 7 lean on the demo video (P4).

## What to give the model along with this prompt

- The time limit and format from K6
- The existing Design Draft deck (slide text and speaker notes)
- The repo `README.md` and `docs/plans and specs/00-plan/fecim-plan.md`
- The pre-alpha "how it works" bullets
- Any results, plots and report summaries that exist so far

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

