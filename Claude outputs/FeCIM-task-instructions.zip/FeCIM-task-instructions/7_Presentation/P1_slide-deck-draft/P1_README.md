# P1 — Slide deck draft, by section owners

| | |
|---|---|
| **Owner** | Ethan Ruddell (each section has its own owner) |
| **Due** | Wed 25 Nov |
| **Board bucket** | Bucket 7 — Presentation |
| **Board task** | Slide deck draft (section owners) |
| **Needs first** | K6 (time limit and format), G1 (section owners assigned) |
| **Unblocks** | P2, P3, P5 |
| **AI version** | `P1_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

The presentation is how two semesters of work get judged in about fifteen minutes. The audience won't read the repository. They'll see slides, and one or two things running. Whatever isn't on a slide, clearly, didn't happen as far as the grade is concerned.

A draft by Wednesday, before the break, does two things. It exposes what we can't yet show: an empty results slide tells everyone exactly which measurement still has to be made. And it gives the team something concrete to review on Friday's call, while there's still time to change it.

The hardest part of this deck is the story, because the project sits between fields. A computer-engineering audience knows FPGAs and may never have heard of a ferroelectric transistor. The deck has to make the device physics feel like an ordinary engineering constraint, and then show that we built something rigorous on top of it.

## 2. Where the work goes

- **Deck:** the team's shared slide deck (start from the Design Draft deck; its twelve slides already have speaker notes).
- **Source material:** the repo `README.md` (architecture diagram), the pre-alpha "how it works" bullets, `docs/plans and specs/00-plan/fecim-plan.md`, the reports under `docs/reports/`.
- **Figures:** `docs/img/`, `docs/img/plots/` (from D8).

## 3. How to do it

Suggested flow, with a section owner for each (assign at the Thu 19 meeting):

| # | Section | Slides | Suggested owner | The one thing it must get across |
|---|---|---|---|---|
| 1 | The problem | 1 | Ethan | Neural networks spend their energy moving data between memory and processor |
| 2 | Compute-in-memory and FeFET crossbars | 1–2 | Ethan | A memory array can do the multiply itself, but real devices are imperfect |
| 3 | What FeCIM is | 1 | Ethan | A digital emulator of that array on an FPGA, with the imperfections switchable one at a time |
| 4 | Architecture | 1 | Zhiting | Host, UART, parser, sequencer, 64 lanes, result buffer |
| 5 | Follow one request | 3–4 | Natalie → Zhiting → Megan | Packet out of Python, into the parser, through the write path and lanes, back out |
| 6 | The six non-idealities | 1–2 | Megan | What each one is physically and where it's injected |
| 7 | How we know it's right | 2 | Ethan | Model, golden vectors, co-simulation, hardware match; the live bug |
| 8 | Calibration | 1 | Ethan + Natalie | Register values trace to a published device |
| 9 | Results | 3–5 | Natalie | Accuracy versus each imperfection, with the real device marked (P2) |
| 10 | Design corrections and assumptions | 1 | Ethan | We found our own errors and fixed them (P3) |
| 11 | Semester 2 | 1 | all | Multi-tile, differential pairs, retention drift, three device technologies |

Rules for the draft:

1. One idea per slide, stated in the title as a full sentence ("Two 9-bit multiplies fit in one block, so 64 lanes use half the chip"), not a label ("Multipliers").
2. Every number carries its source in the speaker notes: the file and commit it came from.
3. A placeholder slide is fine in the draft. Label it with exactly what's missing and who's producing it.
4. Section 5 follows the data, in the same order as the pre-alpha demo: host, interface, array, verification.
5. Fit the time limit from K6 with about 20 % to spare. As a guide, allow one minute per slide.

## 4. How you know it's done

- A complete draft exists in the shared deck by Wed 25, with every section present, even if some slides are labelled placeholders.
- Each section has a named owner and speaker.
- Every number on a slide has its source in the notes.
- The slide count fits the time limit with margin.
- The draft is ready to walk through on the Fri 27 call.

## 5. Watch out for

- Don't open with device physics. Open with the problem, and bring in the physics as the constraint.
- The audience should hear "392 cycles, 7.84 µs" once, with the correction story. Make sure no slide still says 2.7 µs.
- "Bit-exact" means something specific here: identical integers for the same seed. Say it once, plainly, and then use it consistently.
- If a live demo isn't allowed, section 5 and section 7 lean on the demo video (P4).

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

