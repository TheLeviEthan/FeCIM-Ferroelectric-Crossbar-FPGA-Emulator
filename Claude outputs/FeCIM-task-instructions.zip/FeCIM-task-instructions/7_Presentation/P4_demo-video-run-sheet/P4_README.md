# P4 — Demo video, run sheet and backup recordings

| | |
|---|---|
| **Owner** | Natalie Poche |
| **Due** | Sat 28 Nov |
| **Board bucket** | Bucket 7 — Presentation |
| **Board task** | Demo video + run sheet + backup recordings |
| **Needs first** | each demo working at least once (A2, C5, C8, D6, D7, D8) |
| **Unblocks** | P5, X2, X3 |
| **AI version** | `P4_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Live hardware demos fail for reasons that have nothing to do with whether the design works: a loose jumper wire, a laptop that picked a different COM port, a projector that won't mirror. When that happens in front of an audience with no fallback, a working project looks broken.

Three things protect us. A **backup recording** of every demo, made the first time it works, means any single failure costs ten seconds: "here's the recording of this running". A **demo video** stitches the best takes into one short clip that tells the story end to end, usable if live demos aren't allowed or time is tight. And a **run sheet** is the checklist for the day: who runs what, on which laptop, with which board, typing exactly which command, expecting exactly which output.

The run sheet is also what makes the dry run a real test. It gets followed by someone who isn't the demo's author.

## 2. Where the work goes

- **Run sheet:** `docs/coursework/demo-run-sheet.md`, committed.
- **Recordings:** a shared folder (video files don't go in the repo), each linked from the run sheet.
- **Demo video:** the same shared folder, linked from the run sheet and the deck.

## 3. How to do it

**Run sheet**, one row per demo:

| # | Demo | Owner | Laptop | Board? | Exact command | Expected output | Recording | Slot |
|---|---|---|---|---|---|---|---|---|
| 1 | Hardware gate: `IDENTIFY` and a register round trip | Zhiting | | yes | | magic `0xFEC1`, version 2, 64 lanes | link | |
| 2 | Full-design co-simulation, then the live bug | Ethan | | no | | `PASS`, then a failure naming the column | link | |
| 3 | Hardware equals model | Zhiting or Natalie | | yes | | `PASS n/n` | link | |
| 4 | Linear digits on the board; digit on the display | Natalie | | yes | | accuracy table; display shows the digit | link | |
| 5 | MLP digits | Natalie | | yes | | accuracy table and time breakdown | link | |
| 6 | One live sweep point | Natalie | | yes | | a new point appears on the curve | link | |

Above the table, add a setup checklist: boards flashed with the release image, dongle jumpers at 3.3 V, COM port names noted, `SW[1:0] = 10` for the digit display, virtual environment activated, terminal font enlarged.

**Recording each demo:**

1. Record the day it first works. Don't wait for Saturday.
2. Thirty seconds, screen capture plus a phone shot of the board where the display matters.
3. Start from a clean terminal, type the command, show the result. No editing needed.
4. Name the file with the demo number and date, and link it in the run sheet.

**Demo video**, two to three minutes:

```text
0:00  one sentence: what you're about to see
0:10  IDENTIFY: the board answers
0:25  a digit goes in, the board's display shows the prediction
0:50  accuracy table: float vs ideal vs calibrated device
1:10  a sweep running; the curve it produces, with the real device marked
1:40  co-simulation: PASS; one character changed in the RTL; it fails and names the column
2:20  hardware equals model: PASS n/n
```

Add short captions instead of narration, so it works with the sound off.

## 4. How you know it's done

- The run sheet is committed with every row filled in: owner, laptop, command, expected output, recording link.
- Every demo has a backup recording that plays.
- The demo video exists, runs two to three minutes, and is understandable with no sound.
- Someone other than each demo's author has followed its row successfully (this happens at the dry run, X2).

## 5. Watch out for

- **Record early.** "It worked yesterday" isn't a recording.
- Commands in the run sheet are copied from a terminal where they worked, not retyped from memory.
- Keep personal details out of recordings: close chat windows and email, and hide the taskbar.
- If the live demo goes wrong on the day, switch to the recording at once. Don't debug in front of the audience.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

