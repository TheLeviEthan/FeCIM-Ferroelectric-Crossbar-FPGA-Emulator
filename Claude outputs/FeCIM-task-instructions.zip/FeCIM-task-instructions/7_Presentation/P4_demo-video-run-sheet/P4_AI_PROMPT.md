# AI prompt — P4: Demo video, run sheet and backup recordings

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **P4 — Demo video, run sheet and backup recordings**, owned by Natalie Poche, due Sat 28 Nov.

Draft the demo run sheet as a Markdown document (setup checklist plus the per-demo table), a shot list with captions for a two-to-three-minute demo video, and a 20-second spoken introduction for each demo. Fill in commands and expected outputs only from the material provided, and leave a marked blank where a command isn't given.

## Where the work goes

- **Run sheet:** `docs/coursework/demo-run-sheet.md`, committed.
- **Recordings:** a shared folder (video files don't go in the repo), each linked from the run sheet.
- **Demo video:** the same shared folder, linked from the run sheet and the deck.

## Steps the owner is following

**Run sheet**, one row per demo:

| # | Demo | Owner | Laptop | Board? | Exact command | Expected output | Recording | Slot |
|---|---|---|---|---|---|---|---|---|
| 1 | Hardware gate: `IDENTIFY` and a register round trip | Zhiting | | yes | | magic `0xFEC1`, version 2, 64 lanes | link | |
| 2 | Full-design co-simulation, then the live bug | Ethan | | no | | `PASS`, then a failure naming the column | link | |
| 3 | Hardware equals model | Zhiting or Natalie | | yes | | `PASS n/n` | link | |
| 4 | Linear digits on the board; digit on the display | Natalie | | yes | | accuracy table; display shows the digit | link | |
| 5 | MLP digits | Natalie | | yes | | accuracy table and time breakdown | link | |
| 6 | One live sweep point | Natalie | | yes | | a new point appears on the curve | link | |

Above the table, add a setup checklist: boards flashed with the release image, dongle jumpers at 3.3 V, COM port names noted, `SW[1:0] = 10` for the digit display, virtual environment activated, terminal font enlarged.

**Recording each demo:**

1. Record the day it first works. Don't wait for Saturday.
2. Thirty seconds, screen capture plus a phone shot of the board where the display matters.
3. Start from a clean terminal, type the command, show the result. No editing needed.
4. Name the file with the demo number and date, and link it in the run sheet.

**Demo video**, two to three minutes:

```text
0:00  one sentence: what you're about to see
0:10  IDENTIFY: the board answers
0:25  a digit goes in, the board's display shows the prediction
0:50  accuracy table: float vs ideal vs calibrated device
1:10  a sweep running; the curve it produces, with the real device marked
1:40  co-simulation: PASS; one character changed in the RTL; it fails and names the column
2:20  hardware equals model: PASS n/n
```

Add short captions instead of narration, so it works with the sound off.

## What done looks like

- The run sheet is committed with every row filled in: owner, laptop, command, expected output, recording link.
- Every demo has a backup recording that plays.
- The demo video exists, runs two to three minutes, and is understandable with no sound.
- Someone other than each demo's author has followed its row successfully (this happens at the dry run, X2).

## Things to keep in mind

- **Record early.** "It worked yesterday" isn't a recording.
- Commands in the run sheet are copied from a terminal where they worked, not retyped from memory.
- Keep personal details out of recordings: close chat windows and email, and hide the taskbar.
- If the live demo goes wrong on the day, switch to the recording at once. Don't debug in front of the audience.

## What to give the model along with this prompt

- The demo list above, with owners and laptops
- The exact command and a sample of real output for each demo
- The time limit and demo rules from K6
- The pre-alpha run sheet or demo scripts, if available, as a model

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

