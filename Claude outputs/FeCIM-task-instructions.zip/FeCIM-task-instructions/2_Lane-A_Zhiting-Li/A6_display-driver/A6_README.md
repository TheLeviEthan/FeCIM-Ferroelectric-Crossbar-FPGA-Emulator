# A6 — display_driver on HEX and LEDs

| | |
|---|---|
| **Owner** | Zhiting Li |
| **Due** | Wed 25 Nov |
| **Board bucket** | Bucket 2 — Lane A |
| **Board task** | A6: `display_driver` on HEX |
| **Needs first** | A2 (board builds), A4 (argmax index) |
| **Unblocks** | D6 demo ("digit on the board"), X2 dry run |
| **AI version** | `A6_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

The seven-segment displays and LEDs are the only part of the system an audience can see without a laptop. For the demo, that matters: when the board classifies a handwritten digit, the predicted digit lights up on the board itself.

It's also the one debug channel that keeps working when the serial link is the thing that's broken. A byte counter that ticks on every received byte tells you the UART is alive before any software runs. A heartbeat dot tells "idle" apart from "hung". The course's requirements for this kind of project ask for a physical interface, and this is it.

Finally, `KEY1` triggers a compute with no host attached, and the display shows the result. If the laptop link dies mid-presentation, a preloaded board still demonstrates the design.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Implement:** `rtl/control/display_driver.sv` (skeleton; all segments currently off).
- **Pins:** HEX1–HEX5 and all decimal points (`HEXn[7]`) must be in the pin file from A2; today `quartus/pins.tcl` only has `HEX0[6:0]`.
- **Specs:** `02-lane-a-interface/top-level-spec.md` §6; `control-fsm-spec.md` §8; `01-contract/hardware-verification-errata.md` §3.1 (active-low displays).

## 3. How to build it

Assignments (top-level-spec §6.2):

| Element | Shows |
|---|---|
| `HEX5`–`HEX4` | control FSM state, in hex |
| `HEX3`–`HEX0` | chosen by `SW[1:0]`: `00` RX byte count · `01` `result[0]` low 16 bits · `10` argmax index · `11` error count |
| `HEX0[7]` (decimal point) | heartbeat, toggles once per second |
| `LEDR[9]` | compute busy |
| `LEDR[8]` | error latched since reset |
| `LEDR[7]` | UART RX activity, stretched so it's visible |
| `LEDR[6:0]` | `seq_cnt` activity |

```systemverilog
function automatic logic [6:0] seg_pattern(input logic [3:0] n);   // {g,f,e,d,c,b,a}, 1 = lit
    case (n)
        4'h0: return 7'b0111111;   4'h1: return 7'b0000110;
        // ... 2..F
    endcase
endfunction

always_comb begin
    case (sw[1:0])
        2'b00: value16 = rx_byte_cnt;
        2'b01: value16 = result_word[15:0];
        2'b10: value16 = {9'd0, argmax_idx};
        2'b11: value16 = err_cnt;
    endcase
end

// The displays are ACTIVE LOW: a segment lights when its pin is 0.
assign hex0 = ~{heartbeat, seg_pattern(value16[3:0])};
assign hex1 = ~{1'b0,      seg_pattern(value16[7:4])};
// ...
```

Heartbeat: a counter to `CLK_HZ / 2` that toggles a flop. RX activity stretch: on `rx_activity`, load a counter with about 50 ms worth of cycles and keep the LED on until it reaches zero.

For the digit demo, set `SW[1:0] = 10`. The argmax index for digits is 0 to 9, so the hex digit on `HEX0` is the decimal digit.

## 4. How you know it's done

- After reset: heartbeat dot blinks once per second, `HEX5`–`HEX4` show `00` (IDLE).
- Sending bytes makes the `SW = 00` count climb and `LEDR[7]` flicker.
- After a compute with `SW = 10`, the predicted column index is shown; after a digits inference it's the predicted digit.
- Every segment pattern 0–F checked by eye on the board (one photo is enough evidence).
- Lint waivers removed; whole-design lint clean.

## 5. Watch out for

- **Inverted segments.** Written the natural way, every segment is inverted, which is readable enough to be confusing instead of obviously broken. Drive `~{dp, seg}`.
- **`result_word`** is the result buffer's read data. It only means "result[0]" while `readout_ser` is idle and holding the read address at 0 (see A3).
- The segment bit order `{g,f,e,d,c,b,a}` must match the pin order in the pin file; check one digit on hardware before trusting the table.
- This is the first task to drop if Lane A falls behind. The LEDs alone (busy, error, RX activity) are enough for bring-up.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

