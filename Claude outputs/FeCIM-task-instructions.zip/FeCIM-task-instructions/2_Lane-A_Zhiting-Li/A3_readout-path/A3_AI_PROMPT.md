# AI prompt — A3: Readout path: readout_ser to packet_tx for READ_RESULT and READ_ARGMAX

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **A3 — Readout path: readout_ser to packet_tx for READ_RESULT and READ_ARGMAX**, owned by Zhiting Li, due Sat 21 Nov.

Implement `readout_ser`, the byte serializer that feeds `packet_tx` with the payload for `READ_RESULT` (count × 4 bytes of `int32` results, little-endian) and `READ_ARGMAX` (10 bytes), plus a self-checking testbench.

Match `packet_tx`'s payload handshake exactly; read `packet_tx.sv` to see when it samples `pl_valid` after pulsing `pl_next`. If the file already contains an `IDENTIFY` / `GET_CONFIG` payload path from task A2, extend it instead of replacing it. Editable files: `rtl/control/readout_ser.sv`, `tb/sv/tb_readout_ser.sv` (new), `tb/run_sims.sh`, `.github/workflows/ci.yml`, and the `u_readout_ser` instance in `rtl/fecim_top.sv` if a port has to change. `result_buffer.sv` and `argmax_unit.sv` may still be skeletons; test against a stub memory in the testbench.

## Where the work goes

- **Implement:** `rtl/control/readout_ser.sv` (skeleton; if you extended it in A2, this adds the result and argmax sources to the same serializer).
- **New testbench:** `tb/sv/tb_readout_ser.sv`, added to `tb/run_sims.sh` and CI.
- **Connected to:** `packet_parser` (`rd_go`, `rd_argmax`, `rd_start`, `rd_count`), `result_buffer` (`result_raddr` out, `result_rdata` in, one-cycle registered read), `argmax_unit` (`argmax_idx`, `argmax_val`, `argmax_second`), `packet_tx` (`pl_data`, `pl_valid`, `pl_next`).
- **Specs:** `03-lane-b-array/result-buffer-spec.md` §6 and §9 tests 6–9; `01-contract/protocol.md` §2 (byte order), §4.4, §4.6.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```text
IDLE:   result_raddr = 0                          // so the display can show result[0]
        on rd_go: latch rd_argmax, rd_start, rd_count
                  rd_argmax ? -> ARGMAX : (word = rd_start; left = rd_count; -> FETCH)

FETCH:  result_raddr = word; wait one cycle        // M9K read is registered
        buf = result_rdata; byte = 0; -> SEND

SEND:   on pl_next: pl_data = buf[8*byte +: 8]; pl_valid = 1 next cycle
        after 4 bytes: word++; left--;  left == 0 ? -> IDLE : -> FETCH

ARGMAX: 10 bytes, same handshake:
        {argmax_idx zero-extended to 16 bits} low byte, high byte
        argmax_val    bytes 0..3 (least significant first)
        argmax_second bytes 0..3
```

Don't build a prefetch. A UART byte takes about 540 clock cycles at 921600 baud, so a one-cycle memory read is invisible.

The parser already rejects bad ranges before `rd_go` (its `dispatch_status` returns `ST_ADDR_RANGE` when `start + count > TILE_COLS`), so the serializer can trust what it's given.

For the testbench, stand in for `result_buffer` with a small array pre-filled with known words, including `32'h8000_0000`, `-1`, `1` and `32'h1234_5678`. Drive `pl_next` the way `packet_tx` does and compare bytes.

## Acceptance checks

- `tb_readout_ser` passes: 1 word, 128 words, a mid-range start, and two requests back to back.
- A negative word comes out as its two's-complement bytes, least significant first, and `struct.unpack('<i', ...)` in Python gives back the original value.
- The `READ_ARGMAX` payload is exactly 10 bytes in the order above.
- Re-run with Megan's real `result_buffer` (B6) and `argmax_unit` (A4) once they merge.
- Lint waivers removed; testbench in `run_sims.sh` and CI.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Shared read port.** `display_driver` also shows `result_rdata` ("result[0] low 16 bits" when `SW[1:0] = 01`). Hold `result_raddr` at 0 whenever the serializer is idle, or the display shows whichever word was read last.
- **Range check uses `TILE_COLS`, not `active_cols`.** That's what protocol §4.4 says, so reading columns past `active_cols` is legal and returns whatever the drain left there. The host is expected to read only real columns.
- `rd_count` is `COL_AW + 1` bits because 128 doesn't fit in 7.
- If the payload mux from A2 lives in this module, document the priority between its sources, even though the request/response protocol means only one can be active at a time.

## Files to read first (attach or paste these if you're using a chatbot)

- `rtl/fecim_pkg.sv`, `rtl/fecim_top.sv`
- `rtl/control/readout_ser.sv`
- `rtl/packet/packet_tx.sv`, `rtl/packet/packet_parser.sv`
- `rtl/result/result_buffer.sv`, `rtl/result/argmax_unit.sv` (for their ports)
- `tb/tb_packet_tx.sv`, `tb/run_sims.sh`
- `docs/plans and specs/03-lane-b-array/result-buffer-spec.md`
- `docs/plans and specs/01-contract/protocol.md`

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

