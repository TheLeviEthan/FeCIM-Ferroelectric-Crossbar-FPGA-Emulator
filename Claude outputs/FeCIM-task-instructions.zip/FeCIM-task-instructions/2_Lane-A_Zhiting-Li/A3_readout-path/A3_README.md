# A3 — Readout path: readout_ser to packet_tx for READ_RESULT and READ_ARGMAX

| | |
|---|---|
| **Owner** | Zhiting Li |
| **Due** | Sat 21 Nov |
| **Board bucket** | Bucket 2 — Lane A |
| **Board task** | A3: Readout path — `readout_ser` → `packet_tx` for `READ_RESULT` / `READ_ARGMAX` |
| **Needs first** | A2 (payload serializer pattern), K4 |
| **Unblocks** | C5, C8, D6 |
| **AI version** | `A3_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

The array's answers are 32-bit numbers sitting in a memory on the FPGA. The UART moves 8 bits at a time. `readout_ser` is the adapter between the two: it reads result words and hands them to the packet transmitter one byte at a time.

There are two ways to read an answer, and the project needs both:

- **`READ_RESULT`** returns the raw column sums. This is what proves the hardware is bit-exact against the C++ model, because we compare every number.
- **`READ_ARGMAX`** returns just the winning column, its value and the runner-up's value: 10 bytes instead of 512. A classifier only needs to know which column won, so this makes accuracy sweeps about four times faster. The runner-up lets us plot *decision margin*, which degrades smoothly with noise while accuracy falls off a cliff.

Byte order is where this goes wrong. A sign or endianness mistake only shows on negative values, and about half of our results are negative.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Implement:** `rtl/control/readout_ser.sv` (skeleton; if you extended it in A2, this adds the result and argmax sources to the same serializer).
- **New testbench:** `tb/sv/tb_readout_ser.sv`, added to `tb/run_sims.sh` and CI.
- **Connected to:** `packet_parser` (`rd_go`, `rd_argmax`, `rd_start`, `rd_count`), `result_buffer` (`result_raddr` out, `result_rdata` in, one-cycle registered read), `argmax_unit` (`argmax_idx`, `argmax_val`, `argmax_second`), `packet_tx` (`pl_data`, `pl_valid`, `pl_next`).
- **Specs:** `03-lane-b-array/result-buffer-spec.md` §6 and §9 tests 6–9; `01-contract/protocol.md` §2 (byte order), §4.4, §4.6.

## 3. How to build it

```text
IDLE:   result_raddr = 0                          // so the display can show result[0]
        on rd_go: latch rd_argmax, rd_start, rd_count
                  rd_argmax ? -> ARGMAX : (word = rd_start; left = rd_count; -> FETCH)

FETCH:  result_raddr = word; wait one cycle        // M9K read is registered
        buf = result_rdata; byte = 0; -> SEND

SEND:   on pl_next: pl_data = buf[8*byte +: 8]; pl_valid = 1 next cycle
        after 4 bytes: word++; left--;  left == 0 ? -> IDLE : -> FETCH

ARGMAX: 10 bytes, same handshake:
        {argmax_idx zero-extended to 16 bits} low byte, high byte
        argmax_val    bytes 0..3 (least significant first)
        argmax_second bytes 0..3
```

Don't build a prefetch. A UART byte takes about 540 clock cycles at 921600 baud, so a one-cycle memory read is invisible.

The parser already rejects bad ranges before `rd_go` (its `dispatch_status` returns `ST_ADDR_RANGE` when `start + count > TILE_COLS`), so the serializer can trust what it's given.

For the testbench, stand in for `result_buffer` with a small array pre-filled with known words, including `32'h8000_0000`, `-1`, `1` and `32'h1234_5678`. Drive `pl_next` the way `packet_tx` does and compare bytes.

## 4. How you know it's done

- `tb_readout_ser` passes: 1 word, 128 words, a mid-range start, and two requests back to back.
- A negative word comes out as its two's-complement bytes, least significant first, and `struct.unpack('<i', ...)` in Python gives back the original value.
- The `READ_ARGMAX` payload is exactly 10 bytes in the order above.
- Re-run with Megan's real `result_buffer` (B6) and `argmax_unit` (A4) once they merge.
- Lint waivers removed; testbench in `run_sims.sh` and CI.

## 5. Watch out for

- **Shared read port.** `display_driver` also shows `result_rdata` ("result[0] low 16 bits" when `SW[1:0] = 01`). Hold `result_raddr` at 0 whenever the serializer is idle, or the display shows whichever word was read last.
- **Range check uses `TILE_COLS`, not `active_cols`.** That's what protocol §4.4 says, so reading columns past `active_cols` is legal and returns whatever the drain left there. The host is expected to read only real columns.
- `rd_count` is `COL_AW + 1` bits because 128 doesn't fit in 7.
- If the payload mux from A2 lives in this module, document the priority between its sources, even though the request/response protocol means only one can be active at a time.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

