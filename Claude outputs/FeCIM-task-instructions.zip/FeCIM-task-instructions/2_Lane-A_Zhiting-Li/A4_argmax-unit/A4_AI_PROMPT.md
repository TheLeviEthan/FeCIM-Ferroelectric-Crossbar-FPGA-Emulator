# AI prompt — A4: argmax_unit with runner-up (moved from Lane B)

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **A4 — argmax_unit with runner-up (moved from Lane B)**, owned by Zhiting Li (Megan Mendez reviews), due Sat 21 Nov.

Implement `argmax_unit`: a streaming maximum, index and runner-up tracker over the post-ADC column results as they're written during the drain phase, with a self-checking testbench.

Add an `active_cols` input (16 bits, from the config registers) so that columns at or beyond it are ignored; the skeleton lacks this port although the spec requires the mask. Ties must keep the lowest index, matching `numpy.argmax` and the C++ model. Editable files: `rtl/result/argmax_unit.sv`, the `u_argmax_unit` instance in `rtl/fecim_top.sv`, `tb/sv/tb_argmax_unit.sv` (new), `tb/run_sims.sh`, `.github/workflows/ci.yml`.

State clearly in your reply what `argmax_second` holds when fewer than two valid columns have been seen, because the C++ model has to return the same value.

## Where the work goes

- **Implement:** `rtl/result/argmax_unit.sv` (skeleton). It's in Lane B's folder, so Megan reviews the PR.
- **Port change (K4):** add `input logic [15:0] active_cols` and connect it in `rtl/fecim_top.sv` (instance `u_argmax_unit`). The skeleton has no way to mask columns today.
- **New testbench:** `tb/sv/tb_argmax_unit.sv`, in `tb/run_sims.sh` and CI.
- **Inputs as wired today:** `clear` = `run_start`, `in_valid` = `drain_we`, `in_idx` = `drain_addr`, `in_val` = `adc_out` (post-ADC, signed 32-bit).
- **Specs:** `03-lane-b-array/result-buffer-spec.md` §5 and §9 tests 3–5; `01-contract/protocol.md` §4.6 and §6.3b.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```systemverilog
always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n || clear) begin                   // write the reset branch separately in real code
        max_val    <= 32'sh8000_0000;            // most negative int32
        second_val <= 32'sh8000_0000;
        max_idx    <= '0;
    end else if (in_valid && ({9'd0, in_idx} < active_cols)) begin
        if ($signed(in_val) > max_val) begin     // strict '>' : ties keep the LOWEST index
            second_val <= max_val;
            max_val    <= $signed(in_val);
            max_idx    <= in_idx;
        end else if ($signed(in_val) > second_val) begin
            second_val <= $signed(in_val);
        end
    end
end
```

Walk through a tie to convince yourself: if column 2 and column 5 both hold 900, column 2 arrives first and becomes the max. Column 5 isn't strictly greater, so the index stays 2, and the `else if` branch stores 900 as second place. Top two equal gives `second_val == max_val`, which is what test 5 expects.

Columns arrive in increasing index order (`drain_addr` counts 0 to 63 on pass 0, then 64 to 127), which is why "first seen wins" equals "lowest index wins".

Testbench: feed random vectors plus hand-built ties, and compare with a reference loop written in the testbench that scans all values and applies the same rule.

## Acceptance checks

- Matches a reference argmax over at least 10,000 random vectors, including ties at the maximum and vectors where every value is negative.
- With `active_cols = 10` and large values in columns 10 and up, those columns are ignored.
- `second_val` is right when the maximum is in column 0 and when it's in the last active column.
- `clear` between runs resets all three outputs.
- Megan has approved the PR; Ethan has confirmed the model's `argmax()` uses the same rules.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **`second_val` when `active_cols == 1`** is "undefined" in the protocol. This sketch leaves it at `0x8000_0000`. Tell Ethan the value you ship so `ModelExact::argmax()` returns the same thing; otherwise the full-design comparison (C5) fails on a field nobody uses.
- **Timing.** `chain_out → adc_quant (32-bit add and barrel shift) → 32-bit compare` is all combinational in one cycle. It should fit in 20 ns, but check it in A7. If it doesn't, register `adc_out` and delay `drain_we` / `drain_addr` by one cycle for both this module and `result_buffer`.
- Compare as signed. `in_val` is declared as a plain `logic` vector, so without `$signed` a negative value compares as a huge positive one.

## Files to read first (attach or paste these if you're using a chatbot)

- `rtl/fecim_pkg.sv`, `rtl/fecim_top.sv`
- `rtl/result/argmax_unit.sv`
- `rtl/array/adc_quant.sv`, `rtl/control/control_fsm.sv` (for the drain signals)
- `model/include/fecim/model_exact.h` (the `Argmax` struct and its comment)
- `tb/sv/tb_mac_lane.sv` (style), `tb/run_sims.sh`
- `docs/plans and specs/03-lane-b-array/result-buffer-spec.md`
- `docs/plans and specs/01-contract/protocol.md`

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

