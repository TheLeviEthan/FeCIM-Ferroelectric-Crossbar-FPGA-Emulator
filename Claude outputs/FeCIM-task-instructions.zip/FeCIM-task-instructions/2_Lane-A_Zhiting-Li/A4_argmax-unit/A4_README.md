# A4 — argmax_unit with runner-up (moved from Lane B)

| | |
|---|---|
| **Owner** | Zhiting Li (Megan Mendez reviews) |
| **Due** | Sat 21 Nov |
| **Board bucket** | Bucket 2 — Lane A |
| **Board task** | A4: `argmax_unit` with runner-up (moved from Lane B) |
| **Needs first** | K4 (adds the `active_cols` port) |
| **Unblocks** | A3 re-test, C5, D6 |
| **AI version** | `A4_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

A classifier's answer is "which output is largest". For our digit demo there are ten columns, one per digit, and the winning column is the prediction. `argmax_unit` finds that winner on the FPGA while the results stream past during `DRAIN`, so the host can ask for one small answer instead of every column.

It also tracks second place. The gap between first and second is the *decision margin*. As we turn up a non-ideality, accuracy stays flat and then collapses, but margin shrinks steadily the whole way. A margin plot shows the mechanism, which is a much stronger result to present than "accuracy dropped".

Two details make or break it. First, ties have to resolve to the lowest column index, exactly like `numpy.argmax` and exactly like the C++ model, because coarse ADC settings make ties common. Second, columns beyond `active_cols` hold garbage and must be ignored, or a 10-class problem can "predict" column 37.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Implement:** `rtl/result/argmax_unit.sv` (skeleton). It's in Lane B's folder, so Megan reviews the PR.
- **Port change (K4):** add `input logic [15:0] active_cols` and connect it in `rtl/fecim_top.sv` (instance `u_argmax_unit`). The skeleton has no way to mask columns today.
- **New testbench:** `tb/sv/tb_argmax_unit.sv`, in `tb/run_sims.sh` and CI.
- **Inputs as wired today:** `clear` = `run_start`, `in_valid` = `drain_we`, `in_idx` = `drain_addr`, `in_val` = `adc_out` (post-ADC, signed 32-bit).
- **Specs:** `03-lane-b-array/result-buffer-spec.md` §5 and §9 tests 3–5; `01-contract/protocol.md` §4.6 and §6.3b.

## 3. How to build it

```systemverilog
always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n || clear) begin                   // write the reset branch separately in real code
        max_val    <= 32'sh8000_0000;            // most negative int32
        second_val <= 32'sh8000_0000;
        max_idx    <= '0;
    end else if (in_valid && ({9'd0, in_idx} < active_cols)) begin
        if ($signed(in_val) > max_val) begin     // strict '>' : ties keep the LOWEST index
            second_val <= max_val;
            max_val    <= $signed(in_val);
            max_idx    <= in_idx;
        end else if ($signed(in_val) > second_val) begin
            second_val <= $signed(in_val);
        end
    end
end
```

Walk through a tie to convince yourself: if column 2 and column 5 both hold 900, column 2 arrives first and becomes the max. Column 5 isn't strictly greater, so the index stays 2, and the `else if` branch stores 900 as second place. Top two equal gives `second_val == max_val`, which is what test 5 expects.

Columns arrive in increasing index order (`drain_addr` counts 0 to 63 on pass 0, then 64 to 127), which is why "first seen wins" equals "lowest index wins".

Testbench: feed random vectors plus hand-built ties, and compare with a reference loop written in the testbench that scans all values and applies the same rule.

## 4. How you know it's done

- Matches a reference argmax over at least 10,000 random vectors, including ties at the maximum and vectors where every value is negative.
- With `active_cols = 10` and large values in columns 10 and up, those columns are ignored.
- `second_val` is right when the maximum is in column 0 and when it's in the last active column.
- `clear` between runs resets all three outputs.
- Megan has approved the PR; Ethan has confirmed the model's `argmax()` uses the same rules.

## 5. Watch out for

- **`second_val` when `active_cols == 1`** is "undefined" in the protocol. This sketch leaves it at `0x8000_0000`. Tell Ethan the value you ship so `ModelExact::argmax()` returns the same thing; otherwise the full-design comparison (C5) fails on a field nobody uses.
- **Timing.** `chain_out → adc_quant (32-bit add and barrel shift) → 32-bit compare` is all combinational in one cycle. It should fit in 20 ns, but check it in A7. If it doesn't, register `adc_out` and delay `drain_we` / `drain_addr` by one cycle for both this module and `result_buffer`.
- Compare as signed. `in_val` is declared as a plain `logic` vector, so without `$signed` a negative value compares as a huge positive one.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

