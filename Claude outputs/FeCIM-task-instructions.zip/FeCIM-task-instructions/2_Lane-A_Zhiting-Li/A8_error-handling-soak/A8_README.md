# A8 — Error handling, recovery and soak test

| | |
|---|---|
| **Owner** | Zhiting Li |
| **Due** | Fri 27 Nov |
| **Board bucket** | Bucket 2 — Lane A |
| **Board task** | A8: Error handling, recovery and soak test |
| **Needs first** | A3, C8 (hardware check script), D2 |
| **Unblocks** | X2 dry run confidence, A9 |
| **AI version** | `A8_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

A demo fails in boring ways: a cable gets bumped, a byte is dropped, a script crashes halfway through sending a packet. A lab instrument has to shrug those off. If the only fix is unplugging the board, we don't have an instrument, we have a prototype.

This task makes the link self-healing and then proves it. The protocol already has the pieces: every packet has a CRC, the parser gives up on a stalled packet after 100 ms, and the host waits and retries. What's missing is evidence that these work together on real hardware, and one or two code paths (like "busy") that have never been exercised.

The soak test is the evidence: an hour of random commands and computes with the hardware checked against the model throughout, ending with zero hangs and zero mismatches. That's a sentence we can say in the presentation with a log file behind it.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Parser:** `rtl/packet/packet_parser.sv` (timeout uses `TIMEOUT_CYCLES` from the package). Extend `tb/tb_packet_parser.sv` for the recovery cases.
- **Soft reset:** `CTRL[0]` comes out of `rtl/control/config_regs.sv` as `soft_reset` and currently reaches only `control_fsm`.
- **Soak script:** new `sw/examples/soak_test.py`, built on Natalie's driver and Ethan's hardware-versus-model check (C8).
- **Log:** `results/soak/soak_<date>.log`, committed.
- **Documentation:** a "Recovery behaviour" section in `docs/plans and specs/02-lane-a-interface/hardware.md`.
- **Specs:** `01-contract/protocol.md` §7; `packet-parser-spec.md`; `05-lane-d-host/host-driver-spec.md` §4.2–4.3.

## 3. How to build it

**Simulation cases (add to `tb_packet_parser`):**

```text
1. truncated packet:  send A5, CMD, LEN, half the payload, then nothing
                      -> after TIMEOUT_CYCLES the parser is back in PKT_HUNT
                      -> the next complete packet gets a normal ST_OK reply
2. garbage then sync: random bytes, then a valid packet -> valid reply
3. LEN > MAX_PAYLOAD: rejected at the length field with ST_BAD_LEN
4. COMPUTE while busy (KEY1 compute running): ST_BUSY, running compute unaffected
5. bulk write with a bad CRC, then the same chunk resent correctly: memory ends up correct
```

Shrink the timeout with a testbench parameter so case 1 doesn't simulate five million cycles.

**Soak loop (hardware):**

```python
for i in range(N):                     # run for at least an hour
    cfg = random_config(rng)           # tile size, NOISE_EN mask, sigmas, seed, ADC bits
    W, x = random_weights(rng), random_activations(rng)
    ok = check_hw_vs_model(xbar, cfg, W, x)      # Ethan's C8 function
    log(i, cfg, ok)
    if i % 50 == 0:
        inject_fault(port)             # e.g. write half a packet, or a bad CRC
        time.sleep(0.2)                # then carry on: the next command must work
info = xbar.identify()                 # error counters at the end
```

## 4. How you know it's done

- All five simulation cases pass in `tb_packet_parser`.
- On hardware: a truncated packet followed 200 ms later by `IDENTIFY` succeeds without a reset.
- `CTRL[0]` returns the FSM to `IDLE` mid-compute and the link still works at the current baud rate.
- Soak: at least one hour, zero hangs, zero model mismatches. The identify block's CRC and timeout counters equal the number of faults injected on purpose.
- The log is committed and `hardware.md` documents what each kind of error does and how the host recovers.

## 5. Watch out for

- **What does soft reset reset?** The protocol says `CTRL[0]` is "soft reset" and no more. Decide and document it: the sensible rule is that it returns state machines to idle and keeps every config register, including `BAUD_INC`, so the link survives. Ethan's `set_reg(REG_CTRL, 1)` must do the same.
- **A soft reset mid-compute leaves the lane LFSRs partway through their sequence.** The next noisy compute won't match the model unless the host reseeds (`CTRL[2]`). Either document that or make soft reset reseed too, and tell Ethan which.
- A half-written bulk chunk leaves that chunk's memory partly updated. That's by design (protocol §4.1): the host resends the chunk.
- The driver must wait 100 ms after any error before retrying (protocol §7). If the soak shows retries failing, check that first.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

