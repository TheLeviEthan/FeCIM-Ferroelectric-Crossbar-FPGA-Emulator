# AI prompt — A8: Error handling, recovery and soak test

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **A8 — Error handling, recovery and soak test**, owned by Zhiting Li, due Fri 27 Nov.

Harden the host link and build the evidence that it recovers from faults. Three deliverables: (1) new recovery test cases in `tb/tb_packet_parser.sv`, with any parser fixes they expose; (2) `sw/examples/soak_test.py`, a long-running randomized hardware test that injects link faults on purpose and checks every compute against the C++ model through the existing check function; (3) a short "Recovery behaviour" section for `hardware.md`.

Before writing code, state precisely what `CTRL[0]` soft reset should and shouldn't clear, based on the specs, and flag it as a decision for the owner if the specs don't say. Editable files: `rtl/packet/packet_parser.sv`, `rtl/control/control_fsm.sv`, `rtl/control/config_regs.sv`, `tb/tb_packet_parser.sv`, `sw/examples/soak_test.py` (new), `docs/plans and specs/02-lane-a-interface/hardware.md`. Use the driver's public API as it exists; don't modify files under `sw/fecim/` (Lane D).

## Where the work goes

- **Parser:** `rtl/packet/packet_parser.sv` (timeout uses `TIMEOUT_CYCLES` from the package). Extend `tb/tb_packet_parser.sv` for the recovery cases.
- **Soft reset:** `CTRL[0]` comes out of `rtl/control/config_regs.sv` as `soft_reset` and currently reaches only `control_fsm`.
- **Soak script:** new `sw/examples/soak_test.py`, built on Natalie's driver and Ethan's hardware-versus-model check (C8).
- **Log:** `results/soak/soak_<date>.log`, committed.
- **Documentation:** a "Recovery behaviour" section in `docs/plans and specs/02-lane-a-interface/hardware.md`.
- **Specs:** `01-contract/protocol.md` §7; `packet-parser-spec.md`; `05-lane-d-host/host-driver-spec.md` §4.2–4.3.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

**Simulation cases (add to `tb_packet_parser`):**

```text
1. truncated packet:  send A5, CMD, LEN, half the payload, then nothing
                      -> after TIMEOUT_CYCLES the parser is back in PKT_HUNT
                      -> the next complete packet gets a normal ST_OK reply
2. garbage then sync: random bytes, then a valid packet -> valid reply
3. LEN > MAX_PAYLOAD: rejected at the length field with ST_BAD_LEN
4. COMPUTE while busy (KEY1 compute running): ST_BUSY, running compute unaffected
5. bulk write with a bad CRC, then the same chunk resent correctly: memory ends up correct
```

Shrink the timeout with a testbench parameter so case 1 doesn't simulate five million cycles.

**Soak loop (hardware):**

```python
for i in range(N):                     # run for at least an hour
    cfg = random_config(rng)           # tile size, NOISE_EN mask, sigmas, seed, ADC bits
    W, x = random_weights(rng), random_activations(rng)
    ok = check_hw_vs_model(xbar, cfg, W, x)      # Ethan's C8 function
    log(i, cfg, ok)
    if i % 50 == 0:
        inject_fault(port)             # e.g. write half a packet, or a bad CRC
        time.sleep(0.2)                # then carry on: the next command must work
info = xbar.identify()                 # error counters at the end
```

## Acceptance checks

- All five simulation cases pass in `tb_packet_parser`.
- On hardware: a truncated packet followed 200 ms later by `IDENTIFY` succeeds without a reset.
- `CTRL[0]` returns the FSM to `IDLE` mid-compute and the link still works at the current baud rate.
- Soak: at least one hour, zero hangs, zero model mismatches. The identify block's CRC and timeout counters equal the number of faults injected on purpose.
- The log is committed and `hardware.md` documents what each kind of error does and how the host recovers.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **What does soft reset reset?** The protocol says `CTRL[0]` is "soft reset" and no more. Decide and document it: the sensible rule is that it returns state machines to idle and keeps every config register, including `BAUD_INC`, so the link survives. Ethan's `set_reg(REG_CTRL, 1)` must do the same.
- **A soft reset mid-compute leaves the lane LFSRs partway through their sequence.** The next noisy compute won't match the model unless the host reseeds (`CTRL[2]`). Either document that or make soft reset reseed too, and tell Ethan which.
- A half-written bulk chunk leaves that chunk's memory partly updated. That's by design (protocol §4.1): the host resends the chunk.
- The driver must wait 100 ms after any error before retrying (protocol §7). If the soak shows retries failing, check that first.

## Files to read first (attach or paste these if you're using a chatbot)

- `rtl/fecim_pkg.sv`, `rtl/packet/packet_parser.sv`, `rtl/control/control_fsm.sv`, `rtl/control/config_regs.sv`
- `tb/tb_packet_parser.sv`
- `sw/fecim/crossbar.py` and the backend/driver files as they exist, plus the C8 check script
- `docs/plans and specs/01-contract/protocol.md` (§5–7)
- `docs/plans and specs/02-lane-a-interface/packet-parser-spec.md`, `hardware.md`
- `docs/plans and specs/05-lane-d-host/host-driver-spec.md` (§4)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

