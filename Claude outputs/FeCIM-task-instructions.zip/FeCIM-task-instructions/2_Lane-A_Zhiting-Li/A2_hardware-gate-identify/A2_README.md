# A2 — IDENTIFY, SET_CONFIG and GET_CONFIG on hardware at 921600 (hardware gate)

| | |
|---|---|
| **Owner** | Zhiting Li |
| **Due** | Thu 19 Nov |
| **Board bucket** | Bucket 2 — Lane A |
| **Board task** | A2: `IDENTIFY`, `SET_CONFIG` / `GET_CONFIG` on hardware at 921600 (hardware gate) |
| **Needs first** | K2 (your branch merged), K4, D2 on Natalie's side |
| **Unblocks** | A5, A6, C8, D6, every hardware task |
| **AI version** | `A2_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

This is the first real conversation between the laptop and the FPGA. Until now the board has only echoed bytes. After this task, the Python driver sends a framed packet, the FPGA parses it, checks its CRC, acts on it and sends a framed reply.

`IDENTIFY` is the handshake. The board answers with a magic number (`0xFEC1`), the protocol version, a build ID and its geometry (64 lanes, 128×128). The driver refuses to continue if the magic or version is wrong. That one check turns "the numbers look wrong" into "your bitstream is stale", which saves hours.

`SET_CONFIG` and `GET_CONFIG` are how every experiment is set up. The six non-idealities, the tile size, the seed and the baud rate are all registers. If we can write a register and read it back on real hardware, the whole control plane works.

Everything later (loading weights, `COMPUTE`, reading results) uses the same link. This was the plan's original week-3 gate and it's still open, which is why it's demonstrated live at the Thursday meeting.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Top level:** `rtl/fecim_top.sv` is already the board-level top (it's the only module with device pins). You don't need a separate wrapper.
- **Response payload source (the gap to close):** `rtl/packet/packet_tx.sv` pulls payload bytes through `pl_next` / `pl_valid` / `pl_data`, and the only thing connected to that is `rtl/control/readout_ser.sv`, which is a skeleton with no access to `cfg_rdata` or the identify fields. Add the `IDENTIFY` and `GET_CONFIG` payloads to `readout_ser` (new inputs needed), or add a small payload mux module beside it. Update the instance in `fecim_top.sv`.
- **Parser:** `rtl/packet/packet_parser.sv` sets `resp_len` to 16 for `IDENTIFY` and 4 for `GET_CONFIG`. Check that it also drives `cfg_addr` for a read, and expose separate CRC-error and timeout counters (it has only a combined `err_cnt`).
- **Quartus:** new `quartus/fecim/create_project.tcl` (copy the pattern in `quartus/dsp_pack_test/create_project.tcl`), top entity `fecim_top`, device `10M50DAF484C7G`. Constraints: `quartus/fecim.sdc` from `top-level-spec.md` §5.
- **Pins:** `quartus/pins.tcl` only covers the UART demo: the clock, `KEY[0]`, `HEX0[6:0]`, `LEDR[9:0]` and `ARDUINO_IO[0..1]` as a vector. `fecim_top` needs `KEY[1]`, `SW[9:0]`, `HEX0`–`HEX5` all 8 bits wide, and the scalar port names `ARDUINO_IO0` / `ARDUINO_IO1`. `docs/plans and specs/02-lane-a-interface/hardware.md` gives the locations for `KEY[1]` and the two UART pins, and says `ARDUINO_IO0` needs its weak pull-up enabled. It also says to copy the `SW`, `LEDR` and `HEX` assignments from Terasic's DE10-Lite system files, not to type them from memory. The same document has a bring-up checklist worth following in order.
- **Simulation first:** new `tb/sv/tb_identify.sv` that feeds a framed `IDENTIFY` into the parser's `rx_data` / `rx_valid` and checks the bytes `packet_tx` sends.
- **Specs:** `01-contract/protocol.md` §3 (frame), §4.5 (identify block), §6 (register map and access policy); `02-lane-a-interface/top-level-spec.md`; `hardware.md` (wiring and the 3.3 V check).

## 3. How to build it

**1. Give the response a payload source.** `IDENTIFY` returns 16 bytes, little-endian (protocol §4.5):

```text
offset 0  : MAGIC[7:0], MAGIC[15:8]            // 0xC1, 0xFE
offset 2  : PROTO_VER                          // 0x02
offset 3  : BUILD_ID
offset 4  : NUM_LANES  (2 bytes)               // 64
offset 6  : TILE_ROWS  (2 bytes)               // 128
offset 8  : TILE_COLS  (2 bytes)               // 128
offset 10 : UART framing error count (2 bytes)
offset 12 : CRC error count (2 bytes)
offset 14 : timeout count (2 bytes)
```

`GET_CONFIG` returns `cfg_rdata` as 4 bytes, least significant first. The serializer pattern is the same one A3 needs:

```text
on resp_valid for IDENTIFY / GET_CONFIG: latch the 16 or 4 bytes into a shift buffer
each time packet_tx pulses pl_next:      present the next byte, raise pl_valid
```

`packet_tx` pulses `pl_next` for one cycle and then waits for `pl_valid`, so answer in the following cycle.

**2. Simulate it.** In `tb_identify.sv`, send `A5 06 00 00 <crc>` and compare the reply to `5A 00 10 00 <16 bytes> <crc>`. Then a `SET_CONFIG` / `GET_CONFIG` pair. Use `fecim_pkg::crc8_byte` to build the CRCs.

**3. Build and program.**

```bash
cd quartus/fecim
quartus_sh -t create_project.tcl
quartus_sh --flow compile fecim
# program output_files/fecim.sof with the Windows Quartus Programmer
```

**4. Wire and check the dongle** exactly as `hardware.md` says: set the jumper to 3.3 V and meter the idle TX pin *before* connecting. Dongle TX goes to `ARDUINO_IO0` (FPGA rxd), dongle RX to `ARDUINO_IO1` (FPGA txd), and GND to GND.

**5. Run it with Natalie's driver.** The board boots at 115200 (`BAUD_INC = 2416`). Sequence: open at 115200, `IDENTIFY`, write `BAUD_INC = 19327`, reopen at 921600, `IDENTIFY` again.

## 4. How you know it's done

- `tb_identify` passes and is in `tb/run_sims.sh`.
- On the board, `IDENTIFY` prints magic `0xFEC1`, protocol 2, the build ID, 64 lanes, 128 rows, 128 columns.
- Every RW register round-trips through `SET_CONFIG` / `GET_CONFIG`: `TILE_CFG`, `QUANT_LEVELS`, `QUANT_MULT`, `D2D_SIGMA`, `READ_SIGMA`, `NOISE_SEED`, `NOISE_EN`, `ADC_BITS`, `STUCK_RATE`.
- Reset defaults read back as in `control-fsm-spec.md` §6.3 (`QUANT_LEVELS` 255, `QUANT_MULT` 257, `ADC_BITS` 24, `BAUD_INC` 2416).
- `SET_CONFIG` to `STATUS` returns `ST_ADDR_RANGE`. A packet with a wrong CRC returns `ST_CRC_ERR`.
- The link works at 921600 after the baud switch.
- A 30-second backup recording exists, and the demo runs live at the Thu 19 meeting.

## 5. Watch out for

- **Without step 1, `IDENTIFY` hangs.** `packet_tx` sits in `S_PAYLOAD_WAIT` forever, because nothing ever raises `pl_valid`. A comment in the parser says "`cfg_rdata` is consumed by `packet_tx` via its own config read path", but `packet_tx` has no such input. This is the single most likely reason for the Thursday demo to fail, so do it first.
- **The baud switch races its own reply.** The reply to `SET_CONFIG(BAUD_INC)` may go out at the old rate, the new rate, or change mid-byte. Decide the rule (simplest: the register takes effect only after the reply's last byte has left `uart_tx`), implement it, and tell Natalie what the driver should expect.
- **Error counters.** The identify block wants three separate counts. `uart_rx` gives a `rx_frame_err` pulse, but the parser lumps CRC errors and timeouts into one `err_cnt`. Split them.
- **`result_seq`** in `STATUS[15:8]` is hard-coded to 0 in your `config_regs`. It gets a real source in B6; leave a `TODO` that names it.
- Program the board from a clone whose path has no spaces. The WSL notes in `quartus/README.md` apply.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

