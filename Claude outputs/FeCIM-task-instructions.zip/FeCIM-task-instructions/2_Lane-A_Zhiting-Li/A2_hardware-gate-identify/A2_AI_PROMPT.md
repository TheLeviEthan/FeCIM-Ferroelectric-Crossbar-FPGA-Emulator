# AI prompt — A2: IDENTIFY, SET_CONFIG and GET_CONFIG on hardware at 921600 (hardware gate)

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **A2 — IDENTIFY, SET_CONFIG and GET_CONFIG on hardware at 921600 (hardware gate)**, owned by Zhiting Li, due Thu 19 Nov.

Close the gap that currently prevents the FPGA from answering `IDENTIFY` and `GET_CONFIG`, prove it in simulation, and produce the Quartus project files needed to put `fecim_top` on a DE10-Lite.

Concretely: (1) give `packet_tx` a real payload source for the 16-byte identify block and the 4-byte config read, either by extending `rtl/control/readout_ser.sv` or by adding a small payload mux, and wire it in `rtl/fecim_top.sv`; (2) check the parser's `cfg_addr` handling for reads and split its error counter into CRC and timeout counts; (3) write `tb/sv/tb_identify.sv`; (4) write `quartus/fecim/create_project.tcl`, `quartus/fecim.sdc` and an extended pin file covering every port of `fecim_top`.

You can't program the board, so be explicit about what the owner has to verify on hardware. The array-side modules are still skeletons with tied-off outputs; that's expected for this task and they don't need to change. Editable files: anything under `rtl/control/`, `rtl/packet/`, `rtl/fecim_top.sv`, `quartus/` and `tb/`. Don't change `fecim_pkg.sv` or anything under `rtl/array/`, `rtl/write/`, `rtl/result/`.

For pin locations, use only what's in `hardware.md`, `pins.tcl` or a DE10-Lite document the user gives you. If a pin isn't listed there, leave a clearly marked placeholder; a wrong pin assignment can damage the board.

## Where the work goes

- **Top level:** `rtl/fecim_top.sv` is already the board-level top (it's the only module with device pins). You don't need a separate wrapper.
- **Response payload source (the gap to close):** `rtl/packet/packet_tx.sv` pulls payload bytes through `pl_next` / `pl_valid` / `pl_data`, and the only thing connected to that is `rtl/control/readout_ser.sv`, which is a skeleton with no access to `cfg_rdata` or the identify fields. Add the `IDENTIFY` and `GET_CONFIG` payloads to `readout_ser` (new inputs needed), or add a small payload mux module beside it. Update the instance in `fecim_top.sv`.
- **Parser:** `rtl/packet/packet_parser.sv` sets `resp_len` to 16 for `IDENTIFY` and 4 for `GET_CONFIG`. Check that it also drives `cfg_addr` for a read, and expose separate CRC-error and timeout counters (it has only a combined `err_cnt`).
- **Quartus:** new `quartus/fecim/create_project.tcl` (copy the pattern in `quartus/dsp_pack_test/create_project.tcl`), top entity `fecim_top`, device `10M50DAF484C7G`. Constraints: `quartus/fecim.sdc` from `top-level-spec.md` §5.
- **Pins:** `quartus/pins.tcl` only covers the UART demo: the clock, `KEY[0]`, `HEX0[6:0]`, `LEDR[9:0]` and `ARDUINO_IO[0..1]` as a vector. `fecim_top` needs `KEY[1]`, `SW[9:0]`, `HEX0`–`HEX5` all 8 bits wide, and the scalar port names `ARDUINO_IO0` / `ARDUINO_IO1`. `docs/plans and specs/02-lane-a-interface/hardware.md` gives the locations for `KEY[1]` and the two UART pins, and says `ARDUINO_IO0` needs its weak pull-up enabled. It also says to copy the `SW`, `LEDR` and `HEX` assignments from Terasic's DE10-Lite system files, not to type them from memory. The same document has a bring-up checklist worth following in order.
- **Simulation first:** new `tb/sv/tb_identify.sv` that feeds a framed `IDENTIFY` into the parser's `rx_data` / `rx_valid` and checks the bytes `packet_tx` sends.
- **Specs:** `01-contract/protocol.md` §3 (frame), §4.5 (identify block), §6 (register map and access policy); `02-lane-a-interface/top-level-spec.md`; `hardware.md` (wiring and the 3.3 V check).

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

**1. Give the response a payload source.** `IDENTIFY` returns 16 bytes, little-endian (protocol §4.5):

```text
offset 0  : MAGIC[7:0], MAGIC[15:8]            // 0xC1, 0xFE
offset 2  : PROTO_VER                          // 0x02
offset 3  : BUILD_ID
offset 4  : NUM_LANES  (2 bytes)               // 64
offset 6  : TILE_ROWS  (2 bytes)               // 128
offset 8  : TILE_COLS  (2 bytes)               // 128
offset 10 : UART framing error count (2 bytes)
offset 12 : CRC error count (2 bytes)
offset 14 : timeout count (2 bytes)
```

`GET_CONFIG` returns `cfg_rdata` as 4 bytes, least significant first. The serializer pattern is the same one A3 needs:

```text
on resp_valid for IDENTIFY / GET_CONFIG: latch the 16 or 4 bytes into a shift buffer
each time packet_tx pulses pl_next:      present the next byte, raise pl_valid
```

`packet_tx` pulses `pl_next` for one cycle and then waits for `pl_valid`, so answer in the following cycle.

**2. Simulate it.** In `tb_identify.sv`, send `A5 06 00 00 <crc>` and compare the reply to `5A 00 10 00 <16 bytes> <crc>`. Then a `SET_CONFIG` / `GET_CONFIG` pair. Use `fecim_pkg::crc8_byte` to build the CRCs.

**3. Build and program.**

```bash
cd quartus/fecim
quartus_sh -t create_project.tcl
quartus_sh --flow compile fecim
# program output_files/fecim.sof with the Windows Quartus Programmer
```

**4. Wire and check the dongle** exactly as `hardware.md` says: set the jumper to 3.3 V and meter the idle TX pin *before* connecting. Dongle TX goes to `ARDUINO_IO0` (FPGA rxd), dongle RX to `ARDUINO_IO1` (FPGA txd), and GND to GND.

**5. Run it with Natalie's driver.** The board boots at 115200 (`BAUD_INC = 2416`). Sequence: open at 115200, `IDENTIFY`, write `BAUD_INC = 19327`, reopen at 921600, `IDENTIFY` again.

## Acceptance checks

- `tb_identify` passes and is in `tb/run_sims.sh`.
- On the board, `IDENTIFY` prints magic `0xFEC1`, protocol 2, the build ID, 64 lanes, 128 rows, 128 columns.
- Every RW register round-trips through `SET_CONFIG` / `GET_CONFIG`: `TILE_CFG`, `QUANT_LEVELS`, `QUANT_MULT`, `D2D_SIGMA`, `READ_SIGMA`, `NOISE_SEED`, `NOISE_EN`, `ADC_BITS`, `STUCK_RATE`.
- Reset defaults read back as in `control-fsm-spec.md` §6.3 (`QUANT_LEVELS` 255, `QUANT_MULT` 257, `ADC_BITS` 24, `BAUD_INC` 2416).
- `SET_CONFIG` to `STATUS` returns `ST_ADDR_RANGE`. A packet with a wrong CRC returns `ST_CRC_ERR`.
- The link works at 921600 after the baud switch.
- A 30-second backup recording exists, and the demo runs live at the Thu 19 meeting.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Without step 1, `IDENTIFY` hangs.** `packet_tx` sits in `S_PAYLOAD_WAIT` forever, because nothing ever raises `pl_valid`. A comment in the parser says "`cfg_rdata` is consumed by `packet_tx` via its own config read path", but `packet_tx` has no such input. This is the single most likely reason for the Thursday demo to fail, so do it first.
- **The baud switch races its own reply.** The reply to `SET_CONFIG(BAUD_INC)` may go out at the old rate, the new rate, or change mid-byte. Decide the rule (simplest: the register takes effect only after the reply's last byte has left `uart_tx`), implement it, and tell Natalie what the driver should expect.
- **Error counters.** The identify block wants three separate counts. `uart_rx` gives a `rx_frame_err` pulse, but the parser lumps CRC errors and timeouts into one `err_cnt`. Split them.
- **`result_seq`** in `STATUS[15:8]` is hard-coded to 0 in your `config_regs`. It gets a real source in B6; leave a `TODO` that names it.
- Program the board from a clone whose path has no spaces. The WSL notes in `quartus/README.md` apply.

## Files to read first (attach or paste these if you're using a chatbot)

- `rtl/fecim_pkg.sv`, `rtl/fecim_top.sv`
- `rtl/packet/packet_parser.sv`, `rtl/packet/packet_tx.sv`
- `rtl/control/readout_ser.sv`, `rtl/control/config_regs.sv` (the implemented version from the `Zhiting` branch)
- `quartus/pins.tcl`, `quartus/dsp_pack_test/create_project.tcl`, `quartus/README.md`
- `tb/tb_packet_tx.sv`, `tb/tb_packet_parser.sv`, `tb/run_sims.sh`
- `docs/plans and specs/01-contract/protocol.md`
- `docs/plans and specs/02-lane-a-interface/top-level-spec.md`, `hardware.md`, `packet-parser-spec.md`

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

