# AI prompt — A7: Timing closure at 50 MHz, 64 lanes, all non-idealities

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **A7 — Timing closure at 50 MHz, 64 lanes, all non-idealities**, owned by Zhiting Li, due Tue 24 Nov.

Help close timing at 50 MHz on the full FeCIM design. Deliver the `.sdc` (if it doesn't exist yet), then work from whatever timing reports the owner provides: identify each failing or near-failing path by module and pipeline stage, explain in plain terms why it's slow, and propose the least invasive fix.

Treat any change to pipeline depth as a cross-team change: list every file in every lane that has to change with it (package, lane RTL, activation buffer, C++ parameters, golden vectors, co-sim) and don't present it as a one-line fix. If you can't run Quartus, say so and give exact commands and the report sections to paste back. Editable files: `quartus/fecim.sdc`, `quartus/fecim/`, and Lane A RTL under `rtl/control/`, `rtl/packet/`, `rtl/uart/`. For anything under `rtl/array/`, `rtl/write/` or `rtl/result/`, write the proposed change for Megan instead of making it.

## Where the work goes

- **Constraints:** `quartus/fecim.sdc` (from A2; contents in `top-level-spec.md` §5).
- **Reports to commit:** `quartus/reports/fecim.sta.summary`, plus the worst-path listing as text.
- **If the fallback is needed, these change together:** `rtl/fecim_pkg.sv` (`LANE_PIPE_DEPTH`), `rtl/array/mac_lane.sv`, `rtl/array/act_buffer.sv`, `model/include/fecim/params.h`, `tb/golden/mac_lane/` (regenerate), and the co-sim harnesses.
- **Specs:** `top-level-spec.md` §5; `activation-buffer-spec.md` §4.2; `mac-array-spec.md` §5.5 and §12 test 12.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```tcl
# quartus/fecim.sdc
create_clock -name clk -period 20.000 [get_ports MAX10_CLK1_50]
derive_clock_uncertainty
set_false_path -from [get_ports ARDUINO_IO0]
set_false_path -from [get_ports {KEY[*]}]
set_false_path -from [get_ports {SW[*]}]
set_false_path -to   [get_ports {LEDR[*]}]
set_false_path -to   [get_ports {HEX0[*] HEX1[*] HEX2[*] HEX3[*] HEX4[*] HEX5[*]}]
set_false_path -to   [get_ports ARDUINO_IO1]
```

```bash
quartus_sh --flow compile fecim
quartus_sta fecim -c fecim          # or read output_files/fecim.sta.rpt
```

Look at the **Slow 1200mV 85C** model, setup and hold. Then list the ten worst setup paths and identify each by its start and end register.

Where to expect trouble, in order:

1. **Lane cycle N+2:** `w_align + noise_q`, then the 9×9 multiply into `prod`.
2. **Activation path:** M9K output, IR multiply, broadcast register, then a net that fans out to 64 lanes.
3. **Drain output:** `chain_out`, ADC add and shift, argmax compare.
4. **Write path:** the 16×16 hash multiplies. It has thousands of cycles of slack in practice, so just add pipeline registers.

Fixes, cheapest first: let Quartus duplicate the high-fanout broadcast register; pipeline the write path; register `adc_out`. Last resort for path 1 is the spec's fallback: add a register between the add and the multiply, set `LANE_PIPE_DEPTH = 4`, and add a matching stage on the activation path.

## Acceptance checks

- Setup and hold slack are positive at the slow corner with `NUM_LANES = 64`.
- `fecim.sta.summary` and the worst-path listing are committed.
- If anything in the pipeline changed, the package, model, golden vectors and co-sim were all updated in the same PR series and L2 (task C5) is green again.
- The timed bitstream passes Ethan's hardware-versus-model check (C8).

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **A pipeline change is a four-lane change.** `LANE_PIPE_DEPTH` is read by the FSM, the model, the golden-vector generator and both co-sim harnesses. Tell Ethan and Megan within the hour, not in the PR description.
- **The LFSR reset.** The spec's code resets each lane's LFSR asynchronously to `seed_eff`, which isn't a constant. Quartus has to build asynchronous-load logic for that and may warn about it or produce recovery-time violations. If so, ask Megan to reset to the constant `(LANE_SALT | 1)`, which is the same value because `NOISE_SEED` is 0 at reset, and rely on the synchronous `reseed`.
- A design can meet timing at the fast corner and fail at the slow one. Report the slow corner.
- Don't lower the clock to make timing pass. The 7.84 µs latency claim assumes 50 MHz.

## Files to read first (attach or paste these if you're using a chatbot)

- `quartus/fecim.sdc`, `quartus/fecim/create_project.tcl`
- The timing analyzer summary and the worst-path report
- `rtl/fecim_pkg.sv`, `rtl/array/mac_lane.sv`, `rtl/array/read_noise.sv`, `rtl/array/act_buffer.sv`, `rtl/array/adc_quant.sv`, `rtl/write/write_path.sv`
- `docs/plans and specs/02-lane-a-interface/top-level-spec.md` (§5)
- `docs/plans and specs/03-lane-b-array/activation-buffer-spec.md` (§4)
- `docs/plans and specs/03-lane-b-array/mac-array-spec.md` (§5.5, §12)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

