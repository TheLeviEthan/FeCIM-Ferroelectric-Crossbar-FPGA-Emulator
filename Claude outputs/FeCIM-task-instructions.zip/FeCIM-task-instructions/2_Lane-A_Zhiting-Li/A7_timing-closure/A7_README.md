# A7 — Timing closure at 50 MHz, 64 lanes, all non-idealities

| | |
|---|---|
| **Owner** | Zhiting Li |
| **Due** | Tue 24 Nov |
| **Board bucket** | Bucket 2 — Lane A |
| **Board task** | A7: Timing closure at 50 MHz, 64 lanes, all non-idealities |
| **Needs first** | A5 with B3, B4, B5 merged |
| **Unblocks** | C8 (hardware check), G4 |
| **AI version** | `A7_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Every signal in the FPGA has to get from one flip-flop to the next within one clock period. At 50 MHz that's 20 nanoseconds. If the slowest path takes 21 ns, the design still passes every simulation, because simulation doesn't model wire delay, and then gives occasional wrong answers on the real board. Those errors look exactly like a noise-model bug, which is the worst possible confusion for a project that's *about* injected noise.

Timing analysis is how we rule that out. The tool computes the delay of every path and reports the worst one as *slack*: positive slack means there's time to spare, negative means the design can fail.

We know where the risk is. In each lane, one cycle contains an add (weight plus noise) followed by a 9×9 multiply. The specs call this out as the tightest path and give a fallback. Closing timing with all six non-idealities enabled is what lets us say that the hardware result is the designed result.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Constraints:** `quartus/fecim.sdc` (from A2; contents in `top-level-spec.md` §5).
- **Reports to commit:** `quartus/reports/fecim.sta.summary`, plus the worst-path listing as text.
- **If the fallback is needed, these change together:** `rtl/fecim_pkg.sv` (`LANE_PIPE_DEPTH`), `rtl/array/mac_lane.sv`, `rtl/array/act_buffer.sv`, `model/include/fecim/params.h`, `tb/golden/mac_lane/` (regenerate), and the co-sim harnesses.
- **Specs:** `top-level-spec.md` §5; `activation-buffer-spec.md` §4.2; `mac-array-spec.md` §5.5 and §12 test 12.

## 3. How to build it

```tcl
# quartus/fecim.sdc
create_clock -name clk -period 20.000 [get_ports MAX10_CLK1_50]
derive_clock_uncertainty
set_false_path -from [get_ports ARDUINO_IO0]
set_false_path -from [get_ports {KEY[*]}]
set_false_path -from [get_ports {SW[*]}]
set_false_path -to   [get_ports {LEDR[*]}]
set_false_path -to   [get_ports {HEX0[*] HEX1[*] HEX2[*] HEX3[*] HEX4[*] HEX5[*]}]
set_false_path -to   [get_ports ARDUINO_IO1]
```

```bash
quartus_sh --flow compile fecim
quartus_sta fecim -c fecim          # or read output_files/fecim.sta.rpt
```

Look at the **Slow 1200mV 85C** model, setup and hold. Then list the ten worst setup paths and identify each by its start and end register.

Where to expect trouble, in order:

1. **Lane cycle N+2:** `w_align + noise_q`, then the 9×9 multiply into `prod`.
2. **Activation path:** M9K output, IR multiply, broadcast register, then a net that fans out to 64 lanes.
3. **Drain output:** `chain_out`, ADC add and shift, argmax compare.
4. **Write path:** the 16×16 hash multiplies. It has thousands of cycles of slack in practice, so just add pipeline registers.

Fixes, cheapest first: let Quartus duplicate the high-fanout broadcast register; pipeline the write path; register `adc_out`. Last resort for path 1 is the spec's fallback: add a register between the add and the multiply, set `LANE_PIPE_DEPTH = 4`, and add a matching stage on the activation path.

## 4. How you know it's done

- Setup and hold slack are positive at the slow corner with `NUM_LANES = 64`.
- `fecim.sta.summary` and the worst-path listing are committed.
- If anything in the pipeline changed, the package, model, golden vectors and co-sim were all updated in the same PR series and L2 (task C5) is green again.
- The timed bitstream passes Ethan's hardware-versus-model check (C8).

## 5. Watch out for

- **A pipeline change is a four-lane change.** `LANE_PIPE_DEPTH` is read by the FSM, the model, the golden-vector generator and both co-sim harnesses. Tell Ethan and Megan within the hour, not in the PR description.
- **The LFSR reset.** The spec's code resets each lane's LFSR asynchronously to `seed_eff`, which isn't a constant. Quartus has to build asynchronous-load logic for that and may warn about it or produce recovery-time violations. If so, ask Megan to reset to the constant `(LANE_SALT | 1)`, which is the same value because `NOISE_SEED` is 0 at reset, and rely on the synchronous `reseed`.
- A design can meet timing at the fast corner and fail at the slow one. Report the slow corner.
- Don't lower the clock to make timing pass. The 7.84 µs latency claim assumes 50 MHz.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

