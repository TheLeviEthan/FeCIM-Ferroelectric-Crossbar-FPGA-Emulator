# AI prompt — A9: Bitstream release process and replication guide

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **A9 — Bitstream release process and replication guide**, owned by Zhiting Li, due Sat 28 Nov.

Write the release process and the replication guide for the FeCIM bitstream.

Deliver: (1) a "Release process" section for `quartus/README.md`, as a numbered checklist with exact commands; (2) `docs/replication-guide.md`, a complete walkthrough that takes a student who has never seen this repository from unboxed hardware to a running digit-classifier demo, including the 3.3 V safety check and a troubleshooting table; (3) release-notes text for the GitHub Release.

Take every command, pin name and expected output from the files you're given. Where you'd need a fact you don't have (for example the exact host command for the digits demo, or the Quartus menu path for making a `.pof`), leave a marked placeholder and list it at the end instead of guessing. Editable files: `quartus/README.md`, `docs/replication-guide.md` (new), and the `BUILD_ID` line in `rtl/fecim_pkg.sv`.

## Where the work goes

- **Release:** a GitHub Release on the repo holding `fecim.sof` and `fecim.pof` (bitstreams aren't committed to the repo; see `top-level-spec.md` §8.2).
- **Build ID:** `BUILD_ID` in `rtl/fecim_pkg.sv`, bumped once per release.
- **Process notes:** a "Release process" section in `quartus/README.md`.
- **Guide:** new `docs/replication-guide.md`, with a wiring photo and diagram in `docs/img/`.
- **Reports:** the fit and timing summaries for this exact build in `quartus/reports/`.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

**Release steps (write these into `quartus/README.md` as you do them):**

```text
1. main is green in CI; working tree clean
2. bump BUILD_ID in rtl/fecim_pkg.sv; merge that PR
3. clean build:  quartus_sh -t create_project.tcl && quartus_sh --flow compile fecim
4. confirm timing is met; copy fit/sta summaries to quartus/reports/ and commit
5. make the flash image:  convert fecim.sof -> fecim.pof (Quartus "Convert Programming Files",
   internal configuration) so the board boots the design at power-on with no laptop
6. program a board; IDENTIFY must report the new BUILD_ID
7. run Ethan's hardware-vs-model check (C8) on that board
8. tag the commit; create the GitHub Release; attach .sof, .pof, both summaries
```

**Replication guide outline:**

1. What you need: DE10-Lite, a CP2102 or CH340 USB-UART module that supports 3.3 V logic, three jumper wires, Quartus Programmer, Python 3.
2. The 3.3 V safety check from `hardware.md`, word for word, with the reason: the header is 3.3 V and 5 V can permanently damage the FPGA.
3. Wiring table and photo.
4. Programming the `.sof` (or flashing the `.pof`).
5. `pip install` the host package, then the first command (`IDENTIFY`) and its expected output.
6. Running the digits demo and what the board's display should show.
7. Troubleshooting: no reply, wrong COM port, version mismatch, garbage at the wrong baud rate.

## Acceptance checks

- A teammate follows the guide on their own laptop, without your help, and reaches a working digits demo. Fix every step where they got stuck.
- The GitHub Release exists for the cutoff commit, with both bitstreams and both report summaries.
- `IDENTIFY` on a board programmed from the release reports the `BUILD_ID` named in the release notes.
- With the `.pof` flashed, the board runs the design after a power cycle with no programmer attached.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **`BUILD_ID` lives in the package**, which is shared. Bumping it is a one-line PR, but the Python `sim` backend reports a build ID too; tell Natalie and Ethan what value to expect.
- Keep the release's bitstream and the committed reports from the *same* compile. A report from a different build is worse than no report.
- Photos of the wiring should show the dongle's voltage jumper position.
- If the flash image step gives trouble, ship the `.sof` and say so in the guide; the demo doesn't depend on power-on boot, it's a safety net.

## Files to read first (attach or paste these if you're using a chatbot)

- `quartus/README.md`, `quartus/fecim/create_project.tcl`
- `docs/plans and specs/02-lane-a-interface/hardware.md`, `top-level-spec.md` (§8)
- `README.md` (repo root) and `sw/README.md` or the user guide from D9
- `rtl/fecim_pkg.sv`
- The fit and timing summaries for the release build

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

