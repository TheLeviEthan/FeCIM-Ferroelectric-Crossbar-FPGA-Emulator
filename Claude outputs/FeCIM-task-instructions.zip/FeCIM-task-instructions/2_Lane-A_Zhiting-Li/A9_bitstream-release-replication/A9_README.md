# A9 — Bitstream release process and replication guide

| | |
|---|---|
| **Owner** | Zhiting Li |
| **Due** | Sat 28 Nov |
| **Board bucket** | Bucket 2 — Lane A |
| **Board task** | A9: Bitstream release process + replication guide |
| **Needs first** | A7 (timed build), A8 |
| **Unblocks** | X2 dry run (uses the release), X4 tag |
| **AI version** | `A9_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

An engineering result that only its author can reproduce isn't finished. The test for this project is simple: could another student with a DE10-Lite and a ten-dollar USB dongle get the digit classifier running from our repository, without messaging us?

Two things make that possible. A **release** is a frozen, named bitstream attached to a specific commit, with its resource and timing reports, so "which version is on the board" always has an answer. The `BUILD_ID` in the `IDENTIFY` reply ties a running board back to that release. A **replication guide** is the step-by-step path from an empty desk to a working demo.

The dry run on Mon 30 Nov uses this release on a laptop that isn't yours. That's the real acceptance test.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Release:** a GitHub Release on the repo holding `fecim.sof` and `fecim.pof` (bitstreams aren't committed to the repo; see `top-level-spec.md` §8.2).
- **Build ID:** `BUILD_ID` in `rtl/fecim_pkg.sv`, bumped once per release.
- **Process notes:** a "Release process" section in `quartus/README.md`.
- **Guide:** new `docs/replication-guide.md`, with a wiring photo and diagram in `docs/img/`.
- **Reports:** the fit and timing summaries for this exact build in `quartus/reports/`.

## 3. How to build it

**Release steps (write these into `quartus/README.md` as you do them):**

```text
1. main is green in CI; working tree clean
2. bump BUILD_ID in rtl/fecim_pkg.sv; merge that PR
3. clean build:  quartus_sh -t create_project.tcl && quartus_sh --flow compile fecim
4. confirm timing is met; copy fit/sta summaries to quartus/reports/ and commit
5. make the flash image:  convert fecim.sof -> fecim.pof (Quartus "Convert Programming Files",
   internal configuration) so the board boots the design at power-on with no laptop
6. program a board; IDENTIFY must report the new BUILD_ID
7. run Ethan's hardware-vs-model check (C8) on that board
8. tag the commit; create the GitHub Release; attach .sof, .pof, both summaries
```

**Replication guide outline:**

1. What you need: DE10-Lite, a CP2102 or CH340 USB-UART module that supports 3.3 V logic, three jumper wires, Quartus Programmer, Python 3.
2. The 3.3 V safety check from `hardware.md`, word for word, with the reason: the header is 3.3 V and 5 V can permanently damage the FPGA.
3. Wiring table and photo.
4. Programming the `.sof` (or flashing the `.pof`).
5. `pip install` the host package, then the first command (`IDENTIFY`) and its expected output.
6. Running the digits demo and what the board's display should show.
7. Troubleshooting: no reply, wrong COM port, version mismatch, garbage at the wrong baud rate.

## 4. How you know it's done

- A teammate follows the guide on their own laptop, without your help, and reaches a working digits demo. Fix every step where they got stuck.
- The GitHub Release exists for the cutoff commit, with both bitstreams and both report summaries.
- `IDENTIFY` on a board programmed from the release reports the `BUILD_ID` named in the release notes.
- With the `.pof` flashed, the board runs the design after a power cycle with no programmer attached.

## 5. Watch out for

- **`BUILD_ID` lives in the package**, which is shared. Bumping it is a one-line PR, but the Python `sim` backend reports a build ID too; tell Natalie and Ethan what value to expect.
- Keep the release's bitstream and the committed reports from the *same* compile. A report from a different build is worse than no report.
- Photos of the wiring should show the dongle's voltage jumper position.
- If the flash image step gives trouble, ship the `.sof` and say so in the guide; the demo doesn't depend on power-on boot, it's a safety net.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

