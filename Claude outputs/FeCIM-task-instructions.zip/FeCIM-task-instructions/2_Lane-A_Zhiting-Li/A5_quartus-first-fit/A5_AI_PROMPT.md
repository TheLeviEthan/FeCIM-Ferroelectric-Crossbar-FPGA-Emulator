# AI prompt — A5: Quartus project for fecim_top and first fit

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **A5 — Quartus project for fecim_top and first fit**, owned by Zhiting Li, due Sun 22 Nov.

Write and debug the scripted Quartus Prime Lite project for the full `fecim_top` design and help interpret its fitter report.

You probably can't run Quartus. If so, deliver the Tcl project script and the `.sdc`, explain each assignment, and give the owner a checklist of the exact report sections and numbers to look at, with what each wrong value would indicate. If the owner pastes a fitter summary or report excerpt, analyze it against the budget in `mac-array-spec.md` §11 and say plainly whether 9×9 multiplier pairing and M9K inference happened.

Editable files: everything under `quartus/fecim/`, `quartus/fecim.sdc`, `quartus/pins.tcl`, `quartus/README.md`. Don't change RTL to make the design fit; describe the change and which lane owns it.

## Where the work goes

- **Project script:** `quartus/fecim/create_project.tcl` (started in A2). It should add every file under `rtl/`, source the pin file, and add `quartus/fecim.sdc`.
- **Reports to commit:** `quartus/reports/fecim.fit.summary` and `quartus/reports/fecim.fit.rpt`, next to the existing `dsp_pack_test.*` reports. The `.sof` isn't committed (it goes in the release, A9).
- **Budget to compare against:** `03-lane-b-array/mac-array-spec.md` §11 and `00-plan/fecim-plan.md` §3.8.
- **Toolchain:** Quartus Prime Lite 25.1std.0 Build 1129, Linux build under WSL, exactly as `quartus/README.md` describes.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```bash
cd quartus/fecim
quartus_sh -t create_project.tcl
quartus_sh --flow compile fecim
cp output_files/fecim.fit.summary output_files/fecim.fit.rpt ../reports/
```

Read the report in this order:

1. **Fitter Summary.** Logic elements, memory bits, "Embedded Multiplier 9-bit elements".
2. **Multipliers.** Expect about 72 blocks:
   - 64 for the lanes (each lane has a MAC multiply and a noise-scaling multiply, and the pair shares one block)
   - about 6 for the write path
   - 1 for IR drop
3. **RAM Summary.** Expect 66 M9K: one weight memory per lane (64), the activation buffer and the result buffer. If the lane memories turned into logic elements, the `ramstyle` inference failed.
4. **Fitter Resource Utilization by Entity.** Per-module numbers, which Megan needs for B9.

| Resource | Predicted | Available |
|---|---|---|
| Logic elements | ~18,300 | 49,760 |
| M9K blocks | 66 | 182 |
| Multiplier blocks | 72 | 144 |

If it doesn't fit at 64 lanes, rebuild with `NUM_LANES = 32` in `fecim_pkg.sv` on a branch, record why, and tell Ethan the same day: `model/include/fecim/params.h` and the golden vectors must change with it.

## Acceptance checks

- `quartus_sh --flow compile fecim` succeeds from a clean clone using only the committed script.
- Multiplier blocks ≤ 144 and close to 72; the report shows 9×9 pairing happened.
- 66 M9K blocks, with every lane's weight memory inferred as M9K.
- `fecim.fit.summary` and `fecim.fit.rpt` are committed, and the three headline numbers are posted in Teams for Megan (B9) and the slides.
- The bitstream still answers `IDENTIFY` on the board.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **A fit before the datapath is real means nothing.** Quartus removes logic whose outputs go nowhere. With tied-off skeletons, the multipliers are optimized away and the report shows a tiny design. Run it early to shake out the script, but only trust the numbers once A1, B1, B2, B4 and B6 are in.
- **Re-run after B3 and B4 merge.** The hashes add four multiplier blocks and read noise adds one multiply per lane. Those are the two changes that move the multiplier count.
- If the count is near 136, check operand widths and signedness first (`top-level-spec.md` §8.3): both operands of every lane multiply must be 9-bit signed.
- Build from a path without spaces. Windows Quartus on a `\\wsl.localhost` path is unreliable; use Linux Quartus as the README says.

## Files to read first (attach or paste these if you're using a chatbot)

- `quartus/dsp_pack_test/create_project.tcl`, `quartus/dsp_pack_test/dsp_pack_test.sdc`, `quartus/reports/dsp_pack_test.fit.summary`
- `quartus/pins.tcl`, `quartus/README.md`
- `rtl/fecim_pkg.sv`, `rtl/fecim_top.sv`, `rtl/array/mac_lane.sv`
- `docs/plans and specs/02-lane-a-interface/top-level-spec.md` (§5, §8, §9)
- `docs/plans and specs/03-lane-b-array/mac-array-spec.md` (§6, §11)
- The fitter summary or report, once a build exists

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

