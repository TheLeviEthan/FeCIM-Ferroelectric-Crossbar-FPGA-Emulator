# A5 — Quartus project for fecim_top and first fit

| | |
|---|---|
| **Owner** | Zhiting Li |
| **Due** | Sun 22 Nov |
| **Board bucket** | Bucket 2 — Lane A |
| **Board task** | A5: Quartus project for `fecim_top` + first fit |
| **Needs first** | A1, A2 (project script), B1, B2, B4, B6 merged |
| **Unblocks** | A7, B9, C8, every hardware demo |
| **AI version** | `A5_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Simulation proves the logic is right. The fit proves it's *buildable*: that all 64 lanes, their memories and their multipliers physically fit in this specific chip.

That isn't a formality here. The MAX 10 has 144 multiplier blocks, and the whole design was reshaped around that limit earlier in the semester: 9-bit operands, a ±127 noise clamp, a smaller hash, a triangular variation distribution. Those choices were made so that two multiplies pack into one block. The fitter report is where we find out whether they actually did. The spec predicts 72 blocks. If the report shows around 136, pairing failed and the design is one feature away from not fitting.

The same report gives the resource table for the presentation, and it's the evidence behind the design-corrections slide.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Project script:** `quartus/fecim/create_project.tcl` (started in A2). It should add every file under `rtl/`, source the pin file, and add `quartus/fecim.sdc`.
- **Reports to commit:** `quartus/reports/fecim.fit.summary` and `quartus/reports/fecim.fit.rpt`, next to the existing `dsp_pack_test.*` reports. The `.sof` isn't committed (it goes in the release, A9).
- **Budget to compare against:** `03-lane-b-array/mac-array-spec.md` §11 and `00-plan/fecim-plan.md` §3.8.
- **Toolchain:** Quartus Prime Lite 25.1std.0 Build 1129, Linux build under WSL, exactly as `quartus/README.md` describes.

## 3. How to build it

```bash
cd quartus/fecim
quartus_sh -t create_project.tcl
quartus_sh --flow compile fecim
cp output_files/fecim.fit.summary output_files/fecim.fit.rpt ../reports/
```

Read the report in this order:

1. **Fitter Summary.** Logic elements, memory bits, "Embedded Multiplier 9-bit elements".
2. **Multipliers.** Expect about 72 blocks:
   - 64 for the lanes (each lane has a MAC multiply and a noise-scaling multiply, and the pair shares one block)
   - about 6 for the write path
   - 1 for IR drop
3. **RAM Summary.** Expect 66 M9K: one weight memory per lane (64), the activation buffer and the result buffer. If the lane memories turned into logic elements, the `ramstyle` inference failed.
4. **Fitter Resource Utilization by Entity.** Per-module numbers, which Megan needs for B9.

| Resource | Predicted | Available |
|---|---|---|
| Logic elements | ~18,300 | 49,760 |
| M9K blocks | 66 | 182 |
| Multiplier blocks | 72 | 144 |

If it doesn't fit at 64 lanes, rebuild with `NUM_LANES = 32` in `fecim_pkg.sv` on a branch, record why, and tell Ethan the same day: `model/include/fecim/params.h` and the golden vectors must change with it.

## 4. How you know it's done

- `quartus_sh --flow compile fecim` succeeds from a clean clone using only the committed script.
- Multiplier blocks ≤ 144 and close to 72; the report shows 9×9 pairing happened.
- 66 M9K blocks, with every lane's weight memory inferred as M9K.
- `fecim.fit.summary` and `fecim.fit.rpt` are committed, and the three headline numbers are posted in Teams for Megan (B9) and the slides.
- The bitstream still answers `IDENTIFY` on the board.

## 5. Watch out for

- **A fit before the datapath is real means nothing.** Quartus removes logic whose outputs go nowhere. With tied-off skeletons, the multipliers are optimized away and the report shows a tiny design. Run it early to shake out the script, but only trust the numbers once A1, B1, B2, B4 and B6 are in.
- **Re-run after B3 and B4 merge.** The hashes add four multiplier blocks and read noise adds one multiply per lane. Those are the two changes that move the multiplier count.
- If the count is near 136, check operand widths and signedness first (`top-level-spec.md` §8.3): both operands of every lane multiply must be 9-bit signed.
- Build from a path without spaces. Windows Quartus on a `\\wsl.localhost` path is unreliable; use Linux Quartus as the README says.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

