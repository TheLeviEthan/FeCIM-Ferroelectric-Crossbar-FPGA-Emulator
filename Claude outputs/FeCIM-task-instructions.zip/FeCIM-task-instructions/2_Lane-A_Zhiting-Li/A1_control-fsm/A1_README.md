# A1 — control_fsm and tb_control_fsm

| | |
|---|---|
| **Owner** | Zhiting Li |
| **Due** | Wed 18 Nov |
| **Board bucket** | Bucket 2 — Lane A |
| **Board task** | A1: `control_fsm` + `tb_control_fsm` |
| **Needs first** | K4 (port lists confirmed) |
| **Unblocks** | A5, B7, C3 cross-check, C5 |
| **AI version** | `A1_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

In a real crossbar the physics does the multiply all at once: every row voltage is applied together and each column wire sums its currents instantly. Our FPGA can't do that. It has 64 multiply-accumulate lanes and has to feed them one row per clock cycle, then do it again for the second half of the columns. `control_fsm` is the conductor that turns "it all happens at once" into an ordered sequence of clock cycles.

It owns one counter and five states: `IDLE → CLEAR → ACC → DRAIN → DONE`. In `CLEAR` it zeroes the accumulators. In `ACC` it steps through the rows, so every lane reads one weight and the activation buffer reads one activation per cycle. In `DRAIN` it shifts the 64 finished column sums out to the result buffer. Two passes cover all 128 columns.

Three things in the project depend directly on this module being exact:

- **Correct answers.** Leave `ACC` three cycles early and the last three rows silently vanish from every result. The numbers still look plausible, which is what makes this bug so hard to find.
- **The latency number we present.** 392 cycles (7.84 µs) for a full tile is this FSM's cycle count. `CYCLE_CNT` lets the host read back the measured value.
- **Reproducible noise.** The read-noise generators in the lanes advance once per `acc_en` cycle. One stray `acc_en` and the hardware no longer matches the C++ model, so we could no longer claim bit-exactness.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Implement:** `rtl/control/control_fsm.sv`. It's a skeleton today: the port list is in place and every output is tied to zero. Keep the ports as wired in `rtl/fecim_top.sv` (instance `u_control_fsm`) unless K4 changes them.
- **New testbench:** `tb/sv/tb_control_fsm.sv`, self-checking, prints a line containing `PASS` on success (see `tb/sv/tb_mac_lane.sv` for the house style).
- **Register the testbench:** add it to the `SRC` map and `ORDER` list in `tb/run_sims.sh`, and to the `sim` job in `.github/workflows/ci.yml` (the line that runs `tb/run_sims.sh tb_uart ...`).
- **Specs:** `docs/plans and specs/02-lane-a-interface/control-fsm-spec.md` §3 (address mapping), §4 (sequence), §10 (tests); `03-lane-b-array/result-buffer-spec.md` §3 (drain addressing); `03-lane-b-array/activation-buffer-spec.md` §4 (pipeline timing); `01-contract/rtl-conventions.md` §5 (FSM template).
- **Constants to use from `fecim_pkg`:** `NUM_LANES` (64), `LANE_AW` (6), `ROW_AW` (7), `COL_AW` (7), `SEQ_AW` (8), `LANE_PIPE_DEPTH` (3), `ctrl_state_e`.

## 3. How to build it

One counter, wire slices for everything else (control-fsm-spec §3.1). At 128 rows: `row = seq_cnt[6:0]`, `pass = seq_cnt[7]`.

```text
passes_needed = (active_cols + NUM_LANES - 1) >> LANE_AW     // 1 or 2; rounds up

IDLE:   outputs idle
        if (start_compute || manual_compute):
            pass = 0; cycle_cnt_run = 0; run_start = 1 (one cycle); -> CLEAR

CLEAR:  acc_clear = 1                       // one cycle, every pass
        row = 0; hold = 0;                  -> ACC

ACC:    if (row < active_rows):             // issue one row per cycle
            acc_en  = 1
            seq_cnt = {pass, row}           // weight address in every lane
            act_addr = row
            row++
        else:                               // pipeline drain: acc_en LOW
            hold++
            if (hold == LANE_PIPE_DEPTH):   drain = 0; -> DRAIN

DRAIN:  drain_we   = 1                      // one column per cycle, NUM_LANES cycles
        drain_addr = {pass, drain}          // concatenation, no arithmetic
        shift_en   = 1                      // see "Watch out for"
        if (drain == NUM_LANES-1):          // that was the last lane of this pass
            if (pass + 1 < passes_needed):  pass++; -> CLEAR
            else:                           -> DONE
        else: drain++

DONE:   compute_done = 1 (one cycle); cycle_cnt <= cycle_cnt_run; -> IDLE

every state except IDLE: cycle_cnt_run++
soft_reset in any state:  -> IDLE, outputs idle
state        = current state (ctrl_state_e)
compute_busy = (state != IDLE)
```

Why the hold is exactly `LANE_PIPE_DEPTH`: a row issued in cycle N reaches the accumulator at the end of cycle N+3 (memory read, alignment register, multiply, accumulate). `mac_lane.sv` delays `acc_en` internally through `v1, v2, v3`, so the FSM only has to wait three cycles with `acc_en` low before it drains.

Expected cycle count per pass is `1 + active_rows + LANE_PIPE_DEPTH + NUM_LANES`. For the full tile that's `2 × (1 + 128 + 3 + 64) = 392`.

Build the testbench first, so the timeline is checked from the first compile:

1. Drive `start_compute`, then count: `acc_clear` cycles, `acc_en` cycles, the gap, `drain_we` cycles.
2. Check that `seq_cnt` visits `0 .. passes × 128 − 1` in order while `acc_en` is high.
3. Check `drain_addr` goes `0..63` then `64..127`.
4. Repeat for `TILE_CFG` = 8×8, 32×32, 48×48, 64×64, 128×128.

## 4. How you know it's done

- `tb_control_fsm` passes for all five tile sizes, including `active_cols = 48` (one pass) and `active_cols = 100` (two passes).
- `acc_en` is high for exactly `active_rows` cycles per pass, and low for exactly `LANE_PIPE_DEPTH` cycles before `DRAIN`.
- `cycle_cnt` reads 392 after a full-tile compute, and equals Ethan's model prediction (task C3) for every tile size.
- `compute_done` and `run_start` are each one cycle wide. Two computes back to back give identical timelines.
- A `start_compute` or `manual_compute` pulse while busy changes nothing.
- The skeleton's `lint_off` waivers and the "SKELETON" header are deleted, and `verilator --lint-only -Wall --top-module fecim_top ...` is clean.
- The testbench is in `tb/run_sims.sh` and in CI.

## 5. Watch out for

- **`shift_en` timing.** `result-buffer-spec.md` §3 says "`shift_en` asserts from cycle 1 onward". But if the result buffer captures `chain_out` on the clock edge that ends drain cycle k, the chain must shift on that same edge for lane k+1 to be at the output in cycle k+1. That means `shift_en` high during drain cycles 0 to 62. Work it out with Megan (B6) and let the drain-ordering test decide: a distinct value per column must land at its own address. Then fix the spec sentence.
- **`ST_BUSY` isn't produced today.** `packet_parser.sv` computes `dispatch_status` for `CMD_COMPUTE` from the payload length only; it never looks at `compute_busy`. The case that matters is a host `COMPUTE` arriving while a `KEY1` compute is running. The parser is yours, so add the busy check there (control-fsm-spec §5, test 8).
- **What `CYCLE_CNT` counts** is an open question in the spec (§11.1). This sheet assumes every cycle from leaving `IDLE` up to entering `DONE`. Whatever you choose, Ethan's `cycle_count()` in the model has to count the same way.
- **Non-multiple-of-64 column counts** still drain a full 64 lanes per pass. Masking the unused columns is `argmax_unit`'s job (A4), not yours.
- `active_rows` and `active_cols` are 16 bits wide. Values above 128 can't happen through the driver, but decide what the FSM does with them (clamp, or trust the host) and tell Ethan so the model matches.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

