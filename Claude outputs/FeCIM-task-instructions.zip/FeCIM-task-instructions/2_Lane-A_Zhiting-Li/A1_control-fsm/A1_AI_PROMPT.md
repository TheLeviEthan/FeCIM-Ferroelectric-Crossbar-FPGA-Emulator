# AI prompt — A1: control_fsm and tb_control_fsm

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **A1 — control_fsm and tb_control_fsm**, owned by Zhiting Li, due Wed 18 Nov.

Implement the MVM sequencer `control_fsm` and a self-checking testbench for it. The module's ports already exist and are wired into `fecim_top`; replace the tied-off skeleton body with the real five-state machine, remove the skeleton's lint waivers, and register the new testbench in `tb/run_sims.sh` and the CI workflow.

The hard part is cycle accuracy, not complexity. Downstream, a C++ model steps in lockstep with this FSM and compares every cycle, and the per-lane noise generators advance once per `acc_en` cycle, so an off-by-one in `acc_en`, the pipeline hold or the drain count breaks bit-exactness across the project. Derive the timeline from `mac_lane.sv` and the specs, state it in a comment block at the top of the module, and make the testbench check it cycle by cycle.

Also add the missing busy check for `CMD_COMPUTE` in `rtl/packet/packet_parser.sv` (same lane, so it's editable). Editable files: `rtl/control/control_fsm.sv`, `rtl/packet/packet_parser.sv`, `tb/sv/tb_control_fsm.sv` (new), `tb/run_sims.sh`, `.github/workflows/ci.yml`. Don't change `mac_lane.sv`, `mac_array.sv` or `fecim_pkg.sv`.

## Where the work goes

- **Implement:** `rtl/control/control_fsm.sv`. It's a skeleton today: the port list is in place and every output is tied to zero. Keep the ports as wired in `rtl/fecim_top.sv` (instance `u_control_fsm`) unless K4 changes them.
- **New testbench:** `tb/sv/tb_control_fsm.sv`, self-checking, prints a line containing `PASS` on success (see `tb/sv/tb_mac_lane.sv` for the house style).
- **Register the testbench:** add it to the `SRC` map and `ORDER` list in `tb/run_sims.sh`, and to the `sim` job in `.github/workflows/ci.yml` (the line that runs `tb/run_sims.sh tb_uart ...`).
- **Specs:** `docs/plans and specs/02-lane-a-interface/control-fsm-spec.md` §3 (address mapping), §4 (sequence), §10 (tests); `03-lane-b-array/result-buffer-spec.md` §3 (drain addressing); `03-lane-b-array/activation-buffer-spec.md` §4 (pipeline timing); `01-contract/rtl-conventions.md` §5 (FSM template).
- **Constants to use from `fecim_pkg`:** `NUM_LANES` (64), `LANE_AW` (6), `ROW_AW` (7), `COL_AW` (7), `SEQ_AW` (8), `LANE_PIPE_DEPTH` (3), `ctrl_state_e`.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

One counter, wire slices for everything else (control-fsm-spec §3.1). At 128 rows: `row = seq_cnt[6:0]`, `pass = seq_cnt[7]`.

```text
passes_needed = (active_cols + NUM_LANES - 1) >> LANE_AW     // 1 or 2; rounds up

IDLE:   outputs idle
        if (start_compute || manual_compute):
            pass = 0; cycle_cnt_run = 0; run_start = 1 (one cycle); -> CLEAR

CLEAR:  acc_clear = 1                       // one cycle, every pass
        row = 0; hold = 0;                  -> ACC

ACC:    if (row < active_rows):             // issue one row per cycle
            acc_en  = 1
            seq_cnt = {pass, row}           // weight address in every lane
            act_addr = row
            row++
        else:                               // pipeline drain: acc_en LOW
            hold++
            if (hold == LANE_PIPE_DEPTH):   drain = 0; -> DRAIN

DRAIN:  drain_we   = 1                      // one column per cycle, NUM_LANES cycles
        drain_addr = {pass, drain}          // concatenation, no arithmetic
        shift_en   = 1                      // see "Watch out for"
        if (drain == NUM_LANES-1):          // that was the last lane of this pass
            if (pass + 1 < passes_needed):  pass++; -> CLEAR
            else:                           -> DONE
        else: drain++

DONE:   compute_done = 1 (one cycle); cycle_cnt <= cycle_cnt_run; -> IDLE

every state except IDLE: cycle_cnt_run++
soft_reset in any state:  -> IDLE, outputs idle
state        = current state (ctrl_state_e)
compute_busy = (state != IDLE)
```

Why the hold is exactly `LANE_PIPE_DEPTH`: a row issued in cycle N reaches the accumulator at the end of cycle N+3 (memory read, alignment register, multiply, accumulate). `mac_lane.sv` delays `acc_en` internally through `v1, v2, v3`, so the FSM only has to wait three cycles with `acc_en` low before it drains.

Expected cycle count per pass is `1 + active_rows + LANE_PIPE_DEPTH + NUM_LANES`. For the full tile that's `2 × (1 + 128 + 3 + 64) = 392`.

Build the testbench first, so the timeline is checked from the first compile:

1. Drive `start_compute`, then count: `acc_clear` cycles, `acc_en` cycles, the gap, `drain_we` cycles.
2. Check that `seq_cnt` visits `0 .. passes × 128 − 1` in order while `acc_en` is high.
3. Check `drain_addr` goes `0..63` then `64..127`.
4. Repeat for `TILE_CFG` = 8×8, 32×32, 48×48, 64×64, 128×128.

## Acceptance checks

- `tb_control_fsm` passes for all five tile sizes, including `active_cols = 48` (one pass) and `active_cols = 100` (two passes).
- `acc_en` is high for exactly `active_rows` cycles per pass, and low for exactly `LANE_PIPE_DEPTH` cycles before `DRAIN`.
- `cycle_cnt` reads 392 after a full-tile compute, and equals Ethan's model prediction (task C3) for every tile size.
- `compute_done` and `run_start` are each one cycle wide. Two computes back to back give identical timelines.
- A `start_compute` or `manual_compute` pulse while busy changes nothing.
- The skeleton's `lint_off` waivers and the "SKELETON" header are deleted, and `verilator --lint-only -Wall --top-module fecim_top ...` is clean.
- The testbench is in `tb/run_sims.sh` and in CI.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **`shift_en` timing.** `result-buffer-spec.md` §3 says "`shift_en` asserts from cycle 1 onward". But if the result buffer captures `chain_out` on the clock edge that ends drain cycle k, the chain must shift on that same edge for lane k+1 to be at the output in cycle k+1. That means `shift_en` high during drain cycles 0 to 62. Work it out with Megan (B6) and let the drain-ordering test decide: a distinct value per column must land at its own address. Then fix the spec sentence.
- **`ST_BUSY` isn't produced today.** `packet_parser.sv` computes `dispatch_status` for `CMD_COMPUTE` from the payload length only; it never looks at `compute_busy`. The case that matters is a host `COMPUTE` arriving while a `KEY1` compute is running. The parser is yours, so add the busy check there (control-fsm-spec §5, test 8).
- **What `CYCLE_CNT` counts** is an open question in the spec (§11.1). This sheet assumes every cycle from leaving `IDLE` up to entering `DONE`. Whatever you choose, Ethan's `cycle_count()` in the model has to count the same way.
- **Non-multiple-of-64 column counts** still drain a full 64 lanes per pass. Masking the unused columns is `argmax_unit`'s job (A4), not yours.
- `active_rows` and `active_cols` are 16 bits wide. Values above 128 can't happen through the driver, but decide what the FSM does with them (clamp, or trust the host) and tell Ethan so the model matches.

## Files to read first (attach or paste these if you're using a chatbot)

- `rtl/fecim_pkg.sv`
- `rtl/control/control_fsm.sv` (the skeleton)
- `rtl/fecim_top.sv`
- `rtl/array/mac_lane.sv` and `rtl/array/mac_array.sv` (to derive the timing)
- `rtl/packet/packet_parser.sv`
- `tb/sv/tb_mac_lane.sv` (testbench style) and `tb/run_sims.sh`
- `docs/plans and specs/02-lane-a-interface/control-fsm-spec.md`
- `docs/plans and specs/03-lane-b-array/result-buffer-spec.md` (§3)
- `docs/plans and specs/03-lane-b-array/activation-buffer-spec.md` (§4)
- `docs/plans and specs/01-contract/rtl-conventions.md`

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

