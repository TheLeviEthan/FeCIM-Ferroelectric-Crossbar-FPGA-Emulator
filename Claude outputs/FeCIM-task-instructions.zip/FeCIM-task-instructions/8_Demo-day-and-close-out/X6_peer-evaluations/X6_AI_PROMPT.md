# AI prompt — X6: Peer evaluations, if assigned

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **X6 — Peer evaluations, if assigned**, owned by Ethan Ruddell (each member submits their own), due Wed 2 Dec.

Help one team member write fair, specific peer evaluations. From the facts they provide about each teammate (tasks owned, pull requests merged, reviews given, observations about reliability and collaboration), draft two or three sentences per criterion for each teammate, in a professional and constructive tone, with one concrete suggestion each. Use only the facts given, don't infer ratings or character from commit counts, and leave any numeric scores for the person to decide.

## Where the work goes

- **Submit:** wherever the course specifies (found in K6), individually.
- **Evidence to draw on:** merged pull requests and reviews on GitHub, the Planner board, the daily check-in thread, the meeting logs.

## Steps the owner is following

1. From K6, confirm whether peer evaluations are required, the form, the deadline, and whether they're confidential.
2. Post a reminder in the channel with the deadline and the link. That's the whole of the coordination.
3. Individually, before writing, pull the facts for each teammate:

   ```bash
   git shortlog -sn --since=2026-09-01 main          # commits per author
   git log --author="<name>" --since=2026-11-16 --date=short --format='%ad %s' main
   ```

   Also look at their merged PRs, the reviews they gave others, and their Planner tasks.
4. For each teammate, write two or three sentences on each of: what they built; how reliably they delivered what they said they would; how they helped others (reviews, unblocking, swarming); one concrete thing that would make them more effective.
5. Base ratings on the whole semester, not the last week.
6. Submit your own. Don't share or compare drafts unless the course says to.

## What done looks like

- Every member knows whether evaluations are required, where to submit and by when.
- Each member has submitted their own before the deadline.
- If none are assigned, the Planner task is closed with a note saying so.

## Things to keep in mind

- **Commit counts mislead.** One careful commit can outweigh thirty small ones, and work like reviews, calibration research, test design and board bring-up doesn't show up as lines of code. Use the numbers as a prompt for memory, not as a score.
- Work drafted with AI tools still counts for the person who specified it, checked it and can explain it. Evaluate that judgment.
- Keep it professional and specific. Write nothing you wouldn't say to the person directly.
- An AI tool can help you phrase an evaluation. The judgment has to be yours, from what you observed.

## What to give the model along with this prompt

- The evaluation form or criteria from the course
- For each teammate: their tasks, merged PRs, reviews given, and the evaluator's own observations

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

