# X6 — Peer evaluations, if assigned

| | |
|---|---|
| **Owner** | Ethan Ruddell (each member submits their own) |
| **Due** | Wed 2 Dec |
| **Board bucket** | Bucket 8 — Demo Day and Close-out |
| **Board task** | Peer evaluations (if assigned) |
| **Needs first** | K6 (whether they're required, and the deadline) |
| **Unblocks** | the semester-1 hand-in |
| **AI version** | `X6_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Many capstone courses ask each member to assess the contributions of the others. It's part of the grade, and it's also the fairest record of who did what, because a team's own members see things the instructor can't.

A useful evaluation is specific and based on evidence. "Megan did a lot" helps nobody. "Megan implemented the write path, activation buffer and read-noise integration, and her testbenches caught two timing mismatches at the lane boundary" is fair to her and useful to the instructor. Our repository makes this easy to do well: every pull request, review and task is recorded with a name on it.

It's an individual, confidential task. The owner here only makes sure everyone knows the deadline and has the facts to hand.

## 2. Where the work goes

- **Submit:** wherever the course specifies (found in K6), individually.
- **Evidence to draw on:** merged pull requests and reviews on GitHub, the Planner board, the daily check-in thread, the meeting logs.

## 3. How to do it

1. From K6, confirm whether peer evaluations are required, the form, the deadline, and whether they're confidential.
2. Post a reminder in the channel with the deadline and the link. That's the whole of the coordination.
3. Individually, before writing, pull the facts for each teammate:

   ```bash
   git shortlog -sn --since=2026-09-01 main          # commits per author
   git log --author="<name>" --since=2026-11-16 --date=short --format='%ad %s' main
   ```

   Also look at their merged PRs, the reviews they gave others, and their Planner tasks.
4. For each teammate, write two or three sentences on each of: what they built; how reliably they delivered what they said they would; how they helped others (reviews, unblocking, swarming); one concrete thing that would make them more effective.
5. Base ratings on the whole semester, not the last week.
6. Submit your own. Don't share or compare drafts unless the course says to.

## 4. How you know it's done

- Every member knows whether evaluations are required, where to submit and by when.
- Each member has submitted their own before the deadline.
- If none are assigned, the Planner task is closed with a note saying so.

## 5. Watch out for

- **Commit counts mislead.** One careful commit can outweigh thirty small ones, and work like reviews, calibration research, test design and board bring-up doesn't show up as lines of code. Use the numbers as a prompt for memory, not as a score.
- Work drafted with AI tools still counts for the person who specified it, checked it and can explain it. Evaluate that judgment.
- Keep it professional and specific. Write nothing you wouldn't say to the person directly.
- An AI tool can help you phrase an evaluation. The judgment has to be yours, from what you observed.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

