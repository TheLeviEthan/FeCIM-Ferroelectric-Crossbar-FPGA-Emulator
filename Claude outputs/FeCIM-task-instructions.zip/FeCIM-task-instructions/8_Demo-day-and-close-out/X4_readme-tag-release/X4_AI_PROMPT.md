# AI prompt — X4: README current state, tag v1.0.0 and the GitHub release

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **X4 — README current state, tag v1.0.0 and the GitHub release**, owned by Ethan Ruddell, due Wed 2 Dec.

Update the repository's `README.md` to describe the project's actual state at the semester-1 tag, and write the release notes for `v1.0.0`.

Rewrite the status banner, the "Current state" table, the milestones list and the quick-start instructions from the evidence provided (module list, CI results, report summaries, verification results). Mark an item as done only where the material given shows it; list anything you couldn't confirm. Keep the existing structure and tone of the README, keep a "Known limitations" section consistent with the project's stated modelling assumptions, and link the user guide, replication guide and reports. Editable files: `README.md`; the release notes are delivered as text.

## Where the work goes

- **Edit:** `README.md` at the repository root: the status banner under the title, the "Current state" table, "Next milestones", and the build and run instructions.
- **Tag:** `v1.0.0` on the commit the dry run used (recorded in X2).
- **Release:** GitHub Releases, attaching `fecim.sof`, `fecim.pof`, the wheel and source distribution, `fecim.fit.summary` and `fecim.sta.summary`.
- **Link from the README:** `docs/replication-guide.md`, `docs/user-guide.md`, `docs/reports/verification-report.md`, `docs/reports/utilization.md`, the calibration section of `device-model.md`.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

**1. Rewrite the status table from what's on `main`,** not from memory. For each row, check the code and the evidence:

| Area | What to check before writing "Done" |
|---|---|
| Each RTL module | the skeleton header and lint waivers are gone; its testbench is in CI |
| Six non-idealities | an L1 row for each (C5) and a hardware row (C8) |
| Verification levels | L0, L1, L2, L4 results and the L3 summary, each linked |
| Board build | fit and timing summaries committed; multiplier count stated |
| Host package | installs from the wheel; both backends; both classifiers |
| Calibration | set A documented; what's swept is stated |
| Results | plots regenerate from committed data |

Replace "Next milestones" with the semester-2 list: multi-tile support, differential-pair modelling, retention drift, comparison across three published device technologies, a second application.

Keep a short "Known limitations" section that matches the design-corrections slide.

**2. Tag and release:**

```bash
git switch main && git pull
git log -1 --format=%H                      # must equal the dry-run commit, or tag that commit explicitly
git tag -a v1.0.0 <dry-run-hash> -m "FeCIM semester 1: 128x128 tile, 64 lanes, six non-idealities, calibrated set A, digits demo"
git push origin v1.0.0
```

Create the release on GitHub from the tag, with notes covering: what's included, the `BUILD_ID`, the Quartus version, how to reproduce (link to the replication guide), and known limitations.

**3. Check it as a stranger would:** open the repository's front page in a private browser window. Can you tell what the project is, what works, and how to run it, in two minutes?

## Acceptance checks

- The README's status table matches `main` at the tag, with a link to evidence in every "Done" row.
- No "pre-alpha" or "skeleton" wording remains for anything that's finished, and nothing unfinished is described as done.
- `v1.0.0` points at the commit the dry run used.
- The GitHub Release has the bitstream, the wheel, both report summaries and notes.
- The CI badge on the README is green for that commit.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- The README change itself lands after the tagged commit, which is fine. Say in the README which tag it describes.
- Teammates' names appear in the README's team table and the repository is public. Confirm everyone is still comfortable with that.
- The bitstream is attached to the release, not committed to the repository.
- If something was cut, the README says so in the same plain words as the slide.

## Files to read first (attach or paste these if you're using a chatbot)

- The current `README.md`
- A listing of `rtl/`, `tb/`, `model/`, `sw/`, `docs/` at the tagged commit, and the CI run summary
- `docs/reports/verification-report.md`, `docs/reports/utilization.md`, `quartus/reports/fecim.fit.summary`, `quartus/reports/fecim.sta.summary`
- The Saturday checkpoint post (G6) and the list of anything cut
- The frozen commit hash and `BUILD_ID`

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

