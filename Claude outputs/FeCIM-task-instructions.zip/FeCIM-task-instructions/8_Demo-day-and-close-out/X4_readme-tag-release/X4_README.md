# X4 — README current state, tag v1.0.0 and the GitHub release

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Wed 2 Dec |
| **Board bucket** | Bucket 8 — Demo Day and Close-out |
| **Board task** | README current state + tag `v1.0.0` + GitHub release |
| **Needs first** | X1, X2, A9, D9 |
| **Unblocks** | the semester-1 hand-in; a clean starting point for semester 2 |
| **AI version** | `X4_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

The repository is the thing that gets graded and the thing we come back to in January. Right now its front page describes a project in "pre-alpha", with most modules listed as skeletons. Anyone who opens it would think far less had been built than actually was.

Three small actions fix the record. The **README** is rewritten to say what exists now and how to run it. A **tag** is a permanent, named pointer to one exact commit: `v1.0.0` will always mean "what we presented", however much the code changes afterwards. And the **GitHub Release** attaches the built artifacts to that tag (the bitstream, the Python wheel, the reports), so someone can reproduce the demo without building anything.

When a reviewer asks "what did the team deliver in semester 1?", the answer is one link.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Edit:** `README.md` at the repository root: the status banner under the title, the "Current state" table, "Next milestones", and the build and run instructions.
- **Tag:** `v1.0.0` on the commit the dry run used (recorded in X2).
- **Release:** GitHub Releases, attaching `fecim.sof`, `fecim.pof`, the wheel and source distribution, `fecim.fit.summary` and `fecim.sta.summary`.
- **Link from the README:** `docs/replication-guide.md`, `docs/user-guide.md`, `docs/reports/verification-report.md`, `docs/reports/utilization.md`, the calibration section of `device-model.md`.

## 3. How to build it

**1. Rewrite the status table from what's on `main`,** not from memory. For each row, check the code and the evidence:

| Area | What to check before writing "Done" |
|---|---|
| Each RTL module | the skeleton header and lint waivers are gone; its testbench is in CI |
| Six non-idealities | an L1 row for each (C5) and a hardware row (C8) |
| Verification levels | L0, L1, L2, L4 results and the L3 summary, each linked |
| Board build | fit and timing summaries committed; multiplier count stated |
| Host package | installs from the wheel; both backends; both classifiers |
| Calibration | set A documented; what's swept is stated |
| Results | plots regenerate from committed data |

Replace "Next milestones" with the semester-2 list: multi-tile support, differential-pair modelling, retention drift, comparison across three published device technologies, a second application.

Keep a short "Known limitations" section that matches the design-corrections slide.

**2. Tag and release:**

```bash
git switch main && git pull
git log -1 --format=%H                      # must equal the dry-run commit, or tag that commit explicitly
git tag -a v1.0.0 <dry-run-hash> -m "FeCIM semester 1: 128x128 tile, 64 lanes, six non-idealities, calibrated set A, digits demo"
git push origin v1.0.0
```

Create the release on GitHub from the tag, with notes covering: what's included, the `BUILD_ID`, the Quartus version, how to reproduce (link to the replication guide), and known limitations.

**3. Check it as a stranger would:** open the repository's front page in a private browser window. Can you tell what the project is, what works, and how to run it, in two minutes?

## 4. How you know it's done

- The README's status table matches `main` at the tag, with a link to evidence in every "Done" row.
- No "pre-alpha" or "skeleton" wording remains for anything that's finished, and nothing unfinished is described as done.
- `v1.0.0` points at the commit the dry run used.
- The GitHub Release has the bitstream, the wheel, both report summaries and notes.
- The CI badge on the README is green for that commit.

## 5. Watch out for

- The README change itself lands after the tagged commit, which is fine. Say in the README which tag it describes.
- Teammates' names appear in the README's team table and the repository is public. Confirm everyone is still comfortable with that.
- The bitstream is attached to the release, not committed to the repository.
- If something was cut, the README says so in the same plain words as the slide.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

