# X1 — Merge cutoff: main frozen

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Sun 29 Nov, 18:00 |
| **Board bucket** | Bucket 8 — Demo Day and Close-out |
| **Board task** | Merge cutoff — `main` frozen |
| **Needs first** | G6, P5 |
| **Unblocks** | X2 (dry run from the frozen commit), A9 release, X4 tag |
| **AI version** | `X1_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

A demo is only as reliable as the version of the code it runs from. If people keep merging "one last fix" up to the hour of the presentation, nobody knows which combination of changes is on the boards, and the thing we rehearsed isn't the thing we present.

A cutoff fixes that. At 18:00 on Sunday, `main` stops changing. One commit becomes *the* version: the bitstream is built from it, the Python wheel is built from it, the plots were generated from it, and the dry run tests it. Every number on every slide can then be traced to that one commit.

It also forces an honest decision. Anything that isn't merged and green by the cutoff isn't in the presentation. That's better decided calmly on Sunday evening than discovered on Tuesday morning.

## 2. Where the work goes

- **Repository:** `main` on GitHub, with branch protection (set up in C7).
- **Announce:** the team channel.
- **Record:** the cutoff commit hash in the Planner task, the run sheet and the meeting log.

## 3. How to do it

1. **Sunday morning:** finish or cut what the Saturday checkpoint left open. No new work.
2. **16:00, two-hour warning** in the channel: list the open pull requests and who's reviewing each.
3. **Before 18:00,** each PR is either merged with green CI, or closed with a note saying it's deferred.
4. **At 18:00:**
   - Confirm CI is green on the tip of `main`.
   - Record the commit hash.
   - Post the freeze notice:

     ```text
     main is frozen at <hash> for the presentation. CI green.
     In: <one line>.   Deferred: <PRs or task IDs, one line each>.
     From now until Tuesday: typo fixes to slides only. Nothing merges to main.
     Bitstream and wheel for the dry run are built from this commit.
     ```

5. Zhiting builds the release bitstream from this commit (A9); Natalie builds the wheel (D9).
6. For each deferred item, make sure its one-line disclosure is on the design-corrections slide.

If something critical breaks after the freeze, the fix needs agreement from all four, gets its own PR and a full CI run, and the bitstream and wheel are rebuilt. That should be rare enough that it's a discussion, not a habit.

## 4. How you know it's done

- CI is green on the frozen commit, and its hash is recorded in the channel, the Planner task and the run sheet.
- No open pull request is left ambiguous: each is merged or explicitly deferred.
- The release bitstream and wheel are built from that commit.
- Every deferred item has its disclosure on a slide.

## 5. Watch out for

- A freeze that people quietly ignore is worse than none, because then the recorded hash is wrong. If an exception is made, re-record the hash.
- Slides aren't code. Wording and layout can still be polished; numbers can't change unless they're regenerated from the frozen commit.
- The semester-1 tag (`v1.0.0`) goes on this commit, or on the commit the dry run actually used, in X4.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

