# AI prompt — X1: Merge cutoff: main frozen

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **X1 — Merge cutoff: main frozen**, owned by Ethan Ruddell, due Sun 29 Nov, 18:00.

Draft the two channel posts for the cutoff: the two-hour warning listing open pull requests and reviewers, and the freeze notice with the commit hash, what's in, what's deferred and the rules until the presentation. Then, from the list of deferred items, write a one-sentence factual disclosure for each, suitable for a slide. Use only the PR list and hash provided.

## Where the work goes

- **Repository:** `main` on GitHub, with branch protection (set up in C7).
- **Announce:** the team channel.
- **Record:** the cutoff commit hash in the Planner task, the run sheet and the meeting log.

## Steps the owner is following

1. **Sunday morning:** finish or cut what the Saturday checkpoint left open. No new work.
2. **16:00, two-hour warning** in the channel: list the open pull requests and who's reviewing each.
3. **Before 18:00,** each PR is either merged with green CI, or closed with a note saying it's deferred.
4. **At 18:00:**
   - Confirm CI is green on the tip of `main`.
   - Record the commit hash.
   - Post the freeze notice:

     ```text
     main is frozen at <hash> for the presentation. CI green.
     In: <one line>.   Deferred: <PRs or task IDs, one line each>.
     From now until Tuesday: typo fixes to slides only. Nothing merges to main.
     Bitstream and wheel for the dry run are built from this commit.
     ```

5. Zhiting builds the release bitstream from this commit (A9); Natalie builds the wheel (D9).
6. For each deferred item, make sure its one-line disclosure is on the design-corrections slide.

If something critical breaks after the freeze, the fix needs agreement from all four, gets its own PR and a full CI run, and the bitstream and wheel are rebuilt. That should be rare enough that it's a discussion, not a habit.

## What done looks like

- CI is green on the frozen commit, and its hash is recorded in the channel, the Planner task and the run sheet.
- No open pull request is left ambiguous: each is merged or explicitly deferred.
- The release bitstream and wheel are built from that commit.
- Every deferred item has its disclosure on a slide.

## Things to keep in mind

- A freeze that people quietly ignore is worse than none, because then the recorded hash is wrong. If an exception is made, re-record the hash.
- Slides aren't code. Wording and layout can still be polished; numbers can't change unless they're regenerated from the frozen commit.
- The semester-1 tag (`v1.0.0`) goes on this commit, or on the commit the dry run actually used, in X4.

## What to give the model along with this prompt

- The list of open pull requests with their status and reviewers
- The frozen commit hash and a link to its CI run
- The Saturday checkpoint post (G6)

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

