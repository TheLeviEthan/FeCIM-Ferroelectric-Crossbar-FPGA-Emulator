# AI prompt — X3: Presentation

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **X3 — Presentation**, owned by Ethan Ruddell (all four present), due Tue 1 Dec.

Help with final preparation and the follow-up. Before the talk: turn the run sheet and deck outline into a one-page day-of checklist (what to bring, room setup in order, the fallback line for each demo) and a set of concise answers to likely questions. After the talk: from the notes provided, write the presentation log (questions asked, answers given, feedback, issues) and a list of follow-up actions with owners. Add nothing that isn't in the notes.

## Where the work goes

- **Bring:** both boards (flashed with the release image), both dongles, spare USB cable and jumper wires, every laptop charged, the run sheet printed, the deck and all recordings saved locally on two laptops.
- **Follow:** `docs/coursework/demo-run-sheet.md`.
- **Afterwards:** notes for the log in `docs/meetings/2026-12-01.md`.

## Steps the owner is following

**Before leaving home**

- Deck, recordings and demo video copied to local disk on two laptops. Don't rely on the network.
- Fresh terminal open in the dry-run clone, virtual environment activated, font enlarged.
- Notifications off; chat and email closed.

**In the room, 20 minutes early**

1. Power the boards. The heartbeat dot should blink.
2. Check the dongle jumpers (3.3 V), connect, note the COM port names.
3. Run `IDENTIFY` on each board. Confirm the `BUILD_ID`.
4. Set `SW[1:0] = 10` so the display shows the predicted class.
5. Run the first demo once, quietly, end to end.
6. Test the projector with the first slide and a terminal.

**During**

- Each speaker states their main point in the first sentence of their section.
- If a live demo doesn't respond within about ten seconds, say "here's the recording of this from yesterday" and play it. Carry on. Don't debug.
- One person keeps time and gives a signal at the two-thirds mark.
- For questions: answer the question asked, briefly. If you don't know, say so, and say what you'd check.

**Afterwards, the same day**

- Write down every question asked and any feedback, word for word if possible.
- Note what went wrong and what you'd change.
- Photograph the setup for the record.

## What done looks like

- The presentation was given inside the time limit, with every section covered.
- Each demo ran live or from its recording without stalling the talk.
- Questions and feedback are written down and committed in the log.
- Any follow-up the instructor asked for has an owner and a date.

## Things to keep in mind

- If a board dies, the other board plus recordings carries the talk. If both fail, the co-simulation demo and the recordings still show the full result.
- Don't change anything on the boards or in the clone between the dry run and the talk.
- Present the corrections slide with confidence. It's evidence of care.
- Thank the audience and stop when the time is up. A talk that ends on time lands better than one that ends completely.

## What to give the model along with this prompt

- `docs/coursework/demo-run-sheet.md` and the deck outline with speakers
- The dry-run log (X2)
- The anticipated-questions list from P5
- Notes taken during and after the presentation, for the log

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

