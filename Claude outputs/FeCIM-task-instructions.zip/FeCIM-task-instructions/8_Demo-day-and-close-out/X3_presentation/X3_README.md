# X3 — Presentation

| | |
|---|---|
| **Owner** | Ethan Ruddell (all four present) |
| **Due** | Tue 1 Dec |
| **Board bucket** | Bucket 8 — Demo Day and Close-out |
| **Board task** | Presentation |
| **Needs first** | X2 |
| **Unblocks** | X4–X6 |
| **AI version** | `X3_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

This is where the semester's work is judged. The audience sees about fifteen minutes. In that time they need to understand what problem this addresses, what we built, why they should believe it works, and what we found.

By this point the content is settled. What's left is delivery: starting on time with everything plugged in, saying each point clearly once, handing over cleanly between speakers, and staying calm when something doesn't go to plan. The preparation in the last three tasks exists so that today holds no surprises.

One thing to hold onto while presenting: the strongest part of this project is its rigor. Plenty of teams can show an FPGA doing something. Very few can show a design that matches a reference model bit for bit, on hardware, with a check that visibly catches an injected bug. Lead with what we can prove.

## 2. Where the work goes

- **Bring:** both boards (flashed with the release image), both dongles, spare USB cable and jumper wires, every laptop charged, the run sheet printed, the deck and all recordings saved locally on two laptops.
- **Follow:** `docs/coursework/demo-run-sheet.md`.
- **Afterwards:** notes for the log in `docs/meetings/2026-12-01.md`.

## 3. How to do it

**Before leaving home**

- Deck, recordings and demo video copied to local disk on two laptops. Don't rely on the network.
- Fresh terminal open in the dry-run clone, virtual environment activated, font enlarged.
- Notifications off; chat and email closed.

**In the room, 20 minutes early**

1. Power the boards. The heartbeat dot should blink.
2. Check the dongle jumpers (3.3 V), connect, note the COM port names.
3. Run `IDENTIFY` on each board. Confirm the `BUILD_ID`.
4. Set `SW[1:0] = 10` so the display shows the predicted class.
5. Run the first demo once, quietly, end to end.
6. Test the projector with the first slide and a terminal.

**During**

- Each speaker states their main point in the first sentence of their section.
- If a live demo doesn't respond within about ten seconds, say "here's the recording of this from yesterday" and play it. Carry on. Don't debug.
- One person keeps time and gives a signal at the two-thirds mark.
- For questions: answer the question asked, briefly. If you don't know, say so, and say what you'd check.

**Afterwards, the same day**

- Write down every question asked and any feedback, word for word if possible.
- Note what went wrong and what you'd change.
- Photograph the setup for the record.

## 4. How you know it's done

- The presentation was given inside the time limit, with every section covered.
- Each demo ran live or from its recording without stalling the talk.
- Questions and feedback are written down and committed in the log.
- Any follow-up the instructor asked for has an owner and a date.

## 5. Watch out for

- If a board dies, the other board plus recordings carries the talk. If both fail, the co-simulation demo and the recordings still show the full result.
- Don't change anything on the boards or in the clone between the dry run and the talk.
- Present the corrections slide with confidence. It's evidence of care.
- Thank the audience and stop when the time is up. A talk that ends on time lands better than one that ends completely.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

