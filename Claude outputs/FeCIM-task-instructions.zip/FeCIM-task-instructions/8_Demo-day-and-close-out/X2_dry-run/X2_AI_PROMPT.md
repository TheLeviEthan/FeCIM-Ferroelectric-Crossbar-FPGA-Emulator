# AI prompt — X2: Dry run from a clean clone, both boards (second timed rehearsal)

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **X2 — Dry run from a clean clone, both boards (second timed rehearsal)**, owned by Ethan Ruddell, due Mon 30 Nov.

Produce a dry-run checklist document from the run sheet provided: setup steps for a clean clone, one checklist block per demo (command, expected output, pass/fail, time taken, fallback practised), and an end-of-session section for the live-or-recording decision per demo and what to bring on the day. Then, if given the filled-in results, write the dry-run log and a list of corrections to make to the run sheet. Don't add commands that aren't in the run sheet.

## Where the work goes

- **Place:** in person, ideally in the presentation room; both boards, both dongles, all laptops.
- **Follow:** `docs/coursework/demo-run-sheet.md` (P4).
- **Install from:** the GitHub Release (bitstream from A9, wheel from D9) and a fresh `git clone` at the frozen commit.
- **Log:** `docs/meetings/2026-11-30.md`.

## Steps the owner is following

**Setup, on a laptop that isn't the author's for each demo:**

```bash
git clone <repo-url> fecim-dryrun && cd fecim-dryrun
git checkout <frozen-hash>
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install './sw[demo]'                               # or the wheel from the release
```

Program both boards from the release's bitstream. Confirm `IDENTIFY` shows the release's `BUILD_ID` on each.

**Run every row of the run sheet,** in presentation order. For each:

| Check | |
|---|---|
| Did it run from the clean clone with the written command, unchanged? | |
| Did the output match "expected output"? | |
| How long did it take, including switching laptops or boards? | |
| If it failed: what was missing? Fix the run sheet or fall back to the recording. | |

**Then the full talk, timed,** with live demos. Practise each fallback once on purpose: mid-demo, switch to the recording as you would if it failed.

**Decide per demo:** live on Tuesday, or recording. A demo that needed a fix today goes to recording unless it then passes twice in a row.

**Before leaving:** record the commit hash and `BUILD_ID` used, charge the laptops, label the boards and cables, and agree who carries what on Tuesday.

## What done looks like

- Every demo was run from a clean clone at the frozen commit by someone other than its author, and the result is recorded.
- Both boards run the release bitstream, confirmed by `BUILD_ID`.
- The full talk with demos fits the time limit.
- Each demo is marked live or recording for Tuesday, and every fallback has been practised once.
- The run sheet is corrected wherever reality differed from it.
- The commit hash and `BUILD_ID` are recorded for the tag (X4), and the log is committed.

## Things to keep in mind

- **Don't fix things on the author's laptop and call it done.** If the clean clone fails, the repository or the run sheet is wrong, and that's what gets fixed (under the post-freeze rule in X1 if it's code).
- Check the dongle jumpers again after transport. The 3.3 V check takes one minute.
- Windows may assign a different COM port number on a different USB socket. Note the port on the day, and make the command take it as an argument.
- Test the actual projector or screen share with a terminal: font size, colours, and whether the board's display can be seen by the audience or needs a camera.

## What to give the model along with this prompt

- `docs/coursework/demo-run-sheet.md`
- The frozen commit hash and the release notes
- The time limit and room details from K6
- The filled-in results, for the log

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

