# X2 — Dry run from a clean clone, both boards (second timed rehearsal)

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Mon 30 Nov |
| **Board bucket** | Bucket 8 — Demo Day and Close-out |
| **Board task** | Dry run from clean clone, both boards (second timed rehearsal) |
| **Needs first** | X1, A9 (release), D9 (wheel), P4 (run sheet) |
| **Unblocks** | X3 |
| **AI version** | `X2_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Everything has worked on its author's laptop. That proves less than it sounds. An author's machine has months of accumulated setup: a package installed once and forgotten, a file that was never committed, an environment variable, a COM port that happens to be right. The presentation doesn't happen on that machine in those conditions.

The dry run removes those hidden dependencies by brute force. Each demo is run from a fresh copy of the repository, at the frozen commit, on a laptop that isn't its author's, following the run sheet word for word, with the bitstream from the release. Whatever fails here would have failed in front of the audience.

It's also the second timed rehearsal, this time in person with the real boards and cables, in the room if we can get it. Sunday fixed the talk. Monday fixes the logistics: where the boards sit, who plugs in what, how the laptop hand-over works, what the projector does to the terminal font.

## 2. Where the work goes

- **Place:** in person, ideally in the presentation room; both boards, both dongles, all laptops.
- **Follow:** `docs/coursework/demo-run-sheet.md` (P4).
- **Install from:** the GitHub Release (bitstream from A9, wheel from D9) and a fresh `git clone` at the frozen commit.
- **Log:** `docs/meetings/2026-11-30.md`.

## 3. How to do it

**Setup, on a laptop that isn't the author's for each demo:**

```bash
git clone <repo-url> fecim-dryrun && cd fecim-dryrun
git checkout <frozen-hash>
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install './sw[demo]'                               # or the wheel from the release
```

Program both boards from the release's bitstream. Confirm `IDENTIFY` shows the release's `BUILD_ID` on each.

**Run every row of the run sheet,** in presentation order. For each:

| Check | |
|---|---|
| Did it run from the clean clone with the written command, unchanged? | |
| Did the output match "expected output"? | |
| How long did it take, including switching laptops or boards? | |
| If it failed: what was missing? Fix the run sheet or fall back to the recording. | |

**Then the full talk, timed,** with live demos. Practise each fallback once on purpose: mid-demo, switch to the recording as you would if it failed.

**Decide per demo:** live on Tuesday, or recording. A demo that needed a fix today goes to recording unless it then passes twice in a row.

**Before leaving:** record the commit hash and `BUILD_ID` used, charge the laptops, label the boards and cables, and agree who carries what on Tuesday.

## 4. How you know it's done

- Every demo was run from a clean clone at the frozen commit by someone other than its author, and the result is recorded.
- Both boards run the release bitstream, confirmed by `BUILD_ID`.
- The full talk with demos fits the time limit.
- Each demo is marked live or recording for Tuesday, and every fallback has been practised once.
- The run sheet is corrected wherever reality differed from it.
- The commit hash and `BUILD_ID` are recorded for the tag (X4), and the log is committed.

## 5. Watch out for

- **Don't fix things on the author's laptop and call it done.** If the clean clone fails, the repository or the run sheet is wrong, and that's what gets fixed (under the post-freeze rule in X1 if it's code).
- Check the dongle jumpers again after transport. The 3.3 V check takes one minute.
- Windows may assign a different COM port number on a different USB socket. Note the port on the day, and make the command take it as an argument.
- Test the actual projector or screen share with a terminal: font size, colours, and whether the board's display can be seen by the audience or needs a camera.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

