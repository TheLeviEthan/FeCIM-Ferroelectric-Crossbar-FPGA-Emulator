# X5 — Meeting logs, including the pre-alpha backfill

| | |
|---|---|
| **Owner** | Natalie Poche |
| **Due** | Wed 2 Dec |
| **Board bucket** | Bucket 8 — Demo Day and Close-out |
| **Board task** | Meeting logs (incl. pre-alpha backfill) |
| **Needs first** | G1, G5, P5, X2, X3 (the meetings themselves) |
| **Unblocks** | the semester-1 hand-in |
| **AI version** | `X5_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

The course grades process as well as product, and it grades what's in the repository. A decision made in a meeting and never written down might as well not have been made, both for the grade and for us in January when nobody remembers why we chose something.

The project plan calls for a log of every meeting in a `docs/meetings/` folder. That folder doesn't exist. The pre-alpha run sheet and the logs from that week were written and never committed. So part of this task is catching up, and part is recording the five meetings of this final stretch.

A meeting log doesn't need to be long. Who was there, what was decided, who's doing what by when. Ten lines written the same day are worth more than a page reconstructed two weeks later.

## 2. Where the work goes

- **Create:** `docs/meetings/`, one Markdown file per meeting named by date, for example `docs/meetings/2026-11-19.md`, plus a short `README.md` index.
- **Run sheets:** `docs/coursework/` (the presentation run sheet from P4, and the pre-alpha one if it can be recovered).
- **Sources for the backfill:** the Teams channel history, Planner task comments, the commit history around 29 Oct – 3 Nov.

## 3. How to do it

**Template for each log:**

```markdown
# Meeting — <date>, <in person | Teams>

**Present:** <names>      **Duration:** <minutes>

## Decisions
- <decision, in one sentence> — <why, in one clause>

## Status by lane
- A (Zhiting): ...
- B (Megan): ...
- C (Ethan): ...
- D (Natalie): ...

## Actions
| Action | Owner | Due |
|---|---|---|

## Notes
<anything worth keeping: demo results, questions raised, links to PRs>
```

**Logs to write:**

| Date | Meeting | Main content |
|---|---|---|
| backfill | weekly meetings to date | whatever the channel history supports |
| Mon 2 Nov | pre-alpha dry run | which demos ran, what failed |
| Tue 3 Nov | pre-alpha demo | order, results, feedback |
| Thu 19 Nov | in-person meeting | hardware gate result, decisions, rota (G1) |
| Fri 27 Nov | virtual sync | status, cuts, slide review (G5) |
| Sun 29 Nov | remote rehearsal and cutoff | timings, frozen commit (P5, X1) |
| Mon 30 Nov | dry run | per-demo results, live-or-recording decisions (X2) |
| Tue 1 Dec | presentation | questions, feedback (X3) |

For each meeting from 19 Nov on, take notes during it and commit the log the same day.

For the backfill, write only what the channel, Planner and commit history support, and mark each backfilled log clearly:

```markdown
> Reconstructed on <date> from Teams messages and commit history.
```

## 4. How you know it's done

- `docs/meetings/` exists with an index and one log per meeting in the table.
- Every log has attendees, decisions and actions with owners.
- Backfilled logs are marked as reconstructed and contain nothing that the sources don't support.
- The pre-alpha run sheet (or a note that it couldn't be recovered) and the presentation run sheet are in `docs/coursework/`.
- All of it is merged by Wed 2 Dec.

## 5. Watch out for

- **Don't invent content for the backfill.** A short honest log is fine; a detailed fictional one is a problem if anyone checks it against the commit history.
- Decisions that changed a spec should link to the commit that changed it.
- Keep personal information out: no phone numbers, no travel details beyond "remote".
- Ask each teammate to read the logs for the meetings they attended before the final merge.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

