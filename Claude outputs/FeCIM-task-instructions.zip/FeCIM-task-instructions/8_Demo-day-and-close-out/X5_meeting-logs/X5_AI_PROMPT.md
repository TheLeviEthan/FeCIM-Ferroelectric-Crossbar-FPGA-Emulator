# AI prompt — X5: Meeting logs, including the pre-alpha backfill

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **X5 — Meeting logs, including the pre-alpha backfill**, owned by Natalie Poche, due Wed 2 Dec.

Turn raw notes into meeting logs using the template provided, one file per meeting. Keep each log brief: decisions in one sentence each, actions as a table with owner and due date. For backfilled meetings, use only the chat excerpts, task comments and commit messages supplied, mark the log as reconstructed, and leave out anything that would be a guess. Also produce the index file listing each log with its date and one-line summary.

## Where the work goes

- **Create:** `docs/meetings/`, one Markdown file per meeting named by date, for example `docs/meetings/2026-11-19.md`, plus a short `README.md` index.
- **Run sheets:** `docs/coursework/` (the presentation run sheet from P4, and the pre-alpha one if it can be recovered).
- **Sources for the backfill:** the Teams channel history, Planner task comments, the commit history around 29 Oct – 3 Nov.

## Steps the owner is following

**Template for each log:**

```markdown
# Meeting — <date>, <in person | Teams>

**Present:** <names>      **Duration:** <minutes>

## Decisions
- <decision, in one sentence> — <why, in one clause>

## Status by lane
- A (Zhiting): ...
- B (Megan): ...
- C (Ethan): ...
- D (Natalie): ...

## Actions
| Action | Owner | Due |
|---|---|---|

## Notes
<anything worth keeping: demo results, questions raised, links to PRs>
```

**Logs to write:**

| Date | Meeting | Main content |
|---|---|---|
| backfill | weekly meetings to date | whatever the channel history supports |
| Mon 2 Nov | pre-alpha dry run | which demos ran, what failed |
| Tue 3 Nov | pre-alpha demo | order, results, feedback |
| Thu 19 Nov | in-person meeting | hardware gate result, decisions, rota (G1) |
| Fri 27 Nov | virtual sync | status, cuts, slide review (G5) |
| Sun 29 Nov | remote rehearsal and cutoff | timings, frozen commit (P5, X1) |
| Mon 30 Nov | dry run | per-demo results, live-or-recording decisions (X2) |
| Tue 1 Dec | presentation | questions, feedback (X3) |

For each meeting from 19 Nov on, take notes during it and commit the log the same day.

For the backfill, write only what the channel, Planner and commit history support, and mark each backfilled log clearly:

```markdown
> Reconstructed on <date> from Teams messages and commit history.
```

## What done looks like

- `docs/meetings/` exists with an index and one log per meeting in the table.
- Every log has attendees, decisions and actions with owners.
- Backfilled logs are marked as reconstructed and contain nothing that the sources don't support.
- The pre-alpha run sheet (or a note that it couldn't be recovered) and the presentation run sheet are in `docs/coursework/`.
- All of it is merged by Wed 2 Dec.

## Things to keep in mind

- **Don't invent content for the backfill.** A short honest log is fine; a detailed fictional one is a problem if anyone checks it against the commit history.
- Decisions that changed a spec should link to the commit that changed it.
- Keep personal information out: no phone numbers, no travel details beyond "remote".
- Ask each teammate to read the logs for the meetings they attended before the final merge.

## What to give the model along with this prompt

- The log template above
- Raw notes from each meeting from 19 Nov on
- For the backfill: relevant Teams messages, Planner comments, and `git log --since=2026-10-01 --date=short --format='%ad %an %s'`

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

