# D7 — MLP digits classifier (64 to 32 to 10): sim, then board

| | |
|---|---|
| **Owner** | Natalie Poche |
| **Due** | Fri 27 Nov |
| **Board bucket** | Bucket 5 — Lane D |
| **Board task** | D7: MLP digits classifier (64→32→10) — sim, then board |
| **Needs first** | D6 (mapping proven), D3; board from A5/C8 |
| **Unblocks** | D8 (MLP curves), P2 |
| **AI version** | `D7_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

A single layer can only draw straight boundaries between classes. Real neural networks stack layers with a nonlinearity in between, and that's where their power comes from. The semester-1 target application is the smallest real example: 64 inputs, a hidden layer of 32, and 10 outputs.

Running it on our array shows two things the linear classifier can't.

First, **multi-layer execution**. The output of layer 1 becomes the input of layer 2. Between them the host applies ReLU (negative values become zero) and rescales to 8 bits. ReLU outputs are never negative, which matches the physical fact that our activations are unsigned drive voltages. This is the place where that design decision earns its keep.

Second, **the cost of reloading weights**. Our emulator has one tile. A two-layer network needs two weight matrices, so the tile is reprogrammed between layers. The multiply itself takes microseconds; a reload over UART takes a large fraction of a second. Showing that honestly, with measured numbers, is the motivation for the semester-2 multi-tile work, and it's a property of our single-tile emulator, not of crossbar accelerators in general.

Noise also compounds through layers: errors in layer 1 feed layer 2. So the MLP's accuracy-versus-noise curves are the more realistic result.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **New script:** `sw/examples/digits_mlp.py`, same options as `digits.py`.
- **Network wrapper:** an `MLPNet` class beside `LinearNet` in `sw/fecim/networks.py`, with the same `load` / `classify` shape so the sweep harness can use either.
- **Mapping:** `sw/fecim/mapping.py`, reused from D6.
- **Tests:** add to `sw/tests/test_mapping.py`: two-layer forward pass against a float reference.
- **Specs:** `05-lane-d-host/application-spec.md` §2.3–2.7, §3.2, §3.3.

## 3. How to build it

```python
from sklearn.neural_network import MLPClassifier
mlp = MLPClassifier(hidden_layer_sizes=(32,), activation="relu", max_iter=1000, random_state=0).fit(Xtr, ytr)
W1, b1 = mlp.coefs_[0], mlp.intercepts_[0]             # (64, 32), (32,)   already (inputs, outputs)
W2, b2 = mlp.coefs_[1], mlp.intercepts_[1]             # (32, 10), (10,)

# ---- layer 1: need all 32 values back, so use READ_RESULT and descale on the host ----
s_w1 = np.abs(W1).max() / 127.0;  W1q = np.round(W1 / s_w1).astype(np.int8)
s_a1 = 16.0 / 255.0
def layer1(x):
    xbar.write_activations_raw(np.round(x / s_a1).astype(np.uint8)); xbar.compute()
    acc = xbar.read_results(0, 32)
    return np.maximum(acc * s_w1 * s_a1 + b1, 0.0)      # descale, add bias, ReLU (host)

# ---- between layers: requantize the hidden vector to uint8 with a FIXED scale ----
h_max = percentile(hidden activations over the TRAINING set, 99.9)   # computed once
s_a2  = h_max / 255.0
hq    = lambda h: np.clip(np.round(h / s_a2), 0, 255).astype(np.uint8)

# ---- layer 2: 10 outputs; bias as an always-on row so on-chip argmax is valid (as in D6) ----
s_w2  = np.abs(W2).max() / 127.0
W2q   = np.vstack([np.round(W2 / s_w2), np.round(b2 / (s_w2 * s_a2 * 255))]).astype(np.int8)   # (33, 10)
```

**Two ways to schedule the reloads**, and you need both:

```text
per-image (the honest single-tile cost; time this for the slide):
    for each image:  load W1 -> compute -> read 32 -> load W2 -> compute -> READ_ARGMAX

per-layer batch (what sweeps use; two loads total for the whole test set):
    load W1; for each image: compute, read 32, keep hidden vector on the host
    load W2; for each image: write hidden vector, compute, READ_ARGMAX
```

`sklearn`'s `coefs_` for an MLP are already (inputs, outputs), unlike `LogisticRegression.coef_`. Don't transpose them.

Print a time breakdown for the per-image schedule: weight reload, activation write, compute (`CYCLE_CNT` × 20 ns), readout.

## 4. How you know it's done

- `python sw/examples/digits_mlp.py --backend sim` prints float, ideal-quantized and set-A accuracy, each per class, with a fixed split and seed.
- With noise off, quantized accuracy is within a point or two of the float MLP.
- The requantization between layers is documented in the script and matches spec §2.3–2.5; the two-layer mapping test passes against a float forward pass.
- `--backend fpga` gives identical predictions to `sim` (same schedule, same seed).
- The per-image time breakdown is recorded: reload versus compute versus readout.
- A 30-second backup recording exists.

## 5. Watch out for

- **The transpose differs between the two demos.** `LogisticRegression.coef_` is (outputs, inputs); `MLPClassifier.coefs_[i]` is (inputs, outputs). The orientation test catches a mistake either way.
- **Use a fixed hidden-layer scale,** calibrated once on the training set. A per-image scale would change the relative size of weights and bias in layer 2 from image to image.
- **Clipping at the 99.9th percentile** trades a little saturation for better resolution. Record the clip rate; if accuracy suffers, use the maximum instead.
- **The read-noise sequence depends on the order of computes.** The two schedules above visit computes in different orders, so with read noise on they give statistically equivalent but not identical results. For the cross-backend exact match, use the same schedule on both backends.
- **Write-time effects are applied at every reload.** In the per-image schedule each layer's weights are re-perturbed by the same cell hash each time (same addresses, same seed), so the result is stable; that's the "same physical chip" behaviour we want.
- An optional refinement, only if there's time: both layers fit on the tile at once (layer 2 in columns 0–9, layer 1 in columns 10–41), switching `TILE_CFG` between them instead of reloading. It removes the reload cost, which is the very thing the spec wants shown, so present it as an optimization next to the baseline, not instead of it.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

