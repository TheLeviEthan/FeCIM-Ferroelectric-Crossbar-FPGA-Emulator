# D1 — Packaging: pyproject.toml and pip install -e ./sw

| | |
|---|---|
| **Owner** | Natalie Poche |
| **Due** | Tue 17 Nov |
| **Board bucket** | Bucket 5 — Lane D |
| **Board task** | D1: Packaging — `pyproject.toml`, `pip install -e ./sw` |
| **Needs first** | K3 (your branch merged) |
| **Unblocks** | D2–D9, C5 (imports the encoder), C7 (the CI `python` job), C8 |
| **AI version** | `D1_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Right now the host code is a folder of Python files that works when you run it from the right directory. A *package* is that same code with a small description file that tells Python how to install it, what it depends on and what it's called. After that, anyone can type one command and then `import fecim` from anywhere.

That sounds like housekeeping, and three things depend on it this week. Ethan's co-simulation imports your packet encoder to generate its test stimulus. The CI `python` job skips itself until `sw/pyproject.toml` exists, so today none of your tests run in CI at all, and a broken host package wouldn't be noticed. And every demo command in the presentation starts with "install the package".

The course also asks for software that builds from source with a single command. A `pyproject.toml` is how a Python project meets that requirement.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **New file:** `sw/pyproject.toml`.
- **Package folder:** `sw/fecim/` (already exists, with `protocol.py`, `codec.py`, `transport.py`, `config.py`, `mapping.py`, `sweep.py`, `drivers/`, `parameter_sets/`).
- **Clean up while you're here:**
  - `sw/fecim/code.py` is a 0-byte file: delete it.
  - `sw/fecim/crossbar.py` is also 0 bytes: it becomes the real `Crossbar` class in D2/D3; until then put a one-line docstring in it.
  - `sw/fecim/plan-d.yml` contains the `gf28_hkmg` parameter set, not a plan: move it to `sw/fecim/parameter_sets/gf28_hkmg.yaml`.
  - `sw/fecim/config.yaml` names `parameter_set: "gf28_hkmg"` and has no newline at the end of the file.
- **CI:** the `python` job in `.github/workflows/ci.yml`. It already runs `pip install -e './sw[test]'` and `pytest sw/tests`, behind a gate step that skips the job while `sw/pyproject.toml` is missing. The file says to remove that gate once the package is on `main`.
- **Spec:** `05-lane-d-host/host-driver-spec.md` §7.

## 3. How to build it

```toml
# sw/pyproject.toml
[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"

[project]
name = "fecim"
version = "0.2.0"
description = "Host driver and applications for the FeCIM ferroelectric crossbar emulator"
requires-python = ">=3.10"
dependencies = ["numpy", "pyserial", "pyyaml"]

[project.optional-dependencies]
test = ["pytest"]
plot = ["matplotlib"]
demo = ["scikit-learn", "matplotlib"]

[tool.setuptools.packages.find]
where = ["."]
include = ["fecim*"]

[tool.setuptools.package-data]
fecim = ["parameter_sets/*.yaml", "*.yaml"]

[tool.pytest.ini_options]
testpaths = ["tests"]
```

Then check it the way a stranger would:

```bash
python -m venv /tmp/fecim-venv && source /tmp/fecim-venv/bin/activate
pip install -e './sw[test]'
python -c "import fecim, fecim.protocol; print(fecim.protocol.build_packet(0x06).hex())"
pytest sw/tests
```

Do the same in a Windows terminal, since two of you run the board from Windows.

Keep runtime dependencies minimal: `matplotlib` and `scikit-learn` are extras, because someone running a sweep on the board shouldn't need a plotting library.

## 4. How you know it's done

- `pip install -e './sw[test]'` works in a fresh virtual environment on Windows and in WSL.
- `import fecim` works from any directory, and the parameter-set YAML files are found after installation (load one by package-relative path).
- `pytest sw/tests` passes locally, and the CI `python` job actually runs the tests (the gate step is removed) and is green.
- The two empty files and the misnamed YAML are dealt with.
- The repo `README.md` install instructions match what you actually typed.

## 5. Watch out for

- **Don't add the C++ extension build yet.** The spec's end state uses `scikit-build-core` and pybind11 so that `pip install` compiles the model. That's D3 and D9. A pure-Python package today unblocks three other people; the compiled part can be added without changing the package name.
- **`import fecim` must keep working when the C++ part is absent** (spec §7.3). Don't import the compiled module at package import time.
- If a test imports with `sys.path` tricks, remove them now that the package is installed properly.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

