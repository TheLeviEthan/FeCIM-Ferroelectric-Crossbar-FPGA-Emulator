# AI prompt — D1: Packaging: pyproject.toml and pip install -e ./sw

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **D1 — Packaging: pyproject.toml and pip install -e ./sw**, owned by Natalie Poche, due Tue 17 Nov.

Turn the existing `sw/fecim` folder into an installable Python package: write `sw/pyproject.toml` (setuptools backend, minimal runtime dependencies, `test` / `plot` / `demo` extras, package data for the YAML parameter sets), tidy the stray files, and make sure `pip install -e './sw[test]'` followed by `pytest sw/tests` works from a clean environment.

Look at how the existing modules and tests import each other and fix anything that only works because of the current working directory. Don't restructure the package or rename modules; other lanes import `fecim.protocol` already. Editable files: `sw/pyproject.toml` (new), files under `sw/` as needed for imports and cleanup, and the install section of the repo `README.md`. Report anything in the tests that looks like it was never being collected or run.

## Where the work goes

- **New file:** `sw/pyproject.toml`.
- **Package folder:** `sw/fecim/` (already exists, with `protocol.py`, `codec.py`, `transport.py`, `config.py`, `mapping.py`, `sweep.py`, `drivers/`, `parameter_sets/`).
- **Clean up while you're here:**
  - `sw/fecim/code.py` is a 0-byte file: delete it.
  - `sw/fecim/crossbar.py` is also 0 bytes: it becomes the real `Crossbar` class in D2/D3; until then put a one-line docstring in it.
  - `sw/fecim/plan-d.yml` contains the `gf28_hkmg` parameter set, not a plan: move it to `sw/fecim/parameter_sets/gf28_hkmg.yaml`.
  - `sw/fecim/config.yaml` names `parameter_set: "gf28_hkmg"` and has no newline at the end of the file.
- **CI:** the `python` job in `.github/workflows/ci.yml`. It already runs `pip install -e './sw[test]'` and `pytest sw/tests`, behind a gate step that skips the job while `sw/pyproject.toml` is missing. The file says to remove that gate once the package is on `main`.
- **Spec:** `05-lane-d-host/host-driver-spec.md` §7.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```toml
# sw/pyproject.toml
[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"

[project]
name = "fecim"
version = "0.2.0"
description = "Host driver and applications for the FeCIM ferroelectric crossbar emulator"
requires-python = ">=3.10"
dependencies = ["numpy", "pyserial", "pyyaml"]

[project.optional-dependencies]
test = ["pytest"]
plot = ["matplotlib"]
demo = ["scikit-learn", "matplotlib"]

[tool.setuptools.packages.find]
where = ["."]
include = ["fecim*"]

[tool.setuptools.package-data]
fecim = ["parameter_sets/*.yaml", "*.yaml"]

[tool.pytest.ini_options]
testpaths = ["tests"]
```

Then check it the way a stranger would:

```bash
python -m venv /tmp/fecim-venv && source /tmp/fecim-venv/bin/activate
pip install -e './sw[test]'
python -c "import fecim, fecim.protocol; print(fecim.protocol.build_packet(0x06).hex())"
pytest sw/tests
```

Do the same in a Windows terminal, since two of you run the board from Windows.

Keep runtime dependencies minimal: `matplotlib` and `scikit-learn` are extras, because someone running a sweep on the board shouldn't need a plotting library.

## Acceptance checks

- `pip install -e './sw[test]'` works in a fresh virtual environment on Windows and in WSL.
- `import fecim` works from any directory, and the parameter-set YAML files are found after installation (load one by package-relative path).
- `pytest sw/tests` passes locally, and the CI `python` job actually runs the tests (the gate step is removed) and is green.
- The two empty files and the misnamed YAML are dealt with.
- The repo `README.md` install instructions match what you actually typed.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Don't add the C++ extension build yet.** The spec's end state uses `scikit-build-core` and pybind11 so that `pip install` compiles the model. That's D3 and D9. A pure-Python package today unblocks three other people; the compiled part can be added without changing the package name.
- **`import fecim` must keep working when the C++ part is absent** (spec §7.3). Don't import the compiled module at package import time.
- If a test imports with `sys.path` tricks, remove them now that the package is installed properly.

## Files to read first (attach or paste these if you're using a chatbot)

- A listing of `sw/` (all files)
- `sw/fecim/protocol.py`, `sw/fecim/codec.py`, `sw/fecim/transport.py`, `sw/fecim/config.py`, `sw/fecim/config.yaml`, `sw/fecim/plan-d.yml`, `sw/fecim/drivers/base.py`, `sw/fecim/drivers/factory.py`
- `sw/tests/` (all), `sw/tests/README.md`
- `.github/workflows/ci.yml` (the `python` job)
- `docs/plans and specs/05-lane-d-host/host-driver-spec.md` (§7)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

