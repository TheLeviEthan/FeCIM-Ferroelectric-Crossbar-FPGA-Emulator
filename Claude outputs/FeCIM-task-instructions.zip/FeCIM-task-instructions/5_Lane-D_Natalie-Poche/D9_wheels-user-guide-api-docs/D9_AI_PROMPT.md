# AI prompt — D9: Wheels, clean-machine test, user guide and API docs

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **D9 — Wheels, clean-machine test, user guide and API docs**, owned by Natalie Poche, due Sat 28 Nov.

Finish the host package for release: wheel and source-distribution builds (locally and in CI on a tag), a clean-machine test procedure, a user guide, and API documentation for the public classes.

Write the user guide for an engineering student who has never seen this repository: installation, a first run on the `sim` backend with no hardware, connecting a board, configuring non-idealities in physical units, loading a published parameter set, running the digit classifiers and a sweep, and troubleshooting by error type. Write or improve docstrings for every public method with units, valid ranges, the registers written and the exceptions raised, and produce an API reference page from them.

Take every command and function name from the code you're given, and flag anything the guide needs that doesn't exist yet instead of documenting it as if it did. Editable files: `sw/pyproject.toml`, docstrings under `sw/fecim/`, a wheel-build workflow under `.github/workflows/`, `docs/user-guide.md` (new), `docs/api.md` (new), `docs/coursework/clean-machine-test.md` (new).

## Where the work goes

- **Build config:** `sw/pyproject.toml` (from D1; extended here if the C++ extension is packaged).
- **Wheel build in CI:** a new job or workflow in `.github/workflows/` that runs `python -m build` on a tag and uploads the artifacts; with a compiled extension, `cibuildwheel` (spec §7.1).
- **User guide:** new `docs/user-guide.md`.
- **API reference:** docstrings in `sw/fecim/crossbar.py`, `sweep.py`, `calibration.py`, `networks.py`, plus a generated or hand-written `docs/api.md`.
- **Clean-machine log:** `docs/coursework/clean-machine-test.md`.
- **Release:** the wheel is attached to the same GitHub Release as Zhiting's bitstream (A9).
- **Spec:** `05-lane-d-host/host-driver-spec.md` §7.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```bash
# build
python -m pip install build
python -m build sw                 # -> sw/dist/fecim-<version>-py3-none-any.whl and .tar.gz

# clean-machine test (a teammate's laptop, or a fresh VM / container)
python -m venv t && source t/bin/activate          # Windows: t\Scripts\activate
pip install fecim-<version>-py3-none-any.whl[demo]
python -c "import fecim; print(fecim.__version__)"
python -m fecim.examples.digits --backend sim       # or however the examples are exposed
```

Write down every step where the tester had to ask you something. Each one is a documentation bug.

**User guide outline:**

1. What FeCIM is, in five sentences, and what you need (board optional).
2. Install: from the wheel, and from source.
3. First run with no hardware: `Crossbar(backend="sim")`, one matrix-vector product.
4. Connecting a board: link to the replication guide (A9); `Crossbar(backend="fpga", port=...)`.
5. Configuring non-idealities in physical units; `enable([...])`; `seed(n)`.
6. Loading a published parameter set, and what "swept" and "composite" mean.
7. Running the digit classifiers.
8. Running a sweep and regenerating a plot; where provenance is stored.
9. Troubleshooting: no reply, version mismatch, busy, address range, sequence error.

**API reference:** every public method gets a docstring with its arguments, units, valid range, what it writes to the board, and what it raises. Units matter most: say whether a sigma is in LSB or millivolts.

## Acceptance checks

- `python -m build sw` produces a wheel and a source distribution, in CI as well as locally.
- A teammate installs the wheel on a machine without the repo and runs the `sim` digits demo using only the user guide. The log of that test is committed, with the fixes it prompted.
- Every public `Crossbar` method has a docstring with units and ranges; the API reference is committed.
- The user guide's commands were copied from a terminal where they worked.
- The wheel is attached to the GitHub Release for the cutoff commit.
- If the compiled model isn't in the wheel, the guide says so plainly and gives the source-build steps for `backend="sim"`.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Pure-Python wheel versus compiled wheel.** If D3 shipped the subprocess fallback, the wheel is pure Python and `backend="sim"` needs the model built from source with CMake. That's acceptable for this deadline; say it clearly in the guide. Compiled wheels for three platforms through `cibuildwheel` are worth doing only if the pybind11 route is already working.
- **Examples inside a wheel.** `sw/examples/` isn't part of the installed package. Either move the demos into `fecim/examples/` so they ship, or tell users to get them from the repository.
- Keep the version number in one place and bump it for the release, in step with the bitstream's `BUILD_ID`.
- Don't document functions that don't exist yet. Generate the API page from the code as merged at the cutoff.

## Files to read first (attach or paste these if you're using a chatbot)

- `sw/pyproject.toml`, `sw/fecim/` (all public modules), `sw/examples/`
- `README.md` (repo root), `sw/README.md`
- `docs/replication-guide.md` (A9), `docs/plans and specs/02-lane-a-interface/hardware.md`
- `docs/plans and specs/05-lane-d-host/host-driver-spec.md` (§6, §7), `application-spec.md`
- `.github/workflows/ci.yml`

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

