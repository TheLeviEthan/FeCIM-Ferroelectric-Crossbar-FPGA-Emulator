# D9 — Wheels, clean-machine test, user guide and API docs

| | |
|---|---|
| **Owner** | Natalie Poche |
| **Due** | Sat 28 Nov |
| **Board bucket** | Bucket 5 — Lane D |
| **Board task** | D9: Wheels, clean-machine test, user guide + API docs |
| **Needs first** | D1–D7 stable; A9's replication guide (links to this) |
| **Unblocks** | X2 (dry run on someone else's laptop), X4 |
| **AI version** | `D9_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Software that only runs on its author's laptop isn't finished. The last step is making it something another person can install and use without you in the room.

Three pieces do that. A **wheel** is a pre-built installable file: one `pip install` and it works, with no need to clone the repo or (if we ship the compiled model) own a C++ compiler. The **clean-machine test** is the honest check: install it on a computer that has never seen this project and follow your own instructions. It always finds something, usually a dependency you forgot you'd installed months ago. The **user guide and API reference** explain how to use it and what each function does.

The course asks for a source build that works with one command, binary builds for supported platforms, and user documentation. This task is that requirement. It's also what the dry run tests on Mon 30 Nov, when every demo has to run from a clean clone on a laptop that isn't the author's.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Build config:** `sw/pyproject.toml` (from D1; extended here if the C++ extension is packaged).
- **Wheel build in CI:** a new job or workflow in `.github/workflows/` that runs `python -m build` on a tag and uploads the artifacts; with a compiled extension, `cibuildwheel` (spec §7.1).
- **User guide:** new `docs/user-guide.md`.
- **API reference:** docstrings in `sw/fecim/crossbar.py`, `sweep.py`, `calibration.py`, `networks.py`, plus a generated or hand-written `docs/api.md`.
- **Clean-machine log:** `docs/coursework/clean-machine-test.md`.
- **Release:** the wheel is attached to the same GitHub Release as Zhiting's bitstream (A9).
- **Spec:** `05-lane-d-host/host-driver-spec.md` §7.

## 3. How to build it

```bash
# build
python -m pip install build
python -m build sw                 # -> sw/dist/fecim-<version>-py3-none-any.whl and .tar.gz

# clean-machine test (a teammate's laptop, or a fresh VM / container)
python -m venv t && source t/bin/activate          # Windows: t\Scripts\activate
pip install fecim-<version>-py3-none-any.whl[demo]
python -c "import fecim; print(fecim.__version__)"
python -m fecim.examples.digits --backend sim       # or however the examples are exposed
```

Write down every step where the tester had to ask you something. Each one is a documentation bug.

**User guide outline:**

1. What FeCIM is, in five sentences, and what you need (board optional).
2. Install: from the wheel, and from source.
3. First run with no hardware: `Crossbar(backend="sim")`, one matrix-vector product.
4. Connecting a board: link to the replication guide (A9); `Crossbar(backend="fpga", port=...)`.
5. Configuring non-idealities in physical units; `enable([...])`; `seed(n)`.
6. Loading a published parameter set, and what "swept" and "composite" mean.
7. Running the digit classifiers.
8. Running a sweep and regenerating a plot; where provenance is stored.
9. Troubleshooting: no reply, version mismatch, busy, address range, sequence error.

**API reference:** every public method gets a docstring with its arguments, units, valid range, what it writes to the board, and what it raises. Units matter most: say whether a sigma is in LSB or millivolts.

## 4. How you know it's done

- `python -m build sw` produces a wheel and a source distribution, in CI as well as locally.
- A teammate installs the wheel on a machine without the repo and runs the `sim` digits demo using only the user guide. The log of that test is committed, with the fixes it prompted.
- Every public `Crossbar` method has a docstring with units and ranges; the API reference is committed.
- The user guide's commands were copied from a terminal where they worked.
- The wheel is attached to the GitHub Release for the cutoff commit.
- If the compiled model isn't in the wheel, the guide says so plainly and gives the source-build steps for `backend="sim"`.

## 5. Watch out for

- **Pure-Python wheel versus compiled wheel.** If D3 shipped the subprocess fallback, the wheel is pure Python and `backend="sim"` needs the model built from source with CMake. That's acceptable for this deadline; say it clearly in the guide. Compiled wheels for three platforms through `cibuildwheel` are worth doing only if the pybind11 route is already working.
- **Examples inside a wheel.** `sw/examples/` isn't part of the installed package. Either move the demos into `fecim/examples/` so they ship, or tell users to get them from the repository.
- Keep the version number in one place and bump it for the release, in step with the bitstream's `BUILD_ID`.
- Don't document functions that don't exist yet. Generate the API page from the code as merged at the cutoff.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

