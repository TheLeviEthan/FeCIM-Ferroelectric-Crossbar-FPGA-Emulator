# AI prompt — D4: Parameter set to registers, and IR profile generation

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **D4 — Parameter set to registers, and IR profile generation**, owned by Natalie Poche (calibration co-owner with Ethan Ruddell), due Mon 23 Nov.

Implement the calibration path in the host package: pure conversion functions from published device quantities to register values, a validating YAML loader for parameter sets, the physical-unit setters on `Crossbar`, an IR-drop profile generator, and `load_parameter_set(name)`.

Take every conversion constant from `cell-physics-derivation.md` §4 and `protocol.md` §6.3; don't derive your own. `QUANT_LEVELS` and `QUANT_MULT` must only ever be written as a pair, and `quant_mult` must match the C++ `quant_mult_for` for every level count, so use integer arithmetic for it. A parameter that's `null` in the data file is a deliberate "not reported": never substitute a default; report it back as swept.

Write unit tests that pin the documented values for set A and the spec's worked example. Editable files: everything under `sw/`. If the YAML files, the schema in `device-model.md` and the spec disagree anywhere, list it.

## Where the work goes

- **New module:** `sw/fecim/calibration.py` (pure functions: device units in, register values out) and a loader for the YAML files.
- **Public API additions in `sw/fecim/crossbar.py`** (spec §6): `set_quantization(levels)`, `set_variation(sigma_lsb=... | sigma_vth_mv=..., memory_window_v=...)`, `set_read_noise(...)`, `set_faults(rate, mode)`, `set_adc(bits)`, `set_ir_drop(kappa=... | coeffs=...)`, `enable([...])`, `seed(n)`, and `load_parameter_set(name)`.
- **Data files:** `sw/fecim/parameter_sets/dualport_fefet_mlc.yaml` (set A) and `gf28_hkmg.yaml` (set B, after the D1 rename). Schema: `device-model.md` §4.
- **Tests:** `sw/tests/test_calibration.py`.
- **Specs:** `06-physics-calibration/device-model.md` §4–6; `cell-physics-derivation.md` §4; `01-contract/protocol.md` §6.2, §6.3, §6.5; `host-driver-spec.md` §6.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```python
def sigma_lsb(sigma_vth_mv, memory_window_v):
    return 255.0 * (sigma_vth_mv / 1000.0) / memory_window_v      # weight LSBs

def quant_mult(levels):                    # integer round-half-up, same as the C++ model
    return (255 * 256 + (levels - 1) // 2) // (levels - 1)

def d2d_sigma_reg(s_lsb):   return round(2.450 * s_lsb)           # scale reg/256
def read_sigma_reg(s_lsb):  return round(6.93  * s_lsb)           # scale reg/512
def stuck_rate_reg(p, mode="zero"):
    return round(65536 * p) | ((1 << 16) if mode == "rail" else 0)

def ir_profile(kappa, rows=128):           # first-order: far rows see a weaker drive
    alpha = [1.0 - kappa * i / rows for i in range(rows)]
    return bytes(min(255, round(256 * a)) for a in alpha)

def set_quantization(self, levels):        # the two registers are ALWAYS written together
    if not 2 <= levels <= 255: raise ValueError(...)
    self._backend.set_config(REG_QUANT_LEVELS, levels)
    self._backend.set_config(REG_QUANT_MULT, quant_mult(levels))
```

`load_parameter_set(name)`:

```text
1. read and validate the YAML (required keys, known keys only, confidence per parameter)
2. quant_levels  -> set_quantization
3. sigma_vth_mv + memory_window_v -> set_variation
4. read_sigma_vth_mv: if null, leave READ_SIGMA alone and report it as "swept"
5. stuck_rate:        if null, same
6. return a summary: {applied: {...register values...}, swept: [...], source: "...", composite: bool}
```

It sets values but doesn't enable anything. `enable(["quant", "d2d"])` is a separate, explicit call, by name.

Numbers your test should pin for set A (these are the ones in Ethan's C6 document): `QUANT_LEVELS` 8, `QUANT_MULT` 9326, σ = 7.44 LSB, `D2D_SIGMA` 18.

## Acceptance checks

- `test_calibration.py` pins set A's values (8, 9326, 18) and the spec's worked example (50 mV at 1.0 V → 12.8 LSB → 31).
- `quant_mult(n)` equals the C++ `quant_mult_for(n)` for every n from 2 to 255 (expected values in `write_path.h`: 2 → 65280, 3 → 32640, 5 → 16320, 8 → 9326, 255 → 257).
- A `null` parameter is never silently replaced with a number; it shows up in the returned summary as swept.
- Unknown YAML keys and out-of-range results raise or warn; nothing is clamped silently.
- Round trip on `sim` and on a board: load a set, `GET_CONFIG` each register, compare.
- `set_ir_drop(kappa=0.05)` writes 128 coefficients with one `WRITE_ATTEN` and the profile is plotted for the slides.
- `seed(n)` writes `NOISE_SEED` and then pulses `CTRL[2]`.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Python's `round()` rounds halves to even** (`round(2.5)` is 2). For `QUANT_MULT` use the integer formula above so it always matches the C++ model. For the sigma registers a half-way case is vanishingly unlikely, and the test pins the values anyway.
- **The two sigma registers have different scales** (2.450 and 6.93 per LSB). Swapping them is off by a factor of about 2.8 and produces a perfectly plausible-looking wrong sweep.
- **Range limits:** `D2D_SIGMA` tops out at 255 (about 104 LSB) and `READ_SIGMA` at 255 (about 36.8 LSB). Warn when a request exceeds them; a silent clamp makes a sweep flatten at the top for no visible reason.
- **`set_adc(bits)`** takes ADC bits, valid from 4 to `ACC_USED_W` (24), where 24 is an exact no-op.
- **Coefficient 255 isn't unity** (it's 255/256). "No IR drop" is the enable bit, not `kappa = 0`.
- The YAML stores raw device quantities only. Don't add register values to it.
- Set A is TCAD-simulated and the summary's `source` should make that visible wherever it's printed.

## Files to read first (attach or paste these if you're using a chatbot)

- `sw/fecim/crossbar.py`, `sw/fecim/backends/` (from D2/D3)
- `sw/fecim/parameter_sets/dualport_fefet_mlc.yaml`, `sw/fecim/parameter_sets/README.md`, the `gf28_hkmg` YAML
- `model/include/fecim/write_path.h` (for `quant_mult_for` and its expected values)
- `docs/plans and specs/06-physics-calibration/device-model.md`, `cell-physics-derivation.md`
- `docs/plans and specs/05-lane-d-host/host-driver-spec.md` (§6)
- `docs/plans and specs/01-contract/protocol.md` (§6)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

