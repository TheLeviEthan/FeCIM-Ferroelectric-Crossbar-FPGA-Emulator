# D4 — Parameter set to registers, and IR profile generation

| | |
|---|---|
| **Owner** | Natalie Poche (calibration co-owner with Ethan Ruddell) |
| **Due** | Mon 23 Nov |
| **Board bucket** | Bucket 5 — Lane D |
| **Board task** | D4: Parameter set → registers + IR profile generation |
| **Needs first** | D2 or D3 (a working `Crossbar`), C6 (the documented mapping) |
| **Unblocks** | D5, D6, D8, C9 |
| **AI version** | `D4_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

A device paper reports physical quantities: a memory window of 2.7 volts, a threshold spread of 78.75 millivolts, 8 distinguishable levels. The FPGA wants register values: `QUANT_LEVELS = 8`, `QUANT_MULT = 9326`, `D2D_SIGMA = 18`. This task is the code that converts one into the other.

Putting the conversion in code, in one place, matters for three reasons. Nobody types `18` by hand and gets it wrong. The data files stay in the paper's own units, so if we ever fix the conversion, no stale register values are left lying around. And switching the emulator from one published device technology to another becomes a single call: `xbar.load_parameter_set("dualport_fefet_mlc")`. That one-liner is a nice moment in the demo, and it's what makes the semester-2 goal (comparing three technologies) a matter of adding two data files.

You and Ethan co-own calibration on purpose. He documents the derivation (C6); you implement it. Each checks the other, and your unit test pins the numbers his document states.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **New module:** `sw/fecim/calibration.py` (pure functions: device units in, register values out) and a loader for the YAML files.
- **Public API additions in `sw/fecim/crossbar.py`** (spec §6): `set_quantization(levels)`, `set_variation(sigma_lsb=... | sigma_vth_mv=..., memory_window_v=...)`, `set_read_noise(...)`, `set_faults(rate, mode)`, `set_adc(bits)`, `set_ir_drop(kappa=... | coeffs=...)`, `enable([...])`, `seed(n)`, and `load_parameter_set(name)`.
- **Data files:** `sw/fecim/parameter_sets/dualport_fefet_mlc.yaml` (set A) and `gf28_hkmg.yaml` (set B, after the D1 rename). Schema: `device-model.md` §4.
- **Tests:** `sw/tests/test_calibration.py`.
- **Specs:** `06-physics-calibration/device-model.md` §4–6; `cell-physics-derivation.md` §4; `01-contract/protocol.md` §6.2, §6.3, §6.5; `host-driver-spec.md` §6.

## 3. How to build it

```python
def sigma_lsb(sigma_vth_mv, memory_window_v):
    return 255.0 * (sigma_vth_mv / 1000.0) / memory_window_v      # weight LSBs

def quant_mult(levels):                    # integer round-half-up, same as the C++ model
    return (255 * 256 + (levels - 1) // 2) // (levels - 1)

def d2d_sigma_reg(s_lsb):   return round(2.450 * s_lsb)           # scale reg/256
def read_sigma_reg(s_lsb):  return round(6.93  * s_lsb)           # scale reg/512
def stuck_rate_reg(p, mode="zero"):
    return round(65536 * p) | ((1 << 16) if mode == "rail" else 0)

def ir_profile(kappa, rows=128):           # first-order: far rows see a weaker drive
    alpha = [1.0 - kappa * i / rows for i in range(rows)]
    return bytes(min(255, round(256 * a)) for a in alpha)

def set_quantization(self, levels):        # the two registers are ALWAYS written together
    if not 2 <= levels <= 255: raise ValueError(...)
    self._backend.set_config(REG_QUANT_LEVELS, levels)
    self._backend.set_config(REG_QUANT_MULT, quant_mult(levels))
```

`load_parameter_set(name)`:

```text
1. read and validate the YAML (required keys, known keys only, confidence per parameter)
2. quant_levels  -> set_quantization
3. sigma_vth_mv + memory_window_v -> set_variation
4. read_sigma_vth_mv: if null, leave READ_SIGMA alone and report it as "swept"
5. stuck_rate:        if null, same
6. return a summary: {applied: {...register values...}, swept: [...], source: "...", composite: bool}
```

It sets values but doesn't enable anything. `enable(["quant", "d2d"])` is a separate, explicit call, by name.

Numbers your test should pin for set A (these are the ones in Ethan's C6 document): `QUANT_LEVELS` 8, `QUANT_MULT` 9326, σ = 7.44 LSB, `D2D_SIGMA` 18.

## 4. How you know it's done

- `test_calibration.py` pins set A's values (8, 9326, 18) and the spec's worked example (50 mV at 1.0 V → 12.8 LSB → 31).
- `quant_mult(n)` equals the C++ `quant_mult_for(n)` for every n from 2 to 255 (expected values in `write_path.h`: 2 → 65280, 3 → 32640, 5 → 16320, 8 → 9326, 255 → 257).
- A `null` parameter is never silently replaced with a number; it shows up in the returned summary as swept.
- Unknown YAML keys and out-of-range results raise or warn; nothing is clamped silently.
- Round trip on `sim` and on a board: load a set, `GET_CONFIG` each register, compare.
- `set_ir_drop(kappa=0.05)` writes 128 coefficients with one `WRITE_ATTEN` and the profile is plotted for the slides.
- `seed(n)` writes `NOISE_SEED` and then pulses `CTRL[2]`.

## 5. Watch out for

- **Python's `round()` rounds halves to even** (`round(2.5)` is 2). For `QUANT_MULT` use the integer formula above so it always matches the C++ model. For the sigma registers a half-way case is vanishingly unlikely, and the test pins the values anyway.
- **The two sigma registers have different scales** (2.450 and 6.93 per LSB). Swapping them is off by a factor of about 2.8 and produces a perfectly plausible-looking wrong sweep.
- **Range limits:** `D2D_SIGMA` tops out at 255 (about 104 LSB) and `READ_SIGMA` at 255 (about 36.8 LSB). Warn when a request exceeds them; a silent clamp makes a sweep flatten at the top for no visible reason.
- **`set_adc(bits)`** takes ADC bits, valid from 4 to `ACC_USED_W` (24), where 24 is an exact no-op.
- **Coefficient 255 isn't unity** (it's 255/256). "No IR drop" is the enable bit, not `kappa = 0`.
- The YAML stores raw device quantities only. Don't add register values to it.
- Set A is TCAD-simulated and the summary's `source` should make that visible wherever it's printed.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

