# D2 — Full command set in the driver

| | |
|---|---|
| **Owner** | Natalie Poche |
| **Due** | Thu 19 Nov |
| **Board bucket** | Bucket 5 — Lane D |
| **Board task** | D2: Full command set in the driver |
| **Needs first** | D1; A2 on Zhiting's side for the live test |
| **Unblocks** | A2 demo, C8, D4, D5, D6 |
| **AI version** | `D2_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

The FPGA speaks a compact binary protocol: a sync byte, a command, a length, a payload and a checksum. Nobody wants to write an experiment in those terms. The driver is the translator that lets a user write `xbar.set_quantization(levels=8)` or `xbar.compute()` and get the right bytes on the wire and the right numbers back.

It's also where the system's reliability lives. A serial cable occasionally drops or corrupts a byte. The driver has to notice (checksum or timeout), wait for the board to settle, retry, and be certain it never hands the user results from the *previous* input by mistake. A sweep is tens of thousands of transactions, and one silently wrong answer makes the whole plot unreproducible.

Finally, it's the abstraction that makes the board swappable for the C++ model. If the board backend and the `sim` backend expose the same eight operations, then every application, sweep and test runs on either one unchanged, and "the board matches the model" becomes a one-line comparison.

On Thursday this is one half of the hardware gate: your driver sends `IDENTIFY`, and Zhiting's bitstream answers.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Layering from the spec** (`host-driver-spec.md` §2):

  ```text
  crossbar.py      public API: units, validation, register pairing, chunking
  backends/        FpgaBackend | SimBackend, same interface
  transport.py     serial framing, timeouts, retry (FPGA only)
  codec.py         pure functions, bytes in / bytes out, no I/O
  ```

- **What exists today:** `sw/fecim/protocol.py` (`build_packet`, `crc8`, `PacketParser`, `parse_identify_response`, `parse_read_argmax_response`, `parse_get_config_response`), `sw/fecim/codec.py` (`decode_response_frame`, `decode_status_register`), `sw/fecim/transport.py` (`LoopbackTransport`, `SerialTransport`), `sw/fecim/drivers/base.py` (`BaseCrossbarDriver`, `LoopbackDriver`, `SerialCrossbarDriver`).
- **New:** `sw/fecim/backends/base.py` (the `Backend` protocol), `sw/fecim/backends/fpga.py` (`FpgaBackend`), `sw/fecim/errors.py` (exception tree), and the `Crossbar` class in `sw/fecim/crossbar.py`.
- **Tests:** `sw/tests/`, using a fake transport that plays the board's side.
- **Specs:** `05-lane-d-host/host-driver-spec.md` §3–6; `01-contract/protocol.md` (all of it; it wins over everything else).

## 3. How to build it

**Frames** (protocol §3). Request: `[A5][CMD][LEN lo][LEN hi][PAYLOAD][CRC8]`. Response: `[5A][STATUS][LEN lo][LEN hi][PAYLOAD][CRC8]`. The CRC covers everything except the sync byte.

**The backend interface** (spec §5), one method per command:

```python
class Backend(Protocol):
    def identify(self) -> DeviceInfo: ...
    def set_config(self, reg: int, value: int) -> None: ...
    def get_config(self, reg: int) -> int: ...
    def write_weights(self, addr: int, data: bytes) -> None: ...       # one chunk
    def write_activations(self, addr: int, data: bytes) -> None: ...
    def write_atten(self, addr: int, data: bytes) -> None: ...
    def compute(self) -> None: ...                                     # blocks until done
    def read_results(self, start: int, count: int) -> np.ndarray: ...  # int32
    def read_argmax(self) -> ArgmaxResult: ...                         # index, value, second
```

**One transaction, with retry** (spec §4.3):

```python
def _transact(self, cmd, payload=b""):
    for attempt in range(3):
        try:
            self.port.write(build_packet(cmd, payload))
            head = self._read_exact(4)                       # sync, status, len lo, len hi
            n = struct.unpack("<H", head[2:4])[0]
            body = self._read_exact(n + 1)                   # payload + CRC
            status, resp = decode_response_frame(head + body)
            if status != ST_OK:
                raise status_to_exception(status)            # BoardError subclasses: no retry
            return resp
        except (CrcError, FramingError, SerialTimeout):
            self.port.reset_input_buffer()
            time.sleep(0.1)                                  # protocol §7: required
    raise TransportError(f"command 0x{cmd:02x} failed after 3 attempts")
```

**Connect sequence** (spec §4.4): open at 115200; `IDENTIFY`; check magic `0xFEC1` and protocol version 2 (raise `VersionMismatch`); store lanes, rows, columns; compute `ACC_USED_W`; write `BAUD_INC = 19327`; reopen at 921600; `IDENTIFY` again.

**Decoding:** results are `struct.unpack("<%di" % count, payload)`; argmax is `struct.unpack("<Hii", payload)`.

**Chunking belongs in `Crossbar`, above the backend,** so both backends get identical calls. A full tile is 16,384 weights, sent column-major (`addr = col × 128 + row`) in chunks of **256 data bytes**:

```python
def load_weights_raw(self, W):                 # W: int8, shape (rows, cols)
    flat = np.zeros((128, 128), np.int8); flat[:W.shape[0], :W.shape[1]] = W
    data = flat.T.tobytes()                    # column-major
    for off in range(0, len(data), 256):
        self._backend.write_weights(off, data[off:off + 256])
```

**After each `compute()`,** read `STATUS` and check `result_seq` advanced by exactly one (spec §4.5); raise `SequenceError` otherwise.

## 4. How you know it's done

- Every command in protocol §4 has a backend method and a test: `IDENTIFY`, `SET_CONFIG`, `GET_CONFIG`, `WRITE_WEIGHTS`, `WRITE_ACT`, `WRITE_ATTEN`, `COMPUTE`, `READ_RESULT`, `READ_ARGMAX`.
- Each status code raises its own exception: `0x02` `BadLengthError`, `0x03` `UnknownCommandError`, `0x04` `BusyError`, `0x05` `AddressRangeError`.
- A corrupted reply is retried after 100 ms and succeeds; three failures raise `TransportError`.
- A full 128×128 weight load goes out as 64 chunks and is timed on the board (about 0.2 s at 921600).
- Works with a Windows `COM` port name and with `/dev/ttyUSB*`.
- Live at the Thu 19 meeting: `IDENTIFY` prints magic, version, build ID and geometry from the board.

## 5. Watch out for

- **Chunk size is 256 data bytes** (protocol §4.1), not `MAX_PAYLOAD` (512). The planning board said 512; the protocol is right.
- **The spec calls the board backend `"fpga"`.** The planning board said `"serial"`. Use `Crossbar(backend="fpga", port=...)` so code and spec agree.
- **`result_seq` reads 0 until Megan's B6 merges** (Zhiting's `config_regs` hard-codes it today). Make the sequence check switchable, default on, and turn it off only while testing against a pre-B6 bitstream.
- **The baud switch.** The reply to `SET_CONFIG(BAUD_INC)` may arrive at the old or the new rate; Zhiting decides the rule in A2. Until it's settled: send the command, ignore a garbled reply, reopen at the new rate and confirm with `IDENTIFY`.
- **`SerialTransport`'s default timeout is 0.1 s.** The spec wants 0.5 s between bytes, and it must be longer than the board's own 100 ms parser timeout.
- **Write-time settings need a weight reload.** Quantization, D2D and stuck-at are applied as weights are written, so changing them (or the seed) afterwards has no effect until weights are loaded again. Make `Crossbar` remember the last loaded matrix and either reload automatically or warn.
- Decide what happens to `sw/fecim/drivers/`. Simplest: keep `LoopbackTransport` for tests, move the logic into `backends/`, delete `drivers/` and update the tests that import it.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

