# AI prompt — D2: Full command set in the driver

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **D2 — Full command set in the driver**, owned by Natalie Poche, due Thu 19 Nov.

Build out the host driver so that every command in the frozen protocol is implemented, tested and exposed through a backend interface that the `sim` backend can also implement.

Deliver: the exception tree; the `Backend` protocol; `FpgaBackend` with exact-length reads, timeouts, the mandatory 100 ms post-error wait, three-attempt retry, the connect sequence with version check and baud switch, and `result_seq` tracking; the raw (integer, register-level) part of the `Crossbar` class including column-major weight chunking; and tests that use a fake transport emulating the board, including a corrupted reply, each error status, and a dropped `COMPUTE` reply.

Build on the code that's already there (`protocol.py`, `codec.py`, `transport.py`) instead of rewriting it, and keep `fecim.protocol.build_packet` importable because the co-simulation uses it. Follow `protocol.md` wherever it differs from the driver spec or the existing code, and list every such difference. Editable files: everything under `sw/`. You can't test against hardware; say which behaviours the owner must confirm on the board.

## Where the work goes

- **Layering from the spec** (`host-driver-spec.md` §2):

  ```text
  crossbar.py      public API: units, validation, register pairing, chunking
  backends/        FpgaBackend | SimBackend, same interface
  transport.py     serial framing, timeouts, retry (FPGA only)
  codec.py         pure functions, bytes in / bytes out, no I/O
  ```

- **What exists today:** `sw/fecim/protocol.py` (`build_packet`, `crc8`, `PacketParser`, `parse_identify_response`, `parse_read_argmax_response`, `parse_get_config_response`), `sw/fecim/codec.py` (`decode_response_frame`, `decode_status_register`), `sw/fecim/transport.py` (`LoopbackTransport`, `SerialTransport`), `sw/fecim/drivers/base.py` (`BaseCrossbarDriver`, `LoopbackDriver`, `SerialCrossbarDriver`).
- **New:** `sw/fecim/backends/base.py` (the `Backend` protocol), `sw/fecim/backends/fpga.py` (`FpgaBackend`), `sw/fecim/errors.py` (exception tree), and the `Crossbar` class in `sw/fecim/crossbar.py`.
- **Tests:** `sw/tests/`, using a fake transport that plays the board's side.
- **Specs:** `05-lane-d-host/host-driver-spec.md` §3–6; `01-contract/protocol.md` (all of it; it wins over everything else).

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

**Frames** (protocol §3). Request: `[A5][CMD][LEN lo][LEN hi][PAYLOAD][CRC8]`. Response: `[5A][STATUS][LEN lo][LEN hi][PAYLOAD][CRC8]`. The CRC covers everything except the sync byte.

**The backend interface** (spec §5), one method per command:

```python
class Backend(Protocol):
    def identify(self) -> DeviceInfo: ...
    def set_config(self, reg: int, value: int) -> None: ...
    def get_config(self, reg: int) -> int: ...
    def write_weights(self, addr: int, data: bytes) -> None: ...       # one chunk
    def write_activations(self, addr: int, data: bytes) -> None: ...
    def write_atten(self, addr: int, data: bytes) -> None: ...
    def compute(self) -> None: ...                                     # blocks until done
    def read_results(self, start: int, count: int) -> np.ndarray: ...  # int32
    def read_argmax(self) -> ArgmaxResult: ...                         # index, value, second
```

**One transaction, with retry** (spec §4.3):

```python
def _transact(self, cmd, payload=b""):
    for attempt in range(3):
        try:
            self.port.write(build_packet(cmd, payload))
            head = self._read_exact(4)                       # sync, status, len lo, len hi
            n = struct.unpack("<H", head[2:4])[0]
            body = self._read_exact(n + 1)                   # payload + CRC
            status, resp = decode_response_frame(head + body)
            if status != ST_OK:
                raise status_to_exception(status)            # BoardError subclasses: no retry
            return resp
        except (CrcError, FramingError, SerialTimeout):
            self.port.reset_input_buffer()
            time.sleep(0.1)                                  # protocol §7: required
    raise TransportError(f"command 0x{cmd:02x} failed after 3 attempts")
```

**Connect sequence** (spec §4.4): open at 115200; `IDENTIFY`; check magic `0xFEC1` and protocol version 2 (raise `VersionMismatch`); store lanes, rows, columns; compute `ACC_USED_W`; write `BAUD_INC = 19327`; reopen at 921600; `IDENTIFY` again.

**Decoding:** results are `struct.unpack("<%di" % count, payload)`; argmax is `struct.unpack("<Hii", payload)`.

**Chunking belongs in `Crossbar`, above the backend,** so both backends get identical calls. A full tile is 16,384 weights, sent column-major (`addr = col × 128 + row`) in chunks of **256 data bytes**:

```python
def load_weights_raw(self, W):                 # W: int8, shape (rows, cols)
    flat = np.zeros((128, 128), np.int8); flat[:W.shape[0], :W.shape[1]] = W
    data = flat.T.tobytes()                    # column-major
    for off in range(0, len(data), 256):
        self._backend.write_weights(off, data[off:off + 256])
```

**After each `compute()`,** read `STATUS` and check `result_seq` advanced by exactly one (spec §4.5); raise `SequenceError` otherwise.

## Acceptance checks

- Every command in protocol §4 has a backend method and a test: `IDENTIFY`, `SET_CONFIG`, `GET_CONFIG`, `WRITE_WEIGHTS`, `WRITE_ACT`, `WRITE_ATTEN`, `COMPUTE`, `READ_RESULT`, `READ_ARGMAX`.
- Each status code raises its own exception: `0x02` `BadLengthError`, `0x03` `UnknownCommandError`, `0x04` `BusyError`, `0x05` `AddressRangeError`.
- A corrupted reply is retried after 100 ms and succeeds; three failures raise `TransportError`.
- A full 128×128 weight load goes out as 64 chunks and is timed on the board (about 0.2 s at 921600).
- Works with a Windows `COM` port name and with `/dev/ttyUSB*`.
- Live at the Thu 19 meeting: `IDENTIFY` prints magic, version, build ID and geometry from the board.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Chunk size is 256 data bytes** (protocol §4.1), not `MAX_PAYLOAD` (512). The planning board said 512; the protocol is right.
- **The spec calls the board backend `"fpga"`.** The planning board said `"serial"`. Use `Crossbar(backend="fpga", port=...)` so code and spec agree.
- **`result_seq` reads 0 until Megan's B6 merges** (Zhiting's `config_regs` hard-codes it today). Make the sequence check switchable, default on, and turn it off only while testing against a pre-B6 bitstream.
- **The baud switch.** The reply to `SET_CONFIG(BAUD_INC)` may arrive at the old or the new rate; Zhiting decides the rule in A2. Until it's settled: send the command, ignore a garbled reply, reopen at the new rate and confirm with `IDENTIFY`.
- **`SerialTransport`'s default timeout is 0.1 s.** The spec wants 0.5 s between bytes, and it must be longer than the board's own 100 ms parser timeout.
- **Write-time settings need a weight reload.** Quantization, D2D and stuck-at are applied as weights are written, so changing them (or the seed) afterwards has no effect until weights are loaded again. Make `Crossbar` remember the last loaded matrix and either reload automatically or warn.
- Decide what happens to `sw/fecim/drivers/`. Simplest: keep `LoopbackTransport` for tests, move the logic into `backends/`, delete `drivers/` and update the tests that import it.

## Files to read first (attach or paste these if you're using a chatbot)

- `sw/fecim/` (all files), `sw/tests/` (all files), `sw/examples/demo_loopback.py`, `sw/examples/demo_dongle_loopback.py`
- `docs/plans and specs/01-contract/protocol.md`
- `docs/plans and specs/05-lane-d-host/host-driver-spec.md`
- `docs/plans and specs/03-lane-b-array/result-buffer-spec.md` (§4, §6)
- `tb/golden/packet_vectors.bin.hex`, `tb/golden/gen_packet_vectors.py`

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

