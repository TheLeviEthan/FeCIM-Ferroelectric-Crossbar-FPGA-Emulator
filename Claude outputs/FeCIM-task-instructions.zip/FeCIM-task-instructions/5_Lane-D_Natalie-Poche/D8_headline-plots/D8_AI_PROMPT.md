# AI prompt — D8: Headline plots: calibrated baseline and degradation sweeps on hardware

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **D8 — Headline plots: calibrated baseline and degradation sweeps on hardware**, owned by Natalie Poche, due Sat 28 Nov.

Produce the project's headline results: a script that defines and runs the degradation sweeps (one non-ideality at a time, plus a calibrated baseline) through the existing sweep harness on either backend, and a separate plotting script that turns the committed result files into slide-ready figures.

The plotting script reads only CSV and JSON files, so anyone can regenerate every figure without hardware. Each figure shows the median across seeds with an inter-seed band, the float reference, the hardware and `sim` curves overlaid, and the parameter-set-A marker only on axes where that set actually reports a value. Add decision-margin panels and a per-class chart for low ADC resolution.

Take axis ranges and marker values from the calibration document and the parameter-set file; don't invent device values. If you're given result files, also write three or four plain-language observations per plot, each one supported by specific numbers from the data. Editable files: `sw/examples/run_headline_sweeps.py` (new), `sw/examples/make_plots.py` (new), files under `results/` and `docs/img/plots/`.

## Where the work goes

- **New script:** `sw/examples/make_plots.py`, which reads result CSVs and their JSON sidecars from `results/` and writes PNGs to `docs/img/plots/`. It never talks to a board.
- **Sweep definitions:** `sw/examples/run_headline_sweeps.py`, calling `sweep.run` (D5) for each axis.
- **Data:** `results/*.csv` and `results/*.json`, committed.
- **Specs:** `05-lane-d-host/application-spec.md` §4, §5; `06-physics-calibration/device-model.md` §6 (swept parameters).

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

**Sweeps to run** (linear classifier first, then the MLP; 5 or more seeds each):

| Plot | Axis | Values | Enabled | Set A marker |
|---|---|---|---|---|
| Levels | `QUANT_LEVELS` | 2, 3, 4, 5, 6, 8, 12, 16, 32 | quant | N = 8 |
| D2D | σ in LSB | 0 to 30 | d2d | 7.4 LSB |
| Stuck-at | fault rate | 0 to 10 %, both modes | stuck | none (swept) |
| Read noise | σ in LSB | 0 to 20 | read | none (swept; mark the 1.7 LSB reference if C6 adopts it) |
| IR drop | κ | 0 to 0.5 | ir | none (design choice) |
| ADC | bits | 4 to 12 | adc | none (design choice) |
| Calibrated baseline | — | float · ideal · set A (quant + d2d) | — | — |

**Order of work:**

1. Run every sweep on `backend="sim"` by Tue 24 and agree the axes and ranges with Ethan.
2. Run them on the board from Wed 25. Long multi-seed runs can go overnight; the harness resumes if interrupted.
3. Generate the plots from committed files only.

```python
def plot_axis(csv_sim, csv_hw, marker=None):
    for name, df, style in (("sim", sim, "--"), ("hardware", hw, "o-")):
        g = df.groupby("value")["accuracy"]
        plt.plot(g.median().index, g.median(), style, label=name)
        plt.fill_between(g.median().index, g.min(), g.max(), alpha=0.2)     # inter-seed band
    if marker: plt.axvline(marker, linestyle=":", label="parameter set A")
    plt.axhline(float_accuracy, color="gray", label="float reference")
```

Plot the median with a band across seeds, not a single trace. Make a second panel (or twin axis) for decision margin, and one per-class bar chart at 4-bit ADC to show the tie bias.

A rough time budget on the board with `READ_ARGMAX`: about 100 bytes and three transactions per image. A 360-image test set is well under a second of wire time per point, but USB-serial adapters add a delay to every transaction, so the real figure is seconds to tens of seconds. Measure one point first, then size the overnight runs from that.

## Acceptance checks

- Every plot is generated by `make_plots.py` from CSV and JSON files that are committed, and each PNG's sidecar names the commit, bitstream and seeds.
- Hardware and `sim` curves coincide exactly at every point (identical CSV values for the same seeds).
- Each curve has an inter-seed band, the float reference, and the set-A marker where one applies.
- Margin plots exist for at least read noise and D2D; the per-class chart exists for low ADC resolution.
- Linear and MLP versions exist for the main axes.
- PNGs are exported at slide resolution and handed to P2.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **The ideal reference is "all enables off", not an extreme axis value.** N = 255 levels shifts every weight by one, coefficient 255 scales by 255/256, and so on. Draw the reference line from a noise-free run.
- **Don't put a set-A marker on an axis the paper doesn't report.** Read noise, stuck rate, IR and ADC are swept or are design choices (C6). A marker there would claim more than we know.
- **If hardware and `sim` curves differ at any point,** stop and run C8 on that configuration. Don't average it away or widen the band.
- The read-noise axis in LSB tops out at about 36.8 (register 255). The D2D axis tops out at about 104.
- Use colours and line styles that survive a projector and greyscale printing; label axes in physical units (LSB, and mV where it applies) as well as register values.
- Leave the board somewhere it won't be bumped during overnight runs, and check the identify block's error counters afterwards.

## Files to read first (attach or paste these if you're using a chatbot)

- `sw/fecim/sweep.py`, `sw/fecim/crossbar.py`, `sw/fecim/networks.py`, `sw/fecim/calibration.py`
- `sw/fecim/parameter_sets/dualport_fefet_mlc.yaml`
- `docs/plans and specs/06-physics-calibration/device-model.md` (with C6's additions)
- `docs/plans and specs/05-lane-d-host/application-spec.md` (§4, §5)
- `results/l3/summary.md` (C9) and any result CSV/JSON files that exist

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

