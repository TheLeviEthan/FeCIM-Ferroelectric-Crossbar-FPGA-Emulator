# D3 — Sim backend: Crossbar(backend="sim")

| | |
|---|---|
| **Owner** | Natalie Poche |
| **Due** | Sat 21 Nov |
| **Board bucket** | Bucket 5 — Lane D |
| **Board task** | D3: Sim backend — `Crossbar(backend="sim")` |
| **Needs first** | D2 (the `Backend` interface), C2 (all six effects in the model); C3 for the register-level path |
| **Unblocks** | D5, D6, D7, D8, C8, C9 |
| **AI version** | `D3_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

We have two boards and four people, and one week of the schedule is a holiday when the boards are in two houses. If every experiment needed a board, most of the team would be stuck most of the time.

The `sim` backend removes that bottleneck. It makes the C++ model look exactly like a board to your Python code: same class, same methods, same register numbers. The digit classifier, the sweep harness and the plots can all be built and debugged on a laptop, then pointed at the real board by changing one word.

There's a rule that makes this trustworthy: the `sim` backend must be the *same* C++ model the hardware was verified against, never a separate Python re-implementation. A Python copy would drift from the RTL in some corner, and then "sim and board disagree" would have three suspects instead of two. Because both backends are bit-exact, a sweep run on `sim` and the same sweep run on the board must give identical numbers. That comparison is itself a result we show.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **New:** `sw/fecim/backends/sim.py` (`SimBackend`, implementing the `Backend` protocol from D2).
- **Route A, pybind11 (the spec's plan):** a small binding file, for example `sw/src/bindings.cpp`, wrapping `fecim::ModelExact`, built as an extension module `fecim._model`. Needs a build backend change in `sw/pyproject.toml` (`scikit-build-core` + `pybind11`).
- **Route B, subprocess (the fallback):** a small C++ program `model/examples/fecim_cli.cpp` (Ethan adds it next to `fecim_demo` in `model/CMakeLists.txt`) that reads commands on stdin and prints results on stdout. `SimBackend` starts it once and keeps the pipe open.
- **Model API it calls:** `model/include/fecim/model_exact.h` — `set_reg` / `get_reg`, `write_weight`, `write_activation`, `write_atten`, `compute` (or `start_compute` + `step`), `results`, `argmax`, `cycle_count`.
- **Factory:** `Crossbar(backend="sim")` picks it; `sw/fecim/drivers/factory.py` shows the existing pattern.
- **Spec:** `05-lane-d-host/host-driver-spec.md` §1.1, §5, §7.3.

## 3. How to build it

`SimBackend` is a thin adapter. Each method does what the board would do with the same packet:

```python
class SimBackend:
    def identify(self):                 # same geometry the board reports; no link errors
        return DeviceInfo(magic=0xFEC1, proto=2, build_id=..., lanes=64, rows=128, cols=128)
    def set_config(self, reg, value):   self._check(self._m.set_reg(reg, value))
    def get_config(self, reg):          return self._m.get_reg(reg)
    def write_weights(self, addr, data):
        for i, b in enumerate(data):    # addr = col * 128 + row, column-major
            a = addr + i
            self._m.write_weight(a % 128, a // 128, to_int8(b))
    def write_activations(self, addr, data): ...   # write_activation(row, value)
    def write_atten(self, addr, data): ...         # write_atten(row, coeff)
    def compute(self):                  self._m.compute()
    def read_results(self, start, count): return np.array(self._m.results()[start:start + count], np.int32)
    def read_argmax(self):              return ArgmaxResult(*self._m.argmax())
```

`_check` turns a non-OK status into the same exception the FPGA backend raises.

**Route B's line protocol**, if you need it (one command per line, hex payloads):

```text
R <reg> <value>          set register        -> "OK" or "ERR <status>"
G <reg>                  get register        -> "<value>"
W <addr> <hexbytes>      weights             -> "OK"
A <addr> <hexbytes>      activations         -> "OK"
T <addr> <hexbytes>      attenuation         -> "OK"
C                        compute             -> "OK <cycle_count>"
RR <start> <count>       results             -> "<int> <int> ..."
AM                       argmax              -> "<idx> <val> <second>"
```

**Decision rule:** if `import fecim._model` isn't working on your Windows machine and in CI by end of day Thu 19, switch to Route B. It's less elegant and it's just as bit-exact, because it's the same C++ code.

**Cross-check test:** drive the same sequence of raw calls into `SimBackend` and into a recording fake of the FPGA backend, and assert the *calls* are identical. Then, once a board computes, C8 compares the *numbers*.

## 4. How you know it's done

- `Crossbar(backend="sim")` and `Crossbar(backend="fpga", ...)` expose the same methods, and application code runs on either without an `if`.
- Register semantics match the board: reset defaults, read-only and reserved registers raise `AddressRangeError`, `CTRL[2]` reseeds, `STATUS` and `CYCLE_CNT` read sensibly.
- All six non-idealities work through the backend, alone and together.
- A full pass over the 1,797 `load_digits` images is timed and the figure recorded (it sets how big sweeps can be).
- `import fecim` still works on a machine where the model isn't built, with a clear error only when `backend="sim"` is requested.
- CI builds whichever route you chose and runs the `sim` tests.

## 5. Watch out for

- **`set_reg` / `get_reg` come from Ethan's C3 (due Fri 20).** Before that, the model only has the typed `set_config(Config)` plus `compute()`. Write the adapter against the register-level interface, and if you need to start earlier, keep a small private shim that maps register writes onto a `Config` struct.
- **No Python arithmetic for device effects.** If you find yourself computing a quantized weight or a noise sample in Python "to save a call", stop; that's the drift the rule exists to prevent.
- **A `sim` cycle count is a modelled number, not a measured time.** Report it as cycles, and don't present it as wall-clock latency.
- pybind11 on Windows needs the MSVC build tools. That's the one friction point the spec warns about; document it in the README if you ship Route A.
- Seed 0 is valid and isn't remapped on either backend.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

