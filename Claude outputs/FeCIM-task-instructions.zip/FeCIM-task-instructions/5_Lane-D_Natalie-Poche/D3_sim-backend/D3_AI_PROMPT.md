# AI prompt — D3: Sim backend: Crossbar(backend="sim")

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **D3 — Sim backend: Crossbar(backend="sim")**, owned by Natalie Poche, due Sat 21 Nov.

Implement `SimBackend`, the host backend that runs the bit-exact C++ model behind the same `Backend` interface as the FPGA backend, and wire it into `Crossbar(backend="sim")`.

Provide the pybind11 binding and build configuration as the primary route, and also the subprocess route (a small stdin/stdout C++ CLI plus the Python side) as a fallback the owner can switch to if the extension build is troublesome on Windows; keep both behind the same class so nothing above the backend changes. All device arithmetic must stay in C++: the Python side only moves bytes and integers.

Write the adapter against the model's API as declared in `model_exact.h`, note which members are still stubs in the `.cpp` you're given, and say what the adapter does about each. The C++ CLI lives under `model/` (Lane C): provide it as a proposed file for that lane's owner to review. Editable files: everything under `sw/`; proposed new file `model/examples/fecim_cli.cpp` and its `CMakeLists.txt` entry.

## Where the work goes

- **New:** `sw/fecim/backends/sim.py` (`SimBackend`, implementing the `Backend` protocol from D2).
- **Route A, pybind11 (the spec's plan):** a small binding file, for example `sw/src/bindings.cpp`, wrapping `fecim::ModelExact`, built as an extension module `fecim._model`. Needs a build backend change in `sw/pyproject.toml` (`scikit-build-core` + `pybind11`).
- **Route B, subprocess (the fallback):** a small C++ program `model/examples/fecim_cli.cpp` (Ethan adds it next to `fecim_demo` in `model/CMakeLists.txt`) that reads commands on stdin and prints results on stdout. `SimBackend` starts it once and keeps the pipe open.
- **Model API it calls:** `model/include/fecim/model_exact.h` — `set_reg` / `get_reg`, `write_weight`, `write_activation`, `write_atten`, `compute` (or `start_compute` + `step`), `results`, `argmax`, `cycle_count`.
- **Factory:** `Crossbar(backend="sim")` picks it; `sw/fecim/drivers/factory.py` shows the existing pattern.
- **Spec:** `05-lane-d-host/host-driver-spec.md` §1.1, §5, §7.3.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

`SimBackend` is a thin adapter. Each method does what the board would do with the same packet:

```python
class SimBackend:
    def identify(self):                 # same geometry the board reports; no link errors
        return DeviceInfo(magic=0xFEC1, proto=2, build_id=..., lanes=64, rows=128, cols=128)
    def set_config(self, reg, value):   self._check(self._m.set_reg(reg, value))
    def get_config(self, reg):          return self._m.get_reg(reg)
    def write_weights(self, addr, data):
        for i, b in enumerate(data):    # addr = col * 128 + row, column-major
            a = addr + i
            self._m.write_weight(a % 128, a // 128, to_int8(b))
    def write_activations(self, addr, data): ...   # write_activation(row, value)
    def write_atten(self, addr, data): ...         # write_atten(row, coeff)
    def compute(self):                  self._m.compute()
    def read_results(self, start, count): return np.array(self._m.results()[start:start + count], np.int32)
    def read_argmax(self):              return ArgmaxResult(*self._m.argmax())
```

`_check` turns a non-OK status into the same exception the FPGA backend raises.

**Route B's line protocol**, if you need it (one command per line, hex payloads):

```text
R <reg> <value>          set register        -> "OK" or "ERR <status>"
G <reg>                  get register        -> "<value>"
W <addr> <hexbytes>      weights             -> "OK"
A <addr> <hexbytes>      activations         -> "OK"
T <addr> <hexbytes>      attenuation         -> "OK"
C                        compute             -> "OK <cycle_count>"
RR <start> <count>       results             -> "<int> <int> ..."
AM                       argmax              -> "<idx> <val> <second>"
```

**Decision rule:** if `import fecim._model` isn't working on your Windows machine and in CI by end of day Thu 19, switch to Route B. It's less elegant and it's just as bit-exact, because it's the same C++ code.

**Cross-check test:** drive the same sequence of raw calls into `SimBackend` and into a recording fake of the FPGA backend, and assert the *calls* are identical. Then, once a board computes, C8 compares the *numbers*.

## Acceptance checks

- `Crossbar(backend="sim")` and `Crossbar(backend="fpga", ...)` expose the same methods, and application code runs on either without an `if`.
- Register semantics match the board: reset defaults, read-only and reserved registers raise `AddressRangeError`, `CTRL[2]` reseeds, `STATUS` and `CYCLE_CNT` read sensibly.
- All six non-idealities work through the backend, alone and together.
- A full pass over the 1,797 `load_digits` images is timed and the figure recorded (it sets how big sweeps can be).
- `import fecim` still works on a machine where the model isn't built, with a clear error only when `backend="sim"` is requested.
- CI builds whichever route you chose and runs the `sim` tests.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **`set_reg` / `get_reg` come from Ethan's C3 (due Fri 20).** Before that, the model only has the typed `set_config(Config)` plus `compute()`. Write the adapter against the register-level interface, and if you need to start earlier, keep a small private shim that maps register writes onto a `Config` struct.
- **No Python arithmetic for device effects.** If you find yourself computing a quantized weight or a noise sample in Python "to save a call", stop; that's the drift the rule exists to prevent.
- **A `sim` cycle count is a modelled number, not a measured time.** Report it as cycles, and don't present it as wall-clock latency.
- pybind11 on Windows needs the MSVC build tools. That's the one friction point the spec warns about; document it in the README if you ship Route A.
- Seed 0 is valid and isn't remapped on either backend.

## Files to read first (attach or paste these if you're using a chatbot)

- `sw/fecim/backends/base.py`, `sw/fecim/backends/fpga.py`, `sw/fecim/crossbar.py`, `sw/fecim/errors.py` (from D2)
- `sw/pyproject.toml`, `sw/fecim/drivers/factory.py`
- `model/include/fecim/model_exact.h`, `model/include/fecim/params.h`, `model/src/model_exact.cpp`
- `model/CMakeLists.txt`, `model/examples/demo_mvm.cpp`
- `docs/plans and specs/05-lane-d-host/host-driver-spec.md` (§1, §5, §7)
- `docs/plans and specs/01-contract/protocol.md` (§4–6)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

