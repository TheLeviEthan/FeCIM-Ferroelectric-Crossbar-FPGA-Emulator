# AI prompt — D5: Sweep harness with provenance

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **D5 — Sweep harness with provenance**, owned by Natalie Poche, due Mon 23 Nov.

Rewrite the sweep harness to the interface in `application-spec.md` §4: one or two axes, several seeds per point, per-class accuracy and decision margin recorded for every point, a provenance JSON sidecar written alongside a CSV, and resumability after interruption.

The harness must run unchanged on either backend. Be careful about when weights are reloaded: write-time non-idealities and the seed take effect only when weights are written, so make the reload rule explicit in code and comments. Reseed between sweep points and never within one, and explain why in a comment.

Keep `matplotlib` out of this module (plots are a separate optional layer). Editable files: `sw/fecim/sweep.py`, `sw/tests/test_sweep.py` (new), and small additions to `sw/fecim/crossbar.py` if the harness needs a read-back of the full register config for provenance.

## Where the work goes

- **Rewrite:** `sw/fecim/sweep.py`. It has a `SweepHarness` class with `run_sweep` and `_save_provenance` as scaffolding.
- **Target interface** (`application-spec.md` §4.1): `sweep.run(xbar, network=..., dataset=..., axis=sweep.Axis(name, values), enable=[...], seeds=[...], parameter_set=...)`.
- **Output:** `results/<sweep-name>.csv` plus `results/<sweep-name>.json` (same stem). The `results/` folder exists and is empty apart from `.gitkeep`.
- **Tests:** `sw/tests/test_sweep.py`, on the `sim` backend.
- **Spec:** `05-lane-d-host/application-spec.md` §4 and §6 tests 7–9.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```python
def run(xbar, network, dataset, axis, enable, seeds, parameter_set=None,
        full_results=False, out="results/sweep", resume=True):
    meta = provenance(xbar, enable, seeds, parameter_set, dataset)   # written FIRST
    rows = load_existing(out) if resume else []
    for value in axis.values:
        for seed in seeds:
            if (value, seed) in done(rows): continue                 # resumable
            if parameter_set: xbar.load_parameter_set(parameter_set)
            axis.apply(xbar, value)                                  # e.g. set_read_noise(sigma_lsb=value)
            xbar.enable(enable)
            xbar.seed(seed)                                          # ONE seed for the whole point
            network.load(xbar)                                       # reload: write-time effects use
                                                                     #   the config and the seed
            correct = np.zeros(n_classes, int); total = np.zeros(n_classes, int); margins = []
            for x, label in dataset:
                r = network.classify(xbar, x)                        # READ_ARGMAX path
                total[label] += 1; correct[label] += (r.index == label)
                margins.append(r.value - r.second)
            rows.append(point_row(axis.name, value, seed, correct, total, margins))
            save(out, rows, meta)                                    # after every point
    return rows
```

**Provenance sidecar** (`application-spec.md` §4.5): git commit, `rtl_build_id`, the identify block, backend, parameter set, the full register config, the enable list by name, seeds, dataset name and size, timestamp.

**CSV columns:** axis name, axis value, seed, overall accuracy, one accuracy column per class, mean margin, median margin.

Reseed **between** points, never within one. Holding the seed across all images at a point models one physical chip classifying many inputs. A new seed per image would model a new chip per inference, which isn't a physical situation and averages away the effect we're trying to measure.

## Acceptance checks

- The same sweep definition runs on `backend="sim"` and `backend="fpga"` with no code change.
- Reproducibility: the same sweep run twice gives identical CSVs; changing a seed changes them.
- Interrupting a sweep and restarting it continues from the last finished point and yields the same file as an uninterrupted run.
- Every provenance field in spec §4.5 is present and non-empty.
- Per-class accuracy and margin are in every row.
- A short sweep (5 points × 3 seeds on `sim`) runs in CI.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Reload weights whenever a write-time setting or the seed changes.** Quantization, D2D and stuck-at are baked in when weights are written. If the harness changes `D2D_SIGMA` and doesn't reload, the curve is flat and looks like "D2D has no effect". Read-time axes (read noise, IR, ADC) don't need a reload, but reloading at every point is simpler and always correct; on the board it costs about 0.2 s per point.
- **The existing `run_sweep` uses lists as default arguments** (`enable_noise=[...]`, `seeds=[...]`). In Python a default list is shared between calls. Use `None` and fill in the default inside.
- **Its default `parameter_set="gf28_hkmg"`** is set B. Make the parameter explicit; don't default to a device.
- **"No quantization" is the enable bit off, not `levels = 255`.** N = 255 shifts every weight by one. On a levels axis, plot the ideal reference from a run with `quant` disabled.
- Record the git commit with a "dirty" flag if there are uncommitted changes, so a plot made from uncommitted code is recognizable.
- At low ADC resolution, expect accuracy to skew toward class 0. That's the tie rule (lowest index wins) and it's a real finding; the per-class columns are how you show it.

## Files to read first (attach or paste these if you're using a chatbot)

- `sw/fecim/sweep.py`, `sw/fecim/crossbar.py`, `sw/fecim/mapping.py`, `sw/fecim/backends/`
- `sw/fecim/calibration.py` (from D4)
- `docs/plans and specs/05-lane-d-host/application-spec.md` (§4, §5, §6)
- `docs/plans and specs/05-lane-d-host/host-driver-spec.md` (§6)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

