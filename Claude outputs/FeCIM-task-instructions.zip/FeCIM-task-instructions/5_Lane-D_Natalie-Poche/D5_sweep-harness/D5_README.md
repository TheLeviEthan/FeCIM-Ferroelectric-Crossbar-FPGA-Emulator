# D5 — Sweep harness with provenance

| | |
|---|---|
| **Owner** | Natalie Poche |
| **Due** | Mon 23 Nov |
| **Board bucket** | Bucket 5 — Lane D |
| **Board task** | D5: Sweep harness with provenance |
| **Needs first** | D3 (runs on `sim` first), D4 |
| **Unblocks** | D8, C9 |
| **AI version** | `D5_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

The project's headline results are curves: classification accuracy on the vertical axis, and on the horizontal axis "how bad is this non-ideality". Each point on a curve means: configure the array, run a few hundred test images through it, count how many it got right. A full set of plots is hundreds of points and several hundred thousand inferences. That has to be automated.

The harness is the automation, and it's also where scientific care lives. Three habits are built into it. **Several seeds per point**, because one seed is one random draw, and presenting one draw as "the" accuracy is how you get a result that won't reproduce. **Per-class accuracy as well as the total**, because some effects (coarse ADC settings) quietly favour low-numbered classes, which the total hides. And **provenance**: every result file records the exact code version, bitstream, settings and seeds that produced it.

That last one matters most. A plot nobody can regenerate isn't evidence. A few weeks from now someone will ask why one curve has a bump, and the answer will be in the metadata or it'll be nowhere.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Rewrite:** `sw/fecim/sweep.py`. It has a `SweepHarness` class with `run_sweep` and `_save_provenance` as scaffolding.
- **Target interface** (`application-spec.md` §4.1): `sweep.run(xbar, network=..., dataset=..., axis=sweep.Axis(name, values), enable=[...], seeds=[...], parameter_set=...)`.
- **Output:** `results/<sweep-name>.csv` plus `results/<sweep-name>.json` (same stem). The `results/` folder exists and is empty apart from `.gitkeep`.
- **Tests:** `sw/tests/test_sweep.py`, on the `sim` backend.
- **Spec:** `05-lane-d-host/application-spec.md` §4 and §6 tests 7–9.

## 3. How to build it

```python
def run(xbar, network, dataset, axis, enable, seeds, parameter_set=None,
        full_results=False, out="results/sweep", resume=True):
    meta = provenance(xbar, enable, seeds, parameter_set, dataset)   # written FIRST
    rows = load_existing(out) if resume else []
    for value in axis.values:
        for seed in seeds:
            if (value, seed) in done(rows): continue                 # resumable
            if parameter_set: xbar.load_parameter_set(parameter_set)
            axis.apply(xbar, value)                                  # e.g. set_read_noise(sigma_lsb=value)
            xbar.enable(enable)
            xbar.seed(seed)                                          # ONE seed for the whole point
            network.load(xbar)                                       # reload: write-time effects use
                                                                     #   the config and the seed
            correct = np.zeros(n_classes, int); total = np.zeros(n_classes, int); margins = []
            for x, label in dataset:
                r = network.classify(xbar, x)                        # READ_ARGMAX path
                total[label] += 1; correct[label] += (r.index == label)
                margins.append(r.value - r.second)
            rows.append(point_row(axis.name, value, seed, correct, total, margins))
            save(out, rows, meta)                                    # after every point
    return rows
```

**Provenance sidecar** (`application-spec.md` §4.5): git commit, `rtl_build_id`, the identify block, backend, parameter set, the full register config, the enable list by name, seeds, dataset name and size, timestamp.

**CSV columns:** axis name, axis value, seed, overall accuracy, one accuracy column per class, mean margin, median margin.

Reseed **between** points, never within one. Holding the seed across all images at a point models one physical chip classifying many inputs. A new seed per image would model a new chip per inference, which isn't a physical situation and averages away the effect we're trying to measure.

## 4. How you know it's done

- The same sweep definition runs on `backend="sim"` and `backend="fpga"` with no code change.
- Reproducibility: the same sweep run twice gives identical CSVs; changing a seed changes them.
- Interrupting a sweep and restarting it continues from the last finished point and yields the same file as an uninterrupted run.
- Every provenance field in spec §4.5 is present and non-empty.
- Per-class accuracy and margin are in every row.
- A short sweep (5 points × 3 seeds on `sim`) runs in CI.

## 5. Watch out for

- **Reload weights whenever a write-time setting or the seed changes.** Quantization, D2D and stuck-at are baked in when weights are written. If the harness changes `D2D_SIGMA` and doesn't reload, the curve is flat and looks like "D2D has no effect". Read-time axes (read noise, IR, ADC) don't need a reload, but reloading at every point is simpler and always correct; on the board it costs about 0.2 s per point.
- **The existing `run_sweep` uses lists as default arguments** (`enable_noise=[...]`, `seeds=[...]`). In Python a default list is shared between calls. Use `None` and fill in the default inside.
- **Its default `parameter_set="gf28_hkmg"`** is set B. Make the parameter explicit; don't default to a device.
- **"No quantization" is the enable bit off, not `levels = 255`.** N = 255 shifts every weight by one. On a levels axis, plot the ideal reference from a run with `quant` disabled.
- Record the git commit with a "dirty" flag if there are uncommitted changes, so a plot made from uncommitted code is recognizable.
- At low ADC resolution, expect accuracy to skew toward class 0. That's the tie rule (lowest index wins) and it's a real finding; the per-class columns are how you show it.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

