# AI prompt — D6: Linear digits classifier (64 to 10): sim, then board

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **D6 — Linear digits classifier (64 to 10): sim, then board**, owned by Natalie Poche, due Wed 25 Nov.

Build the linear digit-classifier demo: train a 64-input, 10-class logistic-regression model on scikit-learn's `load_digits` with a fixed split and seed, map it onto the crossbar tile, run inference through the `Crossbar` API using the on-chip argmax, and report float, ideal-quantized, calibrated and hardware accuracy with per-class breakdowns. Include the mapping unit tests from `application-spec.md` §6.

Treat the weight mapping as the part most likely to be silently wrong. In particular, reason explicitly about whether the on-chip argmax of raw integer accumulators equals the argmax of the true scores under your chosen scaling and bias handling, state the conclusion, and add a test that compares `READ_ARGMAX` against a host-side argmax of descaled `READ_RESULT` values for every test image.

Check `sw/fecim/mapping.py` against the spec and report any differences before building on it. Editable files: `sw/examples/digits.py` (new), `sw/fecim/mapping.py`, `sw/fecim/networks.py` (new), `sw/tests/test_mapping.py` (new).

## Where the work goes

- **New script:** `sw/examples/digits.py` with `--backend sim|fpga` and `--port`.
- **Mapping code:** `sw/fecim/mapping.py` (`WeightMapper` has `map_weights`, `map_activations`, `compute_first_layer_offset`, `descale`). Check it against `application-spec.md` §2 as you go.
- **A small network wrapper,** for example `sw/fecim/networks.py`: `LinearNet.load(xbar)` and `LinearNet.classify(xbar, x)`, which the sweep harness (D5) calls.
- **Tests:** `sw/tests/test_mapping.py` (spec §6 tests 1–5).
- **Specs:** `05-lane-d-host/application-spec.md` §2, §3.1, §3.3, §6.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```python
from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

X, y = load_digits(return_X_y=True)                   # 1,797 images, 64 pixels each, values 0..16
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=0, stratify=y)
clf = LogisticRegression(max_iter=2000).fit(Xtr, ytr)  # coef_: (10, 64), intercept_: (10,)

# --- map onto the tile: rows = inputs, columns = outputs ---
tile = clf.coef_.T                                     # (64, 10): TRANSPOSE
s_w  = np.abs(tile).max() / 127.0                      # ONE scale for the whole matrix (see below)
Wq   = np.round(tile / s_w).astype(np.int8)
s_a  = 16.0 / 255.0                                    # pixels are 0..16, already non-negative
xq   = lambda x: np.round(x / s_a).astype(np.uint8)

# --- the bias as an extra, always-on input row ---
b_row = np.round(clf.intercept_ / (s_w * s_a * 255)).astype(np.int8)    # weight for row 64
Wq    = np.vstack([Wq, b_row])                         # (65, 10); activation for row 64 is 255

xbar.set_tile(rows=65, cols=10)
xbar.load_weights_raw(Wq)
def classify(x):
    xbar.write_activations_raw(np.append(xq(x), 255).astype(np.uint8))
    xbar.compute()
    return xbar.read_argmax()                          # index = predicted digit
```

Report four accuracies side by side, each with a per-class breakdown:

| Row | How it's computed |
|---|---|
| Float | `clf.score(Xte, yte)` |
| Quantized, ideal array | all `NOISE_EN` bits off |
| Set A | `load_parameter_set("dualport_fefet_mlc")`, `enable(["quant", "d2d"])` |
| Board | the same two configurations on `--backend fpga`; must equal the `sim` numbers exactly |

Before trusting any accuracy number, run the mapping tests: round trip, orientation with a deliberately asymmetric matrix, and "array with noise off matches float to within quantization error".

## Acceptance checks

- `python sw/examples/digits.py --backend sim` runs from a clean install and prints the table above with a fixed split and seed.
- With noise off, quantized accuracy is within about a percentage point of float.
- The on-chip `READ_ARGMAX` index equals the host-side argmax of `READ_RESULT` for every test image on the clean path.
- `--backend fpga` gives exactly the same predictions as `sim` for the same configuration and seed (cross-backend test).
- With `SW[1:0] = 10`, the board's display shows the predicted digit.
- Per-image time on the board is printed. A 30-second backup recording exists.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **On-chip argmax only sees raw integer sums.** `application-spec.md` recommends per-*column* weight scaling and a host-side bias, and also recommends `READ_ARGMAX` for sweeps. Those two don't combine: with a different scale per column, or a bias added afterwards, the largest raw accumulator isn't necessarily the largest true score. The sketch above avoids that with one scale for the whole matrix and the bias folded in as an extra input row. The cost is a little weight resolution, so compare float against quantized accuracy to confirm it's small. If you'd rather keep per-column scaling, you have to use `READ_RESULT` and do the descale and argmax on the host. Either way, write the choice into the spec.
- **Check the bias row fits in int8.** If `intercept / (s_w × s_a × 255)` exceeds ±127 for some class, give the bias row a smaller constant activation or split it across two rows.
- **Don't standardize the pixels** (subtracting a mean makes inputs signed, and then the first-layer offset correction of spec §2.4 is needed). Raw 0–16 pixels avoid the issue.
- **Transpose.** sklearn's `coef_` is (outputs, inputs); the tile is (rows = inputs, columns = outputs). A symmetric test matrix hides this bug, which is why the orientation test uses an asymmetric one.
- `active_cols = 10` means columns 10–63 still accumulate garbage on the board. `argmax_unit` masks them (A4); that mask is what this demo depends on.

## Files to read first (attach or paste these if you're using a chatbot)

- `sw/fecim/mapping.py`, `sw/fecim/crossbar.py`, `sw/fecim/backends/`, `sw/fecim/calibration.py`
- `sw/examples/demo_pipeline.py` (existing style)
- `docs/plans and specs/05-lane-d-host/application-spec.md` (§2, §3, §6)
- `docs/plans and specs/03-lane-b-array/result-buffer-spec.md` (§5)
- `docs/plans and specs/01-contract/protocol.md` (§4.6, §6.3b)

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

