# D6 — Linear digits classifier (64 to 10): sim, then board

| | |
|---|---|
| **Owner** | Natalie Poche |
| **Due** | Wed 25 Nov |
| **Board bucket** | Bucket 5 — Lane D |
| **Board task** | D6: Linear digits classifier (64→10) — sim, then board |
| **Needs first** | D3 (`sim` by Sun 22); D2, A5, A6, C8 for the board run |
| **Unblocks** | D7, D8, G4, the main demo |
| **AI version** | `D6_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Up to here the array multiplies random matrices and we check the arithmetic. That proves the machine works. It doesn't show that it's *useful*. This task runs a real, if small, machine-learning model on it: recognizing handwritten digits.

The model is the simplest classifier there is: one layer, 64 inputs (the pixels of an 8×8 image) and 10 outputs (one score per digit). The biggest score wins. That's exactly a matrix-vector multiply followed by an argmax, which is what our hardware does. Trained normally on a laptop it gets about 95 % right, which leaves plenty of room to *see* accuracy fall as we turn up each device non-ideality.

The interesting engineering is the translation. The trained model has real-valued weights and inputs. The array stores 8-bit signed weights and takes 8-bit unsigned inputs. Mapping one onto the other without changing the answer is where silent mistakes hide: a matrix the wrong way round, a scale applied per column that the on-chip argmax doesn't know about, a bias term the hardware doesn't have. Each gives numbers of the right shape and the wrong value.

This is the demo: a digit goes in from the laptop, and the board's display shows what it thinks the digit is.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **New script:** `sw/examples/digits.py` with `--backend sim|fpga` and `--port`.
- **Mapping code:** `sw/fecim/mapping.py` (`WeightMapper` has `map_weights`, `map_activations`, `compute_first_layer_offset`, `descale`). Check it against `application-spec.md` §2 as you go.
- **A small network wrapper,** for example `sw/fecim/networks.py`: `LinearNet.load(xbar)` and `LinearNet.classify(xbar, x)`, which the sweep harness (D5) calls.
- **Tests:** `sw/tests/test_mapping.py` (spec §6 tests 1–5).
- **Specs:** `05-lane-d-host/application-spec.md` §2, §3.1, §3.3, §6.

## 3. How to build it

```python
from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

X, y = load_digits(return_X_y=True)                   # 1,797 images, 64 pixels each, values 0..16
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=0, stratify=y)
clf = LogisticRegression(max_iter=2000).fit(Xtr, ytr)  # coef_: (10, 64), intercept_: (10,)

# --- map onto the tile: rows = inputs, columns = outputs ---
tile = clf.coef_.T                                     # (64, 10): TRANSPOSE
s_w  = np.abs(tile).max() / 127.0                      # ONE scale for the whole matrix (see below)
Wq   = np.round(tile / s_w).astype(np.int8)
s_a  = 16.0 / 255.0                                    # pixels are 0..16, already non-negative
xq   = lambda x: np.round(x / s_a).astype(np.uint8)

# --- the bias as an extra, always-on input row ---
b_row = np.round(clf.intercept_ / (s_w * s_a * 255)).astype(np.int8)    # weight for row 64
Wq    = np.vstack([Wq, b_row])                         # (65, 10); activation for row 64 is 255

xbar.set_tile(rows=65, cols=10)
xbar.load_weights_raw(Wq)
def classify(x):
    xbar.write_activations_raw(np.append(xq(x), 255).astype(np.uint8))
    xbar.compute()
    return xbar.read_argmax()                          # index = predicted digit
```

Report four accuracies side by side, each with a per-class breakdown:

| Row | How it's computed |
|---|---|
| Float | `clf.score(Xte, yte)` |
| Quantized, ideal array | all `NOISE_EN` bits off |
| Set A | `load_parameter_set("dualport_fefet_mlc")`, `enable(["quant", "d2d"])` |
| Board | the same two configurations on `--backend fpga`; must equal the `sim` numbers exactly |

Before trusting any accuracy number, run the mapping tests: round trip, orientation with a deliberately asymmetric matrix, and "array with noise off matches float to within quantization error".

## 4. How you know it's done

- `python sw/examples/digits.py --backend sim` runs from a clean install and prints the table above with a fixed split and seed.
- With noise off, quantized accuracy is within about a percentage point of float.
- The on-chip `READ_ARGMAX` index equals the host-side argmax of `READ_RESULT` for every test image on the clean path.
- `--backend fpga` gives exactly the same predictions as `sim` for the same configuration and seed (cross-backend test).
- With `SW[1:0] = 10`, the board's display shows the predicted digit.
- Per-image time on the board is printed. A 30-second backup recording exists.

## 5. Watch out for

- **On-chip argmax only sees raw integer sums.** `application-spec.md` recommends per-*column* weight scaling and a host-side bias, and also recommends `READ_ARGMAX` for sweeps. Those two don't combine: with a different scale per column, or a bias added afterwards, the largest raw accumulator isn't necessarily the largest true score. The sketch above avoids that with one scale for the whole matrix and the bias folded in as an extra input row. The cost is a little weight resolution, so compare float against quantized accuracy to confirm it's small. If you'd rather keep per-column scaling, you have to use `READ_RESULT` and do the descale and argmax on the host. Either way, write the choice into the spec.
- **Check the bias row fits in int8.** If `intercept / (s_w × s_a × 255)` exceeds ±127 for some class, give the bias row a smaller constant activation or split it across two rows.
- **Don't standardize the pixels** (subtracting a mean makes inputs signed, and then the first-layer offset correction of spec §2.4 is needed). Raw 0–16 pixels avoid the issue.
- **Transpose.** sklearn's `coef_` is (outputs, inputs); the tile is (rows = inputs, columns = outputs). A symmetric test matrix hides this bug, which is why the orientation test uses an asymmetric one.
- `active_cols = 10` means columns 10–63 still accumulate garbage on the board. `argmax_unit` masks them (A4); that mask is what this demo depends on.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

