# FeCIM task instructions — start here

This pack has detailed instructions for every task on the semester-1 completion board (`semester1-planner-board-rev3.md`), Mon 16 Nov to the presentation on Tue 1 Dec 2026. It was written against the repository at `main` @ `95a7e97`, with the `Zhiting` and `Natalie` branches as they stood on 16 Nov.

## What's in each task folder

Every task has its own folder with two files:

| File | Who it's for | What it contains |
|---|---|---|
| `<ID>_README.md` | you | What the task is and how it fits the project, explained at undergraduate level; where the work goes in the repo; pseudocode or steps; how you know it's done; what to watch out for |
| `<ID>_AI_PROMPT.md` | an AI model | The same task as a self-contained prompt: project context, the task, file locations, a design sketch, acceptance checks, known issues, the files to attach, and how the model should report back |

Read the README first, even if you plan to use the AI prompt. You're the one who has to explain the result in review and at the presentation.

## Using the AI prompts

- **With a coding agent that can see the repo** (for example Claude Code opened in the repo folder): paste everything below the line in the prompt file.
- **With a chatbot that can't see the repo:** paste the prompt, then attach or paste the files it lists under "Files to read first".
- Each prompt asks the model to list disagreements between the brief, the specs and the code *before* writing anything, to deliver whole files, to explain its changes to you, and to end with an "Issues and open questions" section. Read that section before using the output.
- AI output is a first draft. The acceptance checks in each README are what decide whether it's right. Run them yourself.
- `01_PROJECT_CONTEXT_FOR_AI.md` is the shared context block on its own, for starting an AI session on something that isn't a listed task.

## Task IDs

Lane tasks keep the IDs from the board (A1–A9, B1–B9, C1–C10, D1–D9). Team-wide tasks didn't have IDs on the board, so this pack gives them some: **K** for kickoff, **G** for checkpoints (gates), **P** for presentation, **X** for demo day and close-out. The index below maps each to its board title.

## Task index

### Bucket 1 — Kickoff and Merge

Folder: `1_Kickoff-and-merge/`

| ID | Task | Owner | Due | Folder |
|---|---|---|---|---|
| K1 | Agree semester-1 completion plan, owners, rebalance and async check-ins | Ethan Ruddell | Tue 17 Nov | `K1_agree-plan/` |
| K2 | PR: clean up and merge `Zhiting` branch (`config_regs`, `baud_inc`, `tb_uart`) | Zhiting Li | Tue 17 Nov | `K2_merge-zhiting-branch/` |
| K3 | PR: merge `Natalie` branch (README bug log) | Natalie Poche | Tue 17 Nov | `K3_merge-natalie-branch/` |
| K4 | Confirm every skeleton port list against its spec, in one `fecim_top` commit | Zhiting Li (all four review) | Tue 17 Nov | `K4_confirm-port-lists/` |
| K5 | Board and dongle rota through Tue 1 Dec (incl. Thanksgiving) | Zhiting Li | Tue 17 Nov | `K5_board-rota/` |
| K6 | Check rubric, time limit, format, peer-eval and written-report due dates | Ethan Ruddell | Tue 17 Nov | `K6_check-rubric/` |

### Bucket 2 — Lane A

Folder: `2_Lane-A_Zhiting-Li/`

| ID | Task | Owner | Due | Folder |
|---|---|---|---|---|
| A1 | `control_fsm` + `tb_control_fsm` | Zhiting Li | Wed 18 Nov | `A1_control-fsm/` |
| A2 | `IDENTIFY`, `SET_CONFIG` / `GET_CONFIG` on hardware at 921600 (hardware gate) | Zhiting Li | Thu 19 Nov | `A2_hardware-gate-identify/` |
| A3 | Readout path — `readout_ser` → `packet_tx` for `READ_RESULT` / `READ_ARGMAX` | Zhiting Li | Sat 21 Nov | `A3_readout-path/` |
| A4 | `argmax_unit` with runner-up (moved from Lane B) | Zhiting Li (Megan Mendez reviews) | Sat 21 Nov | `A4_argmax-unit/` |
| A5 | Quartus project for `fecim_top` + first fit | Zhiting Li | Sun 22 Nov | `A5_quartus-first-fit/` |
| A6 | `display_driver` on HEX | Zhiting Li | Wed 25 Nov | `A6_display-driver/` |
| A7 | Timing closure at 50 MHz, 64 lanes, all non-idealities | Zhiting Li | Tue 24 Nov | `A7_timing-closure/` |
| A8 | Error handling, recovery and soak test | Zhiting Li | Fri 27 Nov | `A8_error-handling-soak/` |
| A9 | Bitstream release process + replication guide | Zhiting Li | Sat 28 Nov | `A9_bitstream-release-replication/` |

### Bucket 3 — Lane B

Folder: `3_Lane-B_Megan-Mendez/`

| ID | Task | Owner | Due | Folder |
|---|---|---|---|---|
| B1 | `write_path` stage 1 — quantize + lane-select decode | Megan Mendez | Wed 18 Nov | `B1_write-path-quantize/` |
| B2 | `act_buffer` + IR attenuation (`atten_rom`, `WRITE_ATTEN`) | Megan Mendez | Fri 20 Nov | `B2_act-buffer-ir-drop/` |
| B3 | `write_path` stages 2–3 — D2D + stuck-at | Megan Mendez | Sat 21 Nov | `B3_write-path-d2d-stuck/` |
| B4 | `read_noise` integrated into `mac_lane` | Megan Mendez | Sat 21 Nov | `B4_read-noise-in-mac-lane/` |
| B5 | `adc_quant` (shared, round-to-nearest) | Megan Mendez | Fri 20 Nov | `B5_adc-quant/` |
| B6 | `result_buffer` | Megan Mendez | Fri 20 Nov | `B6_result-buffer/` |
| B7 | `tb_ab_integration` on real modules | Megan Mendez (Zhiting Li reviews) | Mon 23 Nov | `B7_ab-integration-real-modules/` |
| B8 | mac-array-spec §12 tests 2–10, all passing | Megan Mendez | Wed 25 Nov | `B8_array-spec-tests/` |
| B9 | Utilization report | Megan Mendez | Sat 28 Nov | `B9_utilization-report/` |

### Bucket 4 — Lane C

Folder: `4_Lane-C_Ethan-Ruddell/`

| ID | Task | Owner | Due | Folder |
|---|---|---|---|---|
| C1 | `model_exact` D2D + stuck-at + write-path golden vectors | Ethan Ruddell | Tue 17 Nov | `C1_model-d2d-stuck-vectors/` |
| C2 | Read noise, IR drop, ADC in the model + golden vectors | Ethan Ruddell | Wed 18 Nov | `C2_model-read-ir-adc-vectors/` |
| C3 | `ModelExact::step()` + full-array MVM sequencer | Ethan Ruddell | Fri 20 Nov | `C3_model-step-sequencer/` |
| C4 | Full-array L0: Verilated `mac_array` vs model, 1,000 × 128×128 | Ethan Ruddell | Sat 21 Nov | `C4_full-array-l0/` |
| C5 | Full-top co-sim with virtual UART — L1 and L2 | Ethan Ruddell | Mon 23 Nov | `C5_full-top-cosim-l1-l2/` |
| C6 | Calibration — set A documented, register mapping, provenance (week-7 gate) | Ethan Ruddell (co-owned with Natalie Poche) | Mon 23 Nov | `C6_calibration-set-a/` |
| C7 | CI — full-top job, L0 blocking, all lint blocking | Ethan Ruddell | Mon 23 Nov | `C7_ci-gates/` |
| C8 | L4 script — hardware ≡ `model_exact` at matched seed | Ethan Ruddell | Tue 24 Nov | `C8_l4-hardware-vs-model/` |
| C9 | L3 statistical validation | Ethan Ruddell | Fri 27 Nov | `C9_l3-statistical-validation/` |
| C10 | Coverage matrix closed + verification report | Ethan Ruddell | Sat 28 Nov | `C10_coverage-matrix-verification-report/` |

### Bucket 5 — Lane D

Folder: `5_Lane-D_Natalie-Poche/`

| ID | Task | Owner | Due | Folder |
|---|---|---|---|---|
| D1 | Packaging — `pyproject.toml`, `pip install -e ./sw` | Natalie Poche | Tue 17 Nov | `D1_packaging/` |
| D2 | Full command set in the driver | Natalie Poche | Thu 19 Nov | `D2_driver-full-command-set/` |
| D3 | Sim backend — `Crossbar(backend="sim")` | Natalie Poche | Sat 21 Nov | `D3_sim-backend/` |
| D4 | Parameter set → registers + IR profile generation | Natalie Poche (calibration co-owner with Ethan Ruddell) | Mon 23 Nov | `D4_parameter-set-to-registers/` |
| D5 | Sweep harness with provenance | Natalie Poche | Mon 23 Nov | `D5_sweep-harness/` |
| D6 | Linear digits classifier (64→10) — sim, then board | Natalie Poche | Wed 25 Nov | `D6_digits-linear/` |
| D7 | MLP digits classifier (64→32→10) — sim, then board | Natalie Poche | Fri 27 Nov | `D7_digits-mlp/` |
| D8 | Headline plots: calibrated baseline + degradation sweeps on hardware | Natalie Poche | Sat 28 Nov | `D8_headline-plots/` |
| D9 | Wheels, clean-machine test, user guide + API docs | Natalie Poche | Sat 28 Nov | `D9_wheels-user-guide-api-docs/` |

### Bucket 6 — Integration Checkpoints

Folder: `6_Integration-checkpoints/`

| ID | Task | Owner | Due | Folder |
|---|---|---|---|---|
| G1 | Thu 19 meeting: hardware gate, vectors delivered, port lists frozen | Ethan Ruddell | Thu 19 Nov | `G1_thu19-meeting/` |
| G2 | Checkpoint: full-array L0 green | Ethan Ruddell | Sat 21 Nov | `G2_checkpoint-l0/` |
| G3 | Checkpoint: L1 + L2 green in full-top co-sim; first fit done | Ethan Ruddell | Mon 23 Nov | `G3_checkpoint-l1-l2-fit/` |
| G4 | Checkpoint: L4 green on hardware (all six, bit-exact), timing met | Zhiting Li | Wed 25 Nov | `G4_checkpoint-l4-timing/` |
| G5 | Fri 27 virtual sync (Teams): L4, MLP, plots, slides | Ethan Ruddell | Fri 27 Nov | `G5_fri27-virtual-sync/` |
| G6 | Checkpoint: semester-1 complete — every Must task Completed | Ethan Ruddell | Sat 28 Nov | `G6_checkpoint-semester1-complete/` |

### Bucket 7 — Presentation

Folder: `7_Presentation/`

| ID | Task | Owner | Due | Folder |
|---|---|---|---|---|
| P1 | Slide deck draft (section owners) | Ethan Ruddell (each section has its own owner) | Wed 25 Nov | `P1_slide-deck-draft/` |
| P2 | Results slides: plots, resources, latency, verification | Natalie Poche | Sat 28 Nov | `P2_results-slides/` |
| P3 | Design-corrections and modelling-assumptions slide | Ethan Ruddell | Wed 25 Nov | `P3_design-corrections-slide/` |
| P4 | Demo video + run sheet + backup recordings | Natalie Poche | Sat 28 Nov | `P4_demo-video-run-sheet/` |
| P5 | Remote rehearsal, timed (slides + recorded demos) | Ethan Ruddell | Sun 29 Nov | `P5_remote-rehearsal/` |

### Bucket 8 — Demo Day and Close-out

Folder: `8_Demo-day-and-close-out/`

| ID | Task | Owner | Due | Folder |
|---|---|---|---|---|
| X1 | Merge cutoff — `main` frozen | Ethan Ruddell | Sun 29 Nov, 18:00 | `X1_merge-cutoff/` |
| X2 | Dry run from clean clone, both boards (second timed rehearsal) | Ethan Ruddell | Mon 30 Nov | `X2_dry-run/` |
| X3 | Presentation | Ethan Ruddell (all four present) | Tue 1 Dec | `X3_presentation/` |
| X4 | README current state + tag `v1.0.0` + GitHub release | Ethan Ruddell | Wed 2 Dec | `X4_readme-tag-release/` |
| X5 | Meeting logs (incl. pre-alpha backfill) | Natalie Poche | Wed 2 Dec | `X5_meeting-logs/` |
| X6 | Peer evaluations (if assigned) | Ethan Ruddell (each member submits their own) | Wed 2 Dec | `X6_peer-evaluations/` |

## Corrections to the rev 3 board

Reading the code and specs closely to write these instructions turned up places where the board's wording was wrong or incomplete. The task files use the corrected version.

| # | Board said | What the repo and specs actually say | Affects |
|---|---|---|---|
| 1 | A2 needs a new board-level wrapper around `fecim_top` | `fecim_top.sv` already is the board top; it has the device pins. What's missing is pin assignments: `quartus/pins.tcl` only covers the UART demo | A2, A5 |
| 2 | (not mentioned) | **`IDENTIFY` and `GET_CONFIG` have no payload source.** `packet_tx` pulls reply bytes only from `readout_ser`, which is a skeleton with no access to the identify fields or `cfg_rdata`. As it stands, `IDENTIFY` would hang. This sits directly on the path to Thursday's hardware gate | K4, A2 |
| 3 | Chunk bulk writes at `MAX_PAYLOAD` = 512 | Protocol §4.1: chunks of **256 data bytes** | D2 |
| 4 | `Crossbar(backend="serial")` | The driver spec names it **`backend="fpga"`** | D2, D3, D6–D8, C8 |
| 5 | `READ_RESULT` past `active_cols` returns `ST_ADDR_RANGE` | The range check is against `TILE_COLS` (protocol §4.4, and the parser's code) | A3 |
| 6 | Latency "about 390 cycles, 7.8 µs" | Exactly `2 × (1 + 128 + 3 + 64)` = **392 cycles = 7.84 µs** | A1, C3, slides |
| 7 | Verification matrix "ADC bits ∈ {4, 8, 16, 32}" (from the spec) | `ADC_BITS` is a 5-bit register and ≥ 24 is a no-op. Use {4, 8, 16, 24} | C5, C10 |
| 8 | Zhiting's branch "touches five Lane B files" | Those changes, and one in `fecim_pkg.sv`, are an editor encoding fault (`§` became `Â§`) plus an added `timescale` line. Restore all six from `main` | K2 |
| 9 | (not mentioned) | Four skeletons lack ports their specs require: `write_path` (`noise_seed`), `argmax_unit` (`active_cols`), `mac_lane` (read-noise inputs), `result_buffer` (`result_seq`, which `config_regs` hard-codes to 0) | K4 |
| 10 | (not mentioned) | `sw/fecim/plan-d.yml` is really the `gf28_hkmg` parameter set (set B) under the wrong name; `sw/fecim/code.py` and `crossbar.py` are empty files | D1, C6 |
| 11 | "Digit appears on HEX" | The display spec shows the argmax index only when `SW[1:0] = 10` | A6, D6 |
| 12 | Golden vectors "emitted by the model" | The repo's existing pattern is an *independent* Python generator with a `--check` mode, cross-checked against the model. The new vector sets follow that pattern | C1, C2 |

## Decisions that need two lanes to agree

Each of these is one sentence that has to be the same in the RTL and in the model, or bit-exactness fails for a reason that has nothing to do with a bug. Settle them at or before the Thu 19 meeting and write each into its spec.

| # | Decision | Between | Where it's discussed |
|---|---|---|---|
| 1 | Where the `IDENTIFY` / `GET_CONFIG` reply bytes come from | Zhiting, Natalie | K4, A2 |
| 2 | Whether the drain chain shifts in the same cycle as the first result write | Zhiting, Megan | A1, B6, B7 |
| 3 | Which LFSR state a row's noise sample uses (before or after that row's step) | Megan, Ethan | B4, C2 |
| 4 | Whether lane LFSRs advance when read noise is disabled | Megan, Ethan | B4, C2 |
| 5 | The sign convention for stuck-at-rail | Ethan, Megan | C1, B3 |
| 6 | What `argmax_second` holds when only one column is active | Zhiting, Ethan | A4, C3 |
| 7 | What `CYCLE_CNT` counts | Zhiting, Ethan | A1, C3 |
| 8 | Whether `CTRL[1]` zeroes the result memory or only clears the valid flag | Megan, Ethan | B6, C3 |
| 9 | What `CTRL[0]` soft reset does and doesn't reset | Zhiting, Ethan | A8, C3 |
| 10 | At which baud rate the reply to a baud-rate change is sent | Zhiting, Natalie | A2, D2 |
| 11 | How weights and bias are scaled so the on-chip argmax is valid (the application spec's per-column scaling and `READ_ARGMAX` don't combine) | Natalie, Ethan | D6 |
| 12 | How the IR-drop "factorization" test is worded: attenuating the activation isn't bit-identical to attenuating each product once the `>> 8` is included | Megan, Ethan | B8 |

## The critical path

If you only track a handful of tasks, track these, in this order:

```text
K2 merge  ->  K4 ports  ->  C1, C2 vectors  ->  A1 sequencer, B1-B6 leaf RTL
          ->  A2 hardware gate (Thu 19)
          ->  C3 model step  ->  C4 L0 (Sat 21)  ->  C5 L1/L2 + A5 fit (Mon 23)
          ->  A7 timing  ->  C8 hardware match (Wed 25)
          ->  D6, D7, D8 on hardware  ->  everything done (Sat 28)  ->  cutoff (Sun 29, 18:00)
```

## What to keep in mind about these instructions

- **The pseudocode is a sketch.** It was written from the specs and the existing code, and none of it has been compiled or simulated. Where a sketch and a spec disagree, the spec wins, and the golden vectors and tests are the final word.
- **Line references and file contents are as of 16 Nov.** Once K2 and K4 merge, some skeletons will have changed; the task files say where that matters.
- **Some method names are placeholders.** The host API in the Lane C and Lane D sketches (`load_weights_raw`, `set_tile` and so on) follows the driver spec's style, but the real names are whatever D2 and D3 ship.
- **Hardware behaviour hasn't been checked.** Nothing here was run on a board. Pin assignments in particular must come from `hardware.md` and the DE10-Lite manual, not from an AI model's memory.
