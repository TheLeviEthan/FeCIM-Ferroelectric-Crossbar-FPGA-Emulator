# AI prompt — K4: Confirm every skeleton port list against its spec, in one fecim_top commit

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **K4 — Confirm every skeleton port list against its spec, in one fecim_top commit**, owned by Zhiting Li (all four review), due Tue 17 Nov.

Make a ports-only change across the RTL so that every skeleton module has the inputs and outputs its specification requires, and update `fecim_top.sv` to match in the same change.

Apply the seven changes listed in the design sketch, then read each remaining skeleton against its spec and report any further missing or mismatched port you find, with the spec section that requires it. Don't implement any module logic: new inputs remain unused inside skeletons (keep the existing lint waivers), and new outputs are tied to safe constants. The result must pass whole-design `verilator --lint-only -Wall` and the existing testbenches. Where the co-simulation harness instantiates a changed module directly, list the edit its owner needs to make.

Editable files: `rtl/fecim_top.sv` and the port lists of the modules named above; `docs/plans and specs/02-lane-a-interface/top-level-spec.md` §7.1.

## Where the work goes

- **Top level:** `rtl/fecim_top.sv` (Lane A owns it; this is the one commit that changes its wiring).
- **Skeleton port lists to change:** `rtl/write/write_path.sv`, `rtl/result/argmax_unit.sv`, `rtl/result/result_buffer.sv`, `rtl/array/mac_lane.sv`, `rtl/control/readout_ser.sv`, `rtl/control/config_regs.sv`, `rtl/packet/packet_parser.sv`.
- **Checked and fine as they are:** `control_fsm`, `act_buffer`, `adc_quant`, `read_noise`, `display_driver`, `mac_array` (its noise ports exist but aren't passed down yet).
- **Seam definition:** `docs/plans and specs/02-lane-a-interface/top-level-spec.md` §7.1.

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

Changes found by reading the skeletons against the specs:

| # | Module | Change | Why |
|---|---|---|---|
| 1 | `write_path` | add `input logic [31:0] noise_seed` | both cell hashes are seeded with `noise_seed[15:0]` (write-path-spec §5) |
| 2 | `argmax_unit` | add `input logic [15:0] active_cols` | columns at or beyond it must be masked (result-buffer-spec §5.1) |
| 3 | `mac_lane` | add `read_sigma`, `noise_seed`, `reseed` inputs; pass them from `mac_array` | the read-noise generator lives inside each lane (mac-array-spec §5) |
| 4 | `result_buffer` | add `output logic [7:0] result_seq` | `STATUS[15:8]` (protocol §6.4) |
| 5 | `config_regs` | add `input logic [7:0] result_seq`, drive `STATUS[15:8]` from it | today it's hard-coded to 0 |
| 6 | `readout_ser` | add what it needs to serialize the `IDENTIFY` and `GET_CONFIG` payloads: the command being answered, `cfg_rdata`, and the error counters | nothing supplies those payload bytes today (see A2) |
| 7 | `packet_parser` | add separate CRC-error and timeout counter outputs | the identify block reports them separately (protocol §4.5) |

Procedure:

1. Zhiting makes the port-only changes on one branch. New inputs stay unused inside the skeletons, under the lint waivers that are already there.
2. Update the instances in `fecim_top.sv` in the same commit.
3. Run whole-design lint; it must still be clean.
4. Megan confirms rows 1–4, Ethan confirms that the model's `step()` interface can mirror the result, Natalie confirms row 6 gives the driver what `IDENTIFY` needs.
5. Merge. From here on, a port change is a team decision announced in the check-in thread.

Use the same sitting to confirm that the two errors found in the write-path spec's code in October (a zero-extension and a 9-bit product truncation) have been corrected in the spec text.

## Acceptance checks

- One merged PR changes `fecim_top.sv` and the seven port lists; no module logic is implemented in it.
- Whole-design lint is clean and `tb/run_sims.sh` still passes.
- All four have approved the PR.
- `top-level-spec.md` §7.1 lists the added seam signals.
- The write-path spec errata are confirmed fixed, or fixed.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **Row 6 is on the critical path for Thursday.** Without a payload source, `IDENTIFY` hangs. Decide here whether the identify and config-read bytes come from `readout_ser` or from a small separate mux, so A2 can start straight away.
- **`mac_lane`'s port change touches Ethan's co-simulation,** which instantiates `mac_lane` directly (`model/cosim/run_l0.cpp`). Give the new inputs harmless constants there in the same PR, with his review.
- Don't implement behaviour in this PR "while you're in the file". Port lists only, so the review is quick.
- If someone needs another port later, expect it. The rule is to announce it before changing `fecim_top.sv`, not to pretend it won't happen.

## Files to read first (attach or paste these if you're using a chatbot)

- `rtl/fecim_pkg.sv`, `rtl/fecim_top.sv`
- Every file under `rtl/control/`, `rtl/packet/`, `rtl/write/`, `rtl/array/`, `rtl/result/`
- `model/cosim/run_l0.cpp`, `model/cosim/Makefile`
- `docs/plans and specs/02-lane-a-interface/top-level-spec.md`, `control-fsm-spec.md`
- `docs/plans and specs/03-lane-b-array/` (all four specs)
- `docs/plans and specs/01-contract/protocol.md`

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

