# K4 — Confirm every skeleton port list against its spec, in one fecim_top commit

| | |
|---|---|
| **Owner** | Zhiting Li (all four review) |
| **Due** | Tue 17 Nov |
| **Board bucket** | Bucket 1 — Kickoff and Merge |
| **Board task** | Confirm every skeleton port list against its spec, in one `fecim_top` commit |
| **Needs first** | K2 |
| **Unblocks** | A1–A4, B1–B6, C3 |
| **AI version** | `K4_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Nine modules are about to be written by different people at the same time. Each one plugs into `fecim_top` through its ports: the named wires on its edge. If two people each add or rename a port in the same week, they both edit `fecim_top.sv`, their changes collide, and the top level stops compiling for everyone.

The skeletons say outright that their port lists are provisional. Reading them against the specs turns up several places where a module is missing a wire it can't work without. For example, the write path needs the random seed to compute its per-cell hash, and it has no seed input.

So we fix the edges once, together, before anyone fills in a module. After this commit the top level is frozen: each person works inside their own file and nobody needs to touch the wiring again. It's an hour of careful reading that prevents a week of merge conflicts.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Top level:** `rtl/fecim_top.sv` (Lane A owns it; this is the one commit that changes its wiring).
- **Skeleton port lists to change:** `rtl/write/write_path.sv`, `rtl/result/argmax_unit.sv`, `rtl/result/result_buffer.sv`, `rtl/array/mac_lane.sv`, `rtl/control/readout_ser.sv`, `rtl/control/config_regs.sv`, `rtl/packet/packet_parser.sv`.
- **Checked and fine as they are:** `control_fsm`, `act_buffer`, `adc_quant`, `read_noise`, `display_driver`, `mac_array` (its noise ports exist but aren't passed down yet).
- **Seam definition:** `docs/plans and specs/02-lane-a-interface/top-level-spec.md` §7.1.

## 3. How to build it

Changes found by reading the skeletons against the specs:

| # | Module | Change | Why |
|---|---|---|---|
| 1 | `write_path` | add `input logic [31:0] noise_seed` | both cell hashes are seeded with `noise_seed[15:0]` (write-path-spec §5) |
| 2 | `argmax_unit` | add `input logic [15:0] active_cols` | columns at or beyond it must be masked (result-buffer-spec §5.1) |
| 3 | `mac_lane` | add `read_sigma`, `noise_seed`, `reseed` inputs; pass them from `mac_array` | the read-noise generator lives inside each lane (mac-array-spec §5) |
| 4 | `result_buffer` | add `output logic [7:0] result_seq` | `STATUS[15:8]` (protocol §6.4) |
| 5 | `config_regs` | add `input logic [7:0] result_seq`, drive `STATUS[15:8]` from it | today it's hard-coded to 0 |
| 6 | `readout_ser` | add what it needs to serialize the `IDENTIFY` and `GET_CONFIG` payloads: the command being answered, `cfg_rdata`, and the error counters | nothing supplies those payload bytes today (see A2) |
| 7 | `packet_parser` | add separate CRC-error and timeout counter outputs | the identify block reports them separately (protocol §4.5) |

Procedure:

1. Zhiting makes the port-only changes on one branch. New inputs stay unused inside the skeletons, under the lint waivers that are already there.
2. Update the instances in `fecim_top.sv` in the same commit.
3. Run whole-design lint; it must still be clean.
4. Megan confirms rows 1–4, Ethan confirms that the model's `step()` interface can mirror the result, Natalie confirms row 6 gives the driver what `IDENTIFY` needs.
5. Merge. From here on, a port change is a team decision announced in the check-in thread.

Use the same sitting to confirm that the two errors found in the write-path spec's code in October (a zero-extension and a 9-bit product truncation) have been corrected in the spec text.

## 4. How you know it's done

- One merged PR changes `fecim_top.sv` and the seven port lists; no module logic is implemented in it.
- Whole-design lint is clean and `tb/run_sims.sh` still passes.
- All four have approved the PR.
- `top-level-spec.md` §7.1 lists the added seam signals.
- The write-path spec errata are confirmed fixed, or fixed.

## 5. Watch out for

- **Row 6 is on the critical path for Thursday.** Without a payload source, `IDENTIFY` hangs. Decide here whether the identify and config-read bytes come from `readout_ser` or from a small separate mux, so A2 can start straight away.
- **`mac_lane`'s port change touches Ethan's co-simulation,** which instantiates `mac_lane` directly (`model/cosim/run_l0.cpp`). Give the new inputs harmless constants there in the same PR, with his review.
- Don't implement behaviour in this PR "while you're in the file". Port lists only, so the review is quick.
- If someone needs another port later, expect it. The rule is to announce it before changing `fecim_top.sv`, not to pretend it won't happen.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

