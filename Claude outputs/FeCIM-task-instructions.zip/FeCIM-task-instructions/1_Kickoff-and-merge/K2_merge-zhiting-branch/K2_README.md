# K2 — Clean up and merge the Zhiting branch (config_regs, baud_inc, tb_uart)

| | |
|---|---|
| **Owner** | Zhiting Li |
| **Due** | Tue 17 Nov |
| **Board bucket** | Bucket 1 — Kickoff and Merge |
| **Board task** | PR: clean up and merge `Zhiting` branch (`config_regs`, `baud_inc`, `tb_uart`) |
| **Needs first** | nothing |
| **Unblocks** | K3, K4, A1, A2, C7 and everyone who needs `config_regs` |
| **AI version** | `K2_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Your branch holds work the whole team is waiting for. `config_regs` is the register file: every non-ideality, the tile size, the seed and the baud rate are set through it. It also has the fix that lets the baud rate be changed at run time, and the reworked UART testbench. None of that helps anyone until it's on `main`.

The branch has also picked up two kinds of accidental changes that mustn't reach `main`. Four empty files were created at the top of the repository, and six files belonging to other people were altered by an editor encoding problem. Neither is your design work, and both would cause confusion or merge pain for teammates later.

Merging cleanly now, as the first thing anyone does, means everyone else starts their two weeks from the same base. It's a small task with the largest fan-out on the board.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Branch:** `Zhiting` (7 commits ahead of `main`; it merges without conflicts).
- **Keep:** `rtl/control/config_regs.sv`, `rtl/uart/baud_gen.sv`, `rtl/uart/uart_rx.sv`, `quartus/uart_board_logic.sv`, `quartus/top_level.sv`, `tb/tb_uart.sv`.
- **Remove:** four zero-byte files at the repository root: `ACC`, `CLEAR`, `DONE,` (the name includes the comma) and `DRAIN`.
- **Restore from `main`:** `rtl/array/act_buffer.sv`, `rtl/array/adc_quant.sv`, `rtl/array/mac_array.sv`, `rtl/array/mac_lane.sv`, `rtl/array/read_noise.sv`, `rtl/fecim_pkg.sv`. On your branch each one differs from `main` only by an added `` `timescale 1ns/1ps `` line and by `§` characters in comments having turned into `Â§`.
- **CI file:** `.github/workflows/ci.yml` (the `continue-on-error` lines for your modules).

## 3. How to build it

```bash
git fetch origin
git switch Zhiting
git merge origin/main                      # no conflicts expected

# 1. the four stray files
git rm ACC CLEAR 'DONE,' DRAIN

# 2. put other lanes' files and the package back exactly as they are on main
git checkout origin/main -- rtl/array/act_buffer.sv rtl/array/adc_quant.sv \
    rtl/array/mac_array.sv rtl/array/mac_lane.sv rtl/array/read_noise.sv rtl/fecim_pkg.sv

# 3. confirm nothing else is damaged
grep -rn "Â§" rtl tb quartus docs && echo "still some left" || echo "clean"
git diff --stat origin/main                # should list only your own files

# 4. everything still passes
tb/run_sims.sh
verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
    $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')

git commit -m "Zhiting: drop stray files, restore Lane B files and package from main"
git push
```

Then open the pull request and paste its link into the Planner task.

Where the stray files probably came from: a shell line such as `IDLE -> CLEAR -> ACC -> DRAIN -> DONE, ...` pasted into a terminal. The shell reads `>` as "send output to a file with this name".

Where the `Â§` came from: an editor saved UTF-8 files using a Windows code page. Set your editor's default encoding to UTF-8 so it doesn't happen again.

## 4. How you know it's done

- `git diff --stat origin/main` on the branch lists only Lane A files.
- No `Â§` anywhere in the repository.
- `tb/run_sims.sh` passes, including `tb_uart`, `tb_uart_edge` and `tb_ab_integration`.
- Whole-design lint is clean, or any remaining warning is in a file whose skeleton hasn't been implemented yet.
- CI is green on the PR; the `continue-on-error` lines for `packet_parser` and `packet_tx` are deleted if their lint is now clean.
- The PR is merged and its link is in the Planner task.

## 5. Watch out for

- **If the `timescale` line was added to silence a Verilator warning,** don't add it to shared files. Pass a timescale on the Verilator command line in `tb/run_sims.sh` instead, and raise it with Ethan, since that script is shared.
- **`config_regs` hard-codes `result_seq` to zero** ("not present in current port list"). Leave a `TODO(B6)` there; K4 adds the port.
- Check `tb_uart_edge` specifically. The README says it needed updating for `baud_gen`'s `baud_inc` port, and CI doesn't run it today.
- After this merges, tell Natalie: her branch contains your commits, so K3 becomes a one-file diff.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

