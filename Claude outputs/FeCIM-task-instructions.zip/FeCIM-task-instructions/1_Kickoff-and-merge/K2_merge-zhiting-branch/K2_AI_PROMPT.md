# AI prompt — K2: Clean up and merge the Zhiting branch (config_regs, baud_inc, tb_uart)

> **How to use this file.** Everything below the line is the prompt.
> - **AI coding agent with repository access** (for example Claude Code in the repo folder): paste everything below the line. The agent can open the listed files itself.
> - **Chatbot without repository access:** paste everything below the line, and attach or paste the files listed under "Files to read first". Send the largest spec files as attachments if the chat allows it.
>
> Read the reply's "Issues and open questions" section before you use any of the code, and run the acceptance checks yourself.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida finish **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. The repository is `FeCIM-Ferroelectric-Crossbar-FPGA-Emulator`.

A real crossbar computes a matrix-vector product in analog: weights are stored as cell conductances, activations are applied as row voltages, and each column wire sums the resulting currents. FeCIM reproduces that computation digitally in SystemVerilog on a Terasic DE10-Lite (Intel MAX 10 `10M50DAF484C7G`, one 50 MHz clock domain, no PLL). It then deliberately injects six device non-idealities, each switchable through one bit of the `NOISE_EN` register:

| Bit | Effect | Where it's applied |
|---|---|---|
| 0 | Conductance quantization | write path, when a weight is stored |
| 1 | Device-to-device (D2D) variation | write path |
| 3 | Stuck-at faults | write path |
| 2 | Cycle-to-cycle read noise | inside each MAC lane, per-lane LFSR |
| 4 | IR drop | activation broadcast, one coefficient per row |
| 5 | ADC quantization | drain-chain output, before the result buffer |

A Python host drives the board over UART (CP2102 dongle, 115200 baud at reset, 921600 in use). A C++17 model, `model_exact`, reproduces the RTL bit for bit, so every hardware result can be checked against it. The demo application is a digit classifier whose accuracy is measured as each non-ideality is turned up.

**Geometry.** 128×128 tile, 64 MAC lanes, 2 passes. Lane `l` owns columns `l` and `l + 64`. One sequence counter `seq_cnt = {pass, row}` is the weight address in every lane. A full matrix-vector multiply takes `2 × (1 + 128 + 3 + 64) = 392` cycles (7.84 µs). Weights are `int8`, activations are `uint8`, accumulators are 32-bit signed.

**Repository layout.**
- `rtl/` — `fecim_pkg.sv` (shared parameters, enums, `cell_hash16`, `crc8_byte`), `fecim_top.sv`, and `uart/`, `packet/`, `control/`, `write/`, `array/`, `result/`
- `tb/` — `run_sims.sh` (runs every self-checking Verilator testbench), `sv/`, `integration/`, `golden/` (shared vector files)
- `model/` — `include/fecim/`, `src/`, `tests/` (CMake), `cosim/` (Verilator co-simulation harness)
- `sw/` — the Python package `fecim`, `tests/`, `examples/`
- `quartus/` — pin constraints, project scripts, `reports/`
- `docs/plans and specs/` — the specifications. These are authoritative. In this brief, a spec path that starts with a number (such as `03-lane-b-array/mac-array-spec.md`) is relative to this folder.

**Team lanes.** A — Zhiting Li: host-interface RTL and the top level. B — Megan Mendez: array RTL. C — Ethan Ruddell: C++ model and verification. D — Natalie Poche: Python host stack and application.

**Constraints that hold for every task, and why.**
- **Bit-exactness.** The RTL, `model_exact` and the Python `sim` backend must produce identical integers for the same configuration and seed. The model uses integer arithmetic only, with the same shifts, clamps and rounding as the RTL. A 1-LSB difference is a bug, not noise, because the whole verification plan rests on exact comparison.
- **9-bit multiplier operands.** The MAX 10 has 144 embedded multiplier blocks, and each does one 18×18 or two 9×9 signed multiplies. The design only fits because every per-lane multiply is 9×9, signed × signed. Don't widen an operand and don't make one unsigned; zero-extend to a signed-positive 9-bit value instead.
- **Fixed widths and scales.** `ACC_W = 32`. Read-noise clamp is ±127. `D2D_SIGMA` scales by `reg/256` and `READ_SIGMA` by `reg/512`; neither is Q1.8. D2D variation is triangular (two hash bytes), not Gaussian.
- **Frozen contracts.** `docs/plans and specs/01-contract/protocol.md`, the register map, and `rtl/fecim_pkg.sv` are shared by all four lanes. If the task seems to need a change to one of them, stop and say so instead of changing it.
- **RTL style.** SystemVerilog within the Quartus Prime Lite 25.1std subset. `always_ff` and `always_comb` only. Active-low reset `rst_n`, asynchronous assert and synchronous deassert. Constants come from `fecim_pkg`, never retyped as literals. Finished modules pass `verilator --lint-only -Wall` (Verilator 5.020) with no lint waivers left in them.
- **Lane ownership.** Edit only the files this brief lists as editable. If a file in another lane needs to change, describe the change precisely so its owner can make it.
- **Existing tests keep passing.** CI is green on `main` today: the testbenches it runs through `tb/run_sims.sh`, `./build/model_tests`, and the single-lane co-simulation `model/cosim/run_l0`. `pytest sw/tests` passes locally. A change that breaks any of them isn't finished.

## Your task

Task **K2 — Clean up and merge the Zhiting branch (config_regs, baud_inc, tb_uart)**, owned by Zhiting Li, due Tue 17 Nov.

Help clean up a feature branch before it's merged. The branch contains wanted work in Lane A files, plus two accidental changes: four zero-byte files at the repository root (`ACC`, `CLEAR`, `DONE,`, `DRAIN`), and six files outside Lane A that differ from `main` only by an added `timescale` line and by `§` characters corrupted to `Â§`.

With repository access: merge `origin/main` into the branch, remove the four files, restore the six files from `origin/main`, confirm with `git diff --stat origin/main` and a search for `Â§` that only Lane A files differ, then run the testbenches and lint and report the results. Don't push or open the pull request unless asked. Without repository access: give the exact git commands, explain what each does, and say what output to expect at each step. If any of the six files turns out to contain a real functional change, stop and report it instead of restoring over it.

## Where the work goes

- **Branch:** `Zhiting` (7 commits ahead of `main`; it merges without conflicts).
- **Keep:** `rtl/control/config_regs.sv`, `rtl/uart/baud_gen.sv`, `rtl/uart/uart_rx.sv`, `quartus/uart_board_logic.sv`, `quartus/top_level.sv`, `tb/tb_uart.sv`.
- **Remove:** four zero-byte files at the repository root: `ACC`, `CLEAR`, `DONE,` (the name includes the comma) and `DRAIN`.
- **Restore from `main`:** `rtl/array/act_buffer.sv`, `rtl/array/adc_quant.sv`, `rtl/array/mac_array.sv`, `rtl/array/mac_lane.sv`, `rtl/array/read_noise.sv`, `rtl/fecim_pkg.sv`. On your branch each one differs from `main` only by an added `` `timescale 1ns/1ps `` line and by `§` characters in comments having turned into `Â§`.
- **CI file:** `.github/workflows/ci.yml` (the `continue-on-error` lines for your modules).

## Design sketch

This is the team's planned approach. The specs and the existing code are authoritative: where they disagree with this sketch, follow them and say so.

```bash
git fetch origin
git switch Zhiting
git merge origin/main                      # no conflicts expected

# 1. the four stray files
git rm ACC CLEAR 'DONE,' DRAIN

# 2. put other lanes' files and the package back exactly as they are on main
git checkout origin/main -- rtl/array/act_buffer.sv rtl/array/adc_quant.sv \
    rtl/array/mac_array.sv rtl/array/mac_lane.sv rtl/array/read_noise.sv rtl/fecim_pkg.sv

# 3. confirm nothing else is damaged
grep -rn "Â§" rtl tb quartus docs && echo "still some left" || echo "clean"
git diff --stat origin/main                # should list only your own files

# 4. everything still passes
tb/run_sims.sh
verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
    $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')

git commit -m "Zhiting: drop stray files, restore Lane B files and package from main"
git push
```

Then open the pull request and paste its link into the Planner task.

Where the stray files probably came from: a shell line such as `IDLE -> CLEAR -> ACC -> DRAIN -> DONE, ...` pasted into a terminal. The shell reads `>` as "send output to a file with this name".

Where the `Â§` came from: an editor saved UTF-8 files using a Windows code page. Set your editor's default encoding to UTF-8 so it doesn't happen again.

## Acceptance checks

- `git diff --stat origin/main` on the branch lists only Lane A files.
- No `Â§` anywhere in the repository.
- `tb/run_sims.sh` passes, including `tb_uart`, `tb_uart_edge` and `tb_ab_integration`.
- Whole-design lint is clean, or any remaining warning is in a file whose skeleton hasn't been implemented yet.
- CI is green on the PR; the `continue-on-error` lines for `packet_parser` and `packet_tx` are deleted if their lint is now clean.
- The PR is merged and its link is in the Planner task.

## Known issues and open points

These were found while planning. Resolve the ones inside this task's files, and report on the rest.

- **If the `timescale` line was added to silence a Verilator warning,** don't add it to shared files. Pass a timescale on the Verilator command line in `tb/run_sims.sh` instead, and raise it with Ethan, since that script is shared.
- **`config_regs` hard-codes `result_seq` to zero** ("not present in current port list"). Leave a `TODO(B6)` there; K4 adds the port.
- Check `tb_uart_edge` specifically. The README says it needed updating for `baud_gen`'s `baud_inc` port, and CI doesn't run it today.
- After this merges, tell Natalie: her branch contains your commits, so K3 becomes a one-file diff.

## Files to read first (attach or paste these if you're using a chatbot)

- Output of `git diff --stat origin/main...origin/Zhiting` and `git log --oneline origin/main..origin/Zhiting`
- Output of `git diff origin/main origin/Zhiting -- rtl/array rtl/fecim_pkg.sv`
- `tb/run_sims.sh`, `.github/workflows/ci.yml`
- `rtl/control/config_regs.sv` from the branch

## How to respond

1. **Read before writing.** If you have repository access, open the files listed above. If you're a chatbot, they'll be attached or pasted; when a file you need is missing, ask for it before writing code. Don't guess at the contents of a file you haven't seen.
2. **Report disagreements first.** Before any code, list every place where this brief, the specs and the existing code disagree, and say which one you followed and why.
3. **Deliver whole files.** Give each new or changed file in full with its repository path, not fragments or diffs with parts left out. With repository access: work on a branch named `<owner-first-name>/<task-id>-<short-name>`, run the commands under "Acceptance checks" and show their output. Don't commit, push or open a pull request unless the user asks.
4. **Explain the work to its owner.** Go file by file: what each block does, which spec section it implements, and the reason for any choice that isn't obvious. The owner is a senior undergraduate engineer who has to defend this code in review and present it, so give the reasoning and not only the result. Define any term a computer-engineering senior might not know.
5. **End with "Issues and open questions".** Include inconsistencies you found, assumptions you made, anything you couldn't test, changes needed in files you weren't allowed to edit, and risks the owner should check on hardware (timing, resource use, bit-exactness).

Only say a check passes if you ran it and saw it pass. If you couldn't run something, say so and give the exact command for the owner to run.

