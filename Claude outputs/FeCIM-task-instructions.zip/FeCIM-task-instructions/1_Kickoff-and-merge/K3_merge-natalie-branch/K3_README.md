# K3 — Merge the Natalie branch (README bug log)

| | |
|---|---|
| **Owner** | Natalie Poche |
| **Due** | Tue 17 Nov |
| **Board bucket** | Bucket 1 — Kickoff and Merge |
| **Board task** | PR: merge `Natalie` branch (README bug log) |
| **Needs first** | K2 (merge Zhiting's branch first) |
| **Unblocks** | D1 and the rest of Lane D, starting from a clean `main` |
| **AI version** | `K3_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Your branch has one change of your own that isn't on `main`: the "Troubleshooting & Resolved Bugs" section of the README, which records two real problems the team hit and fixed. That's worth keeping. A written record of bugs and their root causes is evidence of engineering process, and it saves the next person from rediscovering them.

The branch also contains all of Zhiting's commits, because you merged her work in. If your pull request goes first, her changes arrive under your name along with her accidental files. Merging hers first (K2) and then updating yours leaves a small, clean diff that's easy to review.

Starting Lane D's two weeks from an up-to-date `main` also means every later branch you create is based on what everyone else has.

## 2. Where the work goes

*Spec paths that start with a number, such as `03-lane-b-array/...`, are under `docs/plans and specs/`.*

- **Branch:** `Natalie`.
- **Your change:** `README.md`, the new "Troubleshooting & Resolved Bugs" section just above "License", plus a small edit in `sw/examples/demo_dongle_loopback.py`.
- **Everything else in the diff** against today's `main` comes from Zhiting's branch.

## 3. How to build it

```bash
# after Zhiting's PR (K2) is merged
git fetch origin
git switch Natalie
git merge origin/main
git diff --stat origin/main        # expect: README.md and sw/examples/demo_dongle_loopback.py only
```

If the stat still lists other files (the four stray files, or files under `rtl/`), take `main`'s version of each:

```bash
git rm --ignore-unmatch ACC CLEAR 'DONE,' DRAIN
git checkout origin/main -- rtl quartus tb
```

Then fix one thing in the README section. The first entry's checkbox is `- []`, which doesn't render as a checkbox, and the entry describes a resolved bug. Make both entries `- [x]`.

Commit, push, open the pull request and paste its link into the Planner task.

## 4. How you know it's done

- `git diff --stat origin/main` shows only your README section and your example script.
- Both bug entries render as ticked checkboxes on GitHub.
- CI is green and the PR is merged.

## 5. Watch out for

- Don't open the PR before K2 merges, or the diff will include sixteen files.
- From now on, branch per task from `main` (`natalie/D1-packaging` and so on). One long-lived personal branch is what caused this tangle.

## 6. Workflow

1. **Branch.** `git switch -c <your-first-name>/<task-id>-<short-name>` from an up-to-date `main`.
2. **Use the AI version if you like.** `*_AI_PROMPT.md` in this folder holds the same task written for an AI model. AI-drafted code is held to the same bar as hand-written code: you run the checks, and you must be able to explain every line in review.
3. **Run the checks that apply** from the repo root (WSL or Linux, Verilator 5.020):
   ```bash
   # RTL lint, whole design
   verilator --lint-only -Wall --top-module fecim_top rtl/fecim_pkg.sv \
       $(find rtl -name '*.sv' -not -name 'fecim_pkg.sv')
   tb/run_sims.sh                      # all testbenches; or: tb/run_sims.sh tb_<name>
   #   (tb_uart_edge may fail on main until the Zhiting branch merges, task K2)
   cmake -S model -B build && cmake --build build && ./build/model_tests
   make -C model/cosim && ./model/cosim/run_l0 1 500
   pip install -e './sw[test]' && pytest sw/tests
   ```
4. **Open a pull request** to `main`. A teammate reviews it; anything touching another lane's file needs that lane's owner. No RTL merges without its golden-vector or spec test passing in CI.
5. **Record it.** Paste the PR link into the Planner task's comments (the course measures contribution against commit history), tick the checklist, and post one line in the daily check-in thread.

