# K5 — Board and dongle rota through Tue 1 Dec, including Thanksgiving

| | |
|---|---|
| **Owner** | Zhiting Li |
| **Due** | Tue 17 Nov |
| **Board bucket** | Bucket 1 — Kickoff and Merge |
| **Board task** | Board and dongle rota through Tue 1 Dec (incl. Thanksgiving) |
| **Needs first** | nothing |
| **Unblocks** | A2, D6, D7, D8, C8, A8 |
| **AI version** | `K5_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

We have two FPGA boards and two USB dongles for four people, and from Mon 23 Nov the team is spread across different places for a week. Hardware time is the scarcest thing in the project. If the wrong person has a board over the break, a week of hardware tasks stalls, and nobody can fix it until we're back.

So the rota follows the work. After the Thursday meeting, almost every task that needs a board belongs to two people: Zhiting (bring-up, timing, soak test, release) and Natalie (driver, both classifiers, hardware sweeps). Megan's remaining tasks are simulation only, and Ethan's hardware check is a script the board holders run.

Writing this down takes ten minutes and removes the most likely non-technical reason for missing the deadline.

## 2. Where the work goes

- **Record:** the Planner task's notes, and one line in the Thu 19 meeting log.
- **Safety procedure:** `docs/plans and specs/02-lane-a-interface/hardware.md` (the 3.3 V check).

## 3. How to do it

Proposed rota:

| Period | Board 1 + dongle 1 | Board 2 + dongle 2 |
|---|---|---|
| Mon 16 – Thu 19 | Zhiting (hardware gate) | Megan |
| Thu 19 meeting | both boards in the room | handed to Natalie |
| Thu 19 – Sun 29 | Zhiting (fit, timing, soak, release) | Natalie (driver, digits, sweeps) |
| Mon 30 dry run, Tue 1 Dec | both boards at the venue | both boards at the venue |

Steps:

1. Confirm the proposal with Megan and Natalie in the channel.
2. Each board holder writes where they'll be from Mon 23 to Sat 28. If a holder is travelling without the board, it goes to a teammate who's staying, and that's written down.
3. At the Thursday handover, Natalie checks her dongle's voltage jumper and meters its idle TX pin (about 3.3 V, never 5 V) before the first connection.
4. Pack a spare USB cable and spare jumper wires with each board.
5. Confirm transport for both boards to the dry run and the presentation.

## 4. How you know it's done

- The rota is in the Planner task and agreed by all four.
- Board 2 and dongle 2 are with Natalie after the Thu 19 meeting, and her dongle passed the 3.3 V check.
- Each board's location over the break is written down.
- Both boards are confirmed for Mon 30 and Tue 1 Dec.

## 5. Watch out for

- The DE10-Lite header is 3.3 V. A dongle set to 5 V can permanently damage the FPGA, and we can't replace a board in a holiday week.
- Each board should be flashed with the release image (A9) before it travels, so it boots the design without a programmer.
- If one board fails, the remaining one goes to whoever has the nearest hardware deadline. Agree that rule now.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

