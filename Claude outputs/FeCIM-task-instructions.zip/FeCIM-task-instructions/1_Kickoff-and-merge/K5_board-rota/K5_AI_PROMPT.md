# AI prompt — K5: Board and dongle rota through Tue 1 Dec, including Thanksgiving

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **K5 — Board and dongle rota through Tue 1 Dec, including Thanksgiving**, owned by Zhiting Li, due Tue 17 Nov.

Draft a short hardware rota message for the team channel: a table of who holds which board and dongle for each period up to the presentation, a request for each holder to state where they'll be over the Thanksgiving break, the handover checklist for Thursday (including the 3.3 V dongle check, with the reason for it), and what happens if a board fails. Use the proposed rota as the starting point and keep it under 200 words plus the table.

## Where the work goes

- **Record:** the Planner task's notes, and one line in the Thu 19 meeting log.
- **Safety procedure:** `docs/plans and specs/02-lane-a-interface/hardware.md` (the 3.3 V check).

## Steps the owner is following

Proposed rota:

| Period | Board 1 + dongle 1 | Board 2 + dongle 2 |
|---|---|---|
| Mon 16 – Thu 19 | Zhiting (hardware gate) | Megan |
| Thu 19 meeting | both boards in the room | handed to Natalie |
| Thu 19 – Sun 29 | Zhiting (fit, timing, soak, release) | Natalie (driver, digits, sweeps) |
| Mon 30 dry run, Tue 1 Dec | both boards at the venue | both boards at the venue |

Steps:

1. Confirm the proposal with Megan and Natalie in the channel.
2. Each board holder writes where they'll be from Mon 23 to Sat 28. If a holder is travelling without the board, it goes to a teammate who's staying, and that's written down.
3. At the Thursday handover, Natalie checks her dongle's voltage jumper and meters its idle TX pin (about 3.3 V, never 5 V) before the first connection.
4. Pack a spare USB cable and spare jumper wires with each board.
5. Confirm transport for both boards to the dry run and the presentation.

## What done looks like

- The rota is in the Planner task and agreed by all four.
- Board 2 and dongle 2 are with Natalie after the Thu 19 meeting, and her dongle passed the 3.3 V check.
- Each board's location over the break is written down.
- Both boards are confirmed for Mon 30 and Tue 1 Dec.

## Things to keep in mind

- The DE10-Lite header is 3.3 V. A dongle set to 5 V can permanently damage the FPGA, and we can't replace a board in a holiday week.
- Each board should be flashed with the release image (A9) before it travels, so it boots the design without a programmer.
- If one board fails, the remaining one goes to whoever has the nearest hardware deadline. Agree that rule now.

## What to give the model along with this prompt

- The proposed rota table above
- Each teammate's travel plans for Mon 23 – Sat 28 Nov, if known
- The 3.3 V check steps from `hardware.md`

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

