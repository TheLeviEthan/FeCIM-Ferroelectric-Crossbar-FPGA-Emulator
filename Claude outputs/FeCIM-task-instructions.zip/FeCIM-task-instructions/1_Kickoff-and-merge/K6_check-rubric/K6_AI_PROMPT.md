# AI prompt — K6: Check the rubric, time limit, format, peer-evaluation and report due dates

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **K6 — Check the rubric, time limit, format, peer-evaluation and report due dates**, owned by Ethan Ruddell, due Tue 17 Nov.

Draft a short, polite email to the course instructor asking the specific logistics questions that aren't answered by the posted course materials, and a template for the pinned team post that will record the answers. The email should be easy to answer point by point: number the questions and keep each to one line.

## Where the work goes

- **Look in:** the course's Canvas page (assignments, syllabus, announcements) and any email from the instructor.
- **Record:** the Planner task notes and a pinned post in the team channel.
- **Then update:** dates in Planner buckets 7 and 8 if anything differs from the board.

## Steps the owner is following

Find and write down the answer to each question, with where you found it:

1. Presentation date, time and room. Is it in person?
2. Time limit, and whether questions are inside or outside it.
3. Is a live demo expected, optional or not allowed? Is a demo video required?
4. Required slide sections or a template, if any.
5. The grading rubric: categories and weights.
6. Is a written report due? When, what length, what format?
7. Peer evaluations: required? When and where?
8. What has to be in the repository for the semester-1 milestone, and by what date and time.
9. Is the team presenting as four speakers, and does each member need to speak?

If something isn't posted, email the instructor on Monday with the specific questions, and note in the task that you're waiting.

Then post the answers and say explicitly whether any board date changes.

## What done looks like

- All nine answers are written down with their source, or marked as asked and awaiting a reply.
- A pinned post in the channel gives the confirmed date, time limit and deliverables.
- Planner dates in buckets 7 and 8 match the confirmed dates.
- Any newly discovered deliverable (report, peer evaluation, video) has an owner and a due date.

## Things to keep in mind

- If the presentation is Mon 30 Nov, the dry run moves to Sun 29 and the merge cutoff to Sat 28 at 18:00. Tell the team the same day.
- A written report can mostly be assembled from documents the board already produces: the verification report (C10), the utilization report (B9), the calibration section (C6) and the design-corrections content (P3).

## What to give the model along with this prompt

- The list of nine questions above, with any already answered removed
- Whatever the course page says about the presentation and deliverables (paste the text)

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

