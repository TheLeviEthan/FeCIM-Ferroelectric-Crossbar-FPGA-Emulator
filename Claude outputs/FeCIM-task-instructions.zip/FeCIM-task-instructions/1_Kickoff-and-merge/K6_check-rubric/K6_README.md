# K6 — Check the rubric, time limit, format, peer-evaluation and report due dates

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Tue 17 Nov |
| **Board bucket** | Bucket 1 — Kickoff and Merge |
| **Board task** | Check rubric, time limit, format, peer-eval and written-report due dates |
| **Needs first** | nothing |
| **Unblocks** | P1–P5, X3, X6, and every date on the board |
| **AI version** | `K6_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Every date on the board counts back from the presentation, and the presentation date on the board is an assumption: Tuesday 1 December, in the usual class slot. If it's actually Monday, everything in the last three days moves. If a written report or peer evaluations are due the same day, that's work nobody has been assigned.

The rubric also tells us what's being graded. If a live demo is expected, the recordings are a backup. If demos aren't allowed, the video becomes the main event. If there's a ten-minute limit, the deck is half the size we'd otherwise build. Finding that out on day one is free. Finding it out on Sunday night means redoing the slides.

## 2. Where the work goes

- **Look in:** the course's Canvas page (assignments, syllabus, announcements) and any email from the instructor.
- **Record:** the Planner task notes and a pinned post in the team channel.
- **Then update:** dates in Planner buckets 7 and 8 if anything differs from the board.

## 3. How to do it

Find and write down the answer to each question, with where you found it:

1. Presentation date, time and room. Is it in person?
2. Time limit, and whether questions are inside or outside it.
3. Is a live demo expected, optional or not allowed? Is a demo video required?
4. Required slide sections or a template, if any.
5. The grading rubric: categories and weights.
6. Is a written report due? When, what length, what format?
7. Peer evaluations: required? When and where?
8. What has to be in the repository for the semester-1 milestone, and by what date and time.
9. Is the team presenting as four speakers, and does each member need to speak?

If something isn't posted, email the instructor on Monday with the specific questions, and note in the task that you're waiting.

Then post the answers and say explicitly whether any board date changes.

## 4. How you know it's done

- All nine answers are written down with their source, or marked as asked and awaiting a reply.
- A pinned post in the channel gives the confirmed date, time limit and deliverables.
- Planner dates in buckets 7 and 8 match the confirmed dates.
- Any newly discovered deliverable (report, peer evaluation, video) has an owner and a due date.

## 5. Watch out for

- If the presentation is Mon 30 Nov, the dry run moves to Sun 29 and the merge cutoff to Sat 28 at 18:00. Tell the team the same day.
- A written report can mostly be assembled from documents the board already produces: the verification report (C10), the utilization report (B9), the calibration section (C6) and the design-corrections content (P3).

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

