# K1 — Agree the semester-1 completion plan, owners, rebalance and async check-ins

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Tue 17 Nov |
| **Board bucket** | Bucket 1 — Kickoff and Merge |
| **Board task** | Agree semester-1 completion plan, owners, rebalance and async check-ins |
| **Needs first** | nothing |
| **Unblocks** | every other task |
| **AI version** | `K1_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

Two weeks, four people, about fifty tasks, and only one more in-person meeting before the dry run. A plan like that only works if everyone has actually agreed to it, knows which tasks are theirs, and knows who is waiting on them.

This task is the agreement. It's short, and it's the first thing on the board because everything else assumes it happened. It also settles three specific decisions that change who does what: moving `argmax_unit` from Megan to Zhiting, checking in every day in writing because we can't meet, and holding AI-drafted code to the same test evidence as hand-written code.

For the course, a dated record that the team chose this scope and these owners is evidence of project management. Without the record, it's just something we say we did.

## 2. Where the work goes

- **Post:** the team's Teams channel, with `semester1-planner-board-rev3.md` and this instruction pack attached.
- **Track:** the Planner plan `FeCIM — Capstone`, one bucket per section of the board.
- **Record:** the meeting log for Thu 19 Nov (see X5 for where logs are committed).

## 3. How to do it

1. Monday: post the board, the pack and a five-line summary (template below). Ask for a thumbs-up or an objection from each person by Tuesday night.
2. Create the Planner buckets and tasks from the board, one assignee each, with due dates. Paste each task's checklist.
3. Create a thread called "Daily check-in". Each person posts once a day, weekends and the break included:

   ```text
   Done:    <PR links merged or opened since the last post>
   Today:   <task ID and what "done" will look like>
   Blocked: <who or what; "none" if nothing>
   ```

4. Put the three decisions to the team explicitly:
   - `argmax_unit` (A4) moves to Zhiting, with Megan reviewing.
   - A missed checkpoint triggers a swarm: anyone whose own Gate tasks are done helps the owner the next day.
   - No RTL merges without its golden-vector or spec test passing in CI; no model change without unit tests and a mutation check.
5. Thursday: re-confirm at the meeting, and write the outcome into the meeting log.

Kickoff post template:

```text
Semester-1 completion plan (rev 3) is attached, plus a folder of instructions for every task.
- Scope: full 128x128 / 64-lane design, all six non-idealities, calibrated to set A, linear + MLP digits, on the board.
- Key dates: Thu 19 in-person (hardware gate) · Sat 21 L0 · Mon 23 L1/L2 · Wed 25 hardware match · Fri 27 virtual sync · Sat 28 everything done · Sun 29 18:00 merge cutoff · Mon 30 dry run · Tue 1 Dec presentation.
- Your tasks are in your lane's folder. Each has a README for you and an AI prompt.
- Three decisions need your OK: (1) argmax_unit moves to Zhiting, (2) daily written check-ins, (3) no merge without passing test evidence.
- Please reply with a thumbs-up or your objection by Tuesday night.
```

## 4. How you know it's done

- All four have agreed in writing by Tue 17.
- Every board task exists in Planner with one owner and a due date.
- The check-in thread exists and has a first post from each person.
- The three decisions are recorded as agreed or rejected, and re-confirmed in the Thu 19 meeting log.

## 5. Watch out for

- The pack's `00_START_HERE.md` lists corrections to the board found while writing the instructions. Raise them in the kickoff post so nobody builds from the older wording.
- If someone objects to their load, rebalance now. Finding out on Mon 23 is too late.
- The presentation date is assumed to be Tue 1 Dec; K6 confirms it.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

