# AI prompt — K1: Agree the semester-1 completion plan, owners, rebalance and async check-ins

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **K1 — Agree the semester-1 completion plan, owners, rebalance and async check-ins**, owned by Ethan Ruddell, due Tue 17 Nov.

Draft the kickoff message for the team channel and a one-page agenda item for confirming the plan at the Thursday meeting. The message should summarize scope and key dates in a few lines, tell each person where their tasks are, list the three decisions that need agreement, and ask for a reply by Tuesday night. Keep the tone direct and friendly; these are four classmates, not a client.

## Where the work goes

- **Post:** the team's Teams channel, with `semester1-planner-board-rev3.md` and this instruction pack attached.
- **Track:** the Planner plan `FeCIM — Capstone`, one bucket per section of the board.
- **Record:** the meeting log for Thu 19 Nov (see X5 for where logs are committed).

## Steps the owner is following

1. Monday: post the board, the pack and a five-line summary (template below). Ask for a thumbs-up or an objection from each person by Tuesday night.
2. Create the Planner buckets and tasks from the board, one assignee each, with due dates. Paste each task's checklist.
3. Create a thread called "Daily check-in". Each person posts once a day, weekends and the break included:

   ```text
   Done:    <PR links merged or opened since the last post>
   Today:   <task ID and what "done" will look like>
   Blocked: <who or what; "none" if nothing>
   ```

4. Put the three decisions to the team explicitly:
   - `argmax_unit` (A4) moves to Zhiting, with Megan reviewing.
   - A missed checkpoint triggers a swarm: anyone whose own Gate tasks are done helps the owner the next day.
   - No RTL merges without its golden-vector or spec test passing in CI; no model change without unit tests and a mutation check.
5. Thursday: re-confirm at the meeting, and write the outcome into the meeting log.

Kickoff post template:

```text
Semester-1 completion plan (rev 3) is attached, plus a folder of instructions for every task.
- Scope: full 128x128 / 64-lane design, all six non-idealities, calibrated to set A, linear + MLP digits, on the board.
- Key dates: Thu 19 in-person (hardware gate) · Sat 21 L0 · Mon 23 L1/L2 · Wed 25 hardware match · Fri 27 virtual sync · Sat 28 everything done · Sun 29 18:00 merge cutoff · Mon 30 dry run · Tue 1 Dec presentation.
- Your tasks are in your lane's folder. Each has a README for you and an AI prompt.
- Three decisions need your OK: (1) argmax_unit moves to Zhiting, (2) daily written check-ins, (3) no merge without passing test evidence.
- Please reply with a thumbs-up or your objection by Tuesday night.
```

## What done looks like

- All four have agreed in writing by Tue 17.
- Every board task exists in Planner with one owner and a due date.
- The check-in thread exists and has a first post from each person.
- The three decisions are recorded as agreed or rejected, and re-confirmed in the Thu 19 meeting log.

## Things to keep in mind

- The pack's `00_START_HERE.md` lists corrections to the board found while writing the instructions. Raise them in the kickoff post so nobody builds from the older wording.
- If someone objects to their load, rebalance now. Finding out on Mon 23 is too late.
- The presentation date is assumed to be Tue 1 Dec; K6 confirms it.

## What to give the model along with this prompt

- `semester1-planner-board-rev3.md`
- `00_START_HERE.md` from this pack (for the corrections list)
- Any constraints teammates have already mentioned (travel dates, exams)

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

