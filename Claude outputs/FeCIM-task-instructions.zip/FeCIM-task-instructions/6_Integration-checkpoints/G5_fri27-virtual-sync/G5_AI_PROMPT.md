# AI prompt — G5: Fri 27 virtual sync (Teams): L4, MLP, plots, slides

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **G5 — Fri 27 virtual sync (Teams): L4, MLP, plots, slides**, owned by Ethan Ruddell, due Fri 27 Nov.

Draft the agenda post for this call and a log template with a row per agenda item. Then, if given notes from the call, produce the finished log and a per-person list of what each must finish by Saturday night, in priority order. Don't add items that aren't in the notes.

## Where the work goes

- **Call:** Teams, 30 to 45 minutes, at the time agreed on Thu 19. Board holders share their screens.
- **Log:** `docs/meetings/2026-11-27.md`.
- **Review material:** the shared slide deck, `docs/img/plots/`, the Planner board.

## Steps the owner is following

| Min | Item | Who shares | Decide |
|---|---|---|---|
| 0–8 | Hardware status: L4 on both boards, soak test progress | Zhiting | anything not matching? |
| 8–18 | MLP on the board, live | Natalie | does it match `sim`? time per image? |
| 18–28 | Plots: each sweep, axes, set-A markers, hardware and `sim` overlay | Natalie + Ethan | final axes; which plots go on slides |
| 28–38 | Slide deck, section by section | each owner | gaps and contradictions; who fixes what by Saturday |
| 38–45 | Planner board: every Must task not yet Completed | Ethan | finish, get help, or cut and disclose |

Before the call, each person marks their Planner tasks honestly: Completed, in progress, or at risk.

For anything that won't be done by Saturday night, decide on the call: finish it with a named helper, or cut it. A cut item gets one honest line on the design-corrections slide (P3).

## What done looks like

- Every agenda row has an outcome in the log.
- Every open Must task has one of three labels: on track for Sat 28, helper assigned, or cut and disclosed.
- Plot axes and the list of plots for the slides are final.
- Each slide section has an owner and a list of fixes due Saturday.
- The log is committed.

## Things to keep in mind

- Keep it short. People are with their families; a focused 40 minutes will be attended, and a two-hour call won't.
- Screen-share real output: a board, a terminal, a plot. A status described in words is where surprises hide.
- If the MLP isn't running on hardware yet, the linear classifier on hardware plus the MLP on `sim` is a legitimate thing to present. Decide that here.

## What to give the model along with this prompt

- The agenda table above
- An export or screenshot of the Planner board's open tasks
- Notes from the call, when turning them into the log

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

