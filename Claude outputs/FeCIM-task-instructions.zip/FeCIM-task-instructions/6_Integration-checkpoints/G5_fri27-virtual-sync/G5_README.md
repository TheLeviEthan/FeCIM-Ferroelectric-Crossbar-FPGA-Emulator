# G5 — Fri 27 virtual sync (Teams): L4, MLP, plots, slides

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Fri 27 Nov |
| **Board bucket** | Bucket 6 — Integration Checkpoints |
| **Board task** | Fri 27 virtual sync (Teams): L4, MLP, plots, slides |
| **Needs first** | G4; drafts from D7, D8, P1 |
| **Unblocks** | Sat 28 completion, P5 rehearsal |
| **AI version** | `G5_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

The usual Thursday meeting falls on Thanksgiving, so there's a whole week with no scheduled time when the four of us look at the same thing together. Daily written check-ins keep tasks moving. They don't catch the problems that only show up when someone else looks at your screen: a plot whose axis nobody else can read, a slide that contradicts another slide, a demo that works on one board and hasn't been tried on the other.

This call is that look. It's two days before the merge cutoff, which is late enough that there's real work to review and early enough to fix what the review finds. It's also the last sensible moment to decide that something won't make it, and to say so honestly in the slides instead of patching it on Sunday night.

## 2. Where the work goes

- **Call:** Teams, 30 to 45 minutes, at the time agreed on Thu 19. Board holders share their screens.
- **Log:** `docs/meetings/2026-11-27.md`.
- **Review material:** the shared slide deck, `docs/img/plots/`, the Planner board.

## 3. How to do it

| Min | Item | Who shares | Decide |
|---|---|---|---|
| 0–8 | Hardware status: L4 on both boards, soak test progress | Zhiting | anything not matching? |
| 8–18 | MLP on the board, live | Natalie | does it match `sim`? time per image? |
| 18–28 | Plots: each sweep, axes, set-A markers, hardware and `sim` overlay | Natalie + Ethan | final axes; which plots go on slides |
| 28–38 | Slide deck, section by section | each owner | gaps and contradictions; who fixes what by Saturday |
| 38–45 | Planner board: every Must task not yet Completed | Ethan | finish, get help, or cut and disclose |

Before the call, each person marks their Planner tasks honestly: Completed, in progress, or at risk.

For anything that won't be done by Saturday night, decide on the call: finish it with a named helper, or cut it. A cut item gets one honest line on the design-corrections slide (P3).

## 4. How you know it's done

- Every agenda row has an outcome in the log.
- Every open Must task has one of three labels: on track for Sat 28, helper assigned, or cut and disclosed.
- Plot axes and the list of plots for the slides are final.
- Each slide section has an owner and a list of fixes due Saturday.
- The log is committed.

## 5. Watch out for

- Keep it short. People are with their families; a focused 40 minutes will be attended, and a two-hour call won't.
- Screen-share real output: a board, a terminal, a plot. A status described in words is where surprises hide.
- If the MLP isn't running on hardware yet, the linear classifier on hardware plus the MLP on `sim` is a legitimate thing to present. Decide that here.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

