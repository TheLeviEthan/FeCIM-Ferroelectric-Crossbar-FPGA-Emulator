# G3 — Checkpoint: L1 and L2 green in full-top co-simulation; first fit done

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Mon 23 Nov |
| **Board bucket** | Bucket 6 — Integration Checkpoints |
| **Board task** | Checkpoint: L1 + L2 green in full-top co-sim; first fit done |
| **Needs first** | C5, A5, B3, B5, B6, B7 |
| **Unblocks** | A7, C8, D6 on hardware, the whole break schedule |
| **AI version** | `G3_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

This is the point where the design is finished in simulation. The complete RTL, driven through its own UART by the real host encoder, matches the model byte for byte with each non-ideality alone (L1) and with all six together (L2). And the same RTL has been through the fitter and fits in the chip.

It's placed on the Monday before Thanksgiving on purpose. Everything after it is hardware bring-up, applications, plots and documents, which four people can do in four different places. Everything before it needs tight coordination between lanes. If this checkpoint holds, the break is productive. If it slips, people are debugging cross-lane RTL problems remotely over a holiday, which is the slowest way to do it.

The fit matters at the same moment for a different reason: it's the first time we learn whether all six non-idealities together actually fit the multiplier budget.

## 2. Where the work goes

- **Simulation:** `./model/cosim/run_top` with the full stimulus (task C5).
- **Fit:** `quartus/reports/fecim.fit.summary` (task A5).
- **Post:** the team channel and the Planner task, with commit hashes.

## 3. How to do it

1. Run the full L1/L2 matrix on `main`. Record the pass/fail line for each row: clean; quant; D2D; read noise; stuck (both modes); ADC; IR; all enabled; each tile size.
2. Zhiting posts the three fit numbers: logic elements, M9K blocks, multiplier blocks.
3. Post a combined status:

   ```text
   L1: quant PASS · d2d PASS · read PASS · stuck PASS · adc PASS · ir PASS
   L2: all six, 100 random configs  PASS
   Fit: <LE> / 49,760 LE · <n> / 182 M9K · <n> / 144 multiplier blocks   commit <hash>
   ```

4. For any row that fails, post the first mismatch and decide, the same day, between two options: fix it before the break, or carry it into the break with a named owner and a helper.
5. If the fit fails at 64 lanes, decide now whether to fall back to 32 lanes, and tell Ethan so the model follows.

## 4. How you know it's done

- Every L1 row and L2 are reported, with commit hash.
- The fit numbers are posted and the multiplier count is at or near 72.
- Any failing row has an owner, a helper and a date.
- The short L1/L2 run is blocking in CI.

## 5. Watch out for

- An L1 failure points at one module. An L2 failure with every L1 row passing points at an interaction, most often ordering: something applied in a different sequence in the RTL than in the model.
- A fit made before every non-ideality is merged understates the resource use. Re-run it after the last RTL merge.
- Don't let a partial pass be reported as a pass. "Five of six" is a fail with a known location.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

