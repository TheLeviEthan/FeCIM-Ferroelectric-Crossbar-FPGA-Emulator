# AI prompt — G3: Checkpoint: L1 and L2 green in full-top co-simulation; first fit done

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **G3 — Checkpoint: L1 and L2 green in full-top co-simulation; first fit done**, owned by Ethan Ruddell, due Mon 23 Nov.

From the co-simulation output and fitter summary provided, write the checkpoint status post: one line per verification row with pass or fail, the L2 result, and the three resource numbers against the device limits. For each failure, describe the first mismatch in plain language and say whether it points at a single module (L1) or an interaction (L2). Use only the numbers in the material given.

## Where the work goes

- **Simulation:** `./model/cosim/run_top` with the full stimulus (task C5).
- **Fit:** `quartus/reports/fecim.fit.summary` (task A5).
- **Post:** the team channel and the Planner task, with commit hashes.

## Steps the owner is following

1. Run the full L1/L2 matrix on `main`. Record the pass/fail line for each row: clean; quant; D2D; read noise; stuck (both modes); ADC; IR; all enabled; each tile size.
2. Zhiting posts the three fit numbers: logic elements, M9K blocks, multiplier blocks.
3. Post a combined status:

   ```text
   L1: quant PASS · d2d PASS · read PASS · stuck PASS · adc PASS · ir PASS
   L2: all six, 100 random configs  PASS
   Fit: <LE> / 49,760 LE · <n> / 182 M9K · <n> / 144 multiplier blocks   commit <hash>
   ```

4. For any row that fails, post the first mismatch and decide, the same day, between two options: fix it before the break, or carry it into the break with a named owner and a helper.
5. If the fit fails at 64 lanes, decide now whether to fall back to 32 lanes, and tell Ethan so the model follows.

## What done looks like

- Every L1 row and L2 are reported, with commit hash.
- The fit numbers are posted and the multiplier count is at or near 72.
- Any failing row has an owner, a helper and a date.
- The short L1/L2 run is blocking in CI.

## Things to keep in mind

- An L1 failure points at one module. An L2 failure with every L1 row passing points at an interaction, most often ordering: something applied in a different sequence in the RTL than in the model.
- A fit made before every non-ideality is merged understates the resource use. Re-run it after the last RTL merge.
- Don't let a partial pass be reported as a pass. "Five of six" is a fail with a known location.

## What to give the model along with this prompt

- The output of the full `run_top` matrix
- `quartus/reports/fecim.fit.summary`
- The commit hashes for both

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

