# G2 — Checkpoint: full-array L0 green

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Sat 21 Nov |
| **Board bucket** | Bucket 6 — Integration Checkpoints |
| **Board task** | Checkpoint: full-array L0 green |
| **Needs first** | C4; B1, B2, B4 merged |
| **Unblocks** | C5, B7, B8; everything that enables a non-ideality |
| **AI version** | `G2_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

L0 is the statement "with every non-ideality switched off, the hardware array computes exactly the right integers". All 64 lanes, both passes, a thousand random full-size matrices, compared every clock cycle.

It's a checkpoint, and not just one more test, because of what it licenses. Every later claim has the form "turning on effect X changed the result by this much". That only means something if the result *without* X is known to be exact. If the clean path has a bug, it contaminates every noise measurement, and it looks like a noise effect.

So the rule is strict: until L0 is green, nobody builds on top of it. No non-ideality debugging, no hardware runs of the full array, no sweeps.

## 2. Where the work goes

- **The run:** `make -C model/cosim run_l0_array && ./model/cosim/run_l0_array 1 1000` (task C4).
- **Post the result:** the team channel and the Planner task.
- **Evidence:** the command, the commit hash and the last lines of output, pasted into the task; later linked from the coverage matrix (C10).

## 3. How to do it

1. Confirm the inputs are merged: `mac_lane` with read noise integrated (B4), `mac_array`, and the model's `step()` (C3).
2. Run the full 1,000-matrix L0 on the merged `main`, not on a branch.
3. Run the smaller tile sizes: 8×8, 48×48, 64×64.
4. Post the result in the channel in this form:

   ```text
   L0 full array: PASS  (1000 matrices, 128x128, NOISE_EN=0)   commit <hash>   runtime <t>
   also PASS at 8x8, 48x48, 64x64
   ```

5. If it fails: post the first mismatch (matrix, cycle, lane, signal, expected, actual) and name who's looking at it. Sunday becomes a swarm on that one problem.

## 4. How you know it's done

- The full run passes on `main` and the result is posted with its commit hash.
- The short version is in CI and green.
- If it failed, the first mismatch and an owner were posted the same day.

## 5. Watch out for

- A pass on someone's branch doesn't count. Run it on `main` after the merges.
- The harness plays the sequencer and the activation buffer itself, so a green L0 doesn't say anything about `control_fsm` or `act_buffer`. Those are covered by B7 and C5.
- If L0 can't be run by Saturday because a dependency hasn't merged, that's the thing to report. Say which PR is blocking.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

