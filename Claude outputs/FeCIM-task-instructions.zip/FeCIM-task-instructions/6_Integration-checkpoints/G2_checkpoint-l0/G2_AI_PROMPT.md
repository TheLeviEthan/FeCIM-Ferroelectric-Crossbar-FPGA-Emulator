# AI prompt — G2: Checkpoint: full-array L0 green

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **G2 — Checkpoint: full-array L0 green**, owned by Ethan Ruddell, due Sat 21 Nov.

Write the short status post for this checkpoint from the test output provided: pass or fail, what was run, on which commit, and how long it took. If it failed, summarize the first mismatch in one or two plain sentences (which lane, which pipeline stage, which cycle) and suggest which module to look at first and why, based only on the output given.

## Where the work goes

- **The run:** `make -C model/cosim run_l0_array && ./model/cosim/run_l0_array 1 1000` (task C4).
- **Post the result:** the team channel and the Planner task.
- **Evidence:** the command, the commit hash and the last lines of output, pasted into the task; later linked from the coverage matrix (C10).

## Steps the owner is following

1. Confirm the inputs are merged: `mac_lane` with read noise integrated (B4), `mac_array`, and the model's `step()` (C3).
2. Run the full 1,000-matrix L0 on the merged `main`, not on a branch.
3. Run the smaller tile sizes: 8×8, 48×48, 64×64.
4. Post the result in the channel in this form:

   ```text
   L0 full array: PASS  (1000 matrices, 128x128, NOISE_EN=0)   commit <hash>   runtime <t>
   also PASS at 8x8, 48x48, 64x64
   ```

5. If it fails: post the first mismatch (matrix, cycle, lane, signal, expected, actual) and name who's looking at it. Sunday becomes a swarm on that one problem.

## What done looks like

- The full run passes on `main` and the result is posted with its commit hash.
- The short version is in CI and green.
- If it failed, the first mismatch and an owner were posted the same day.

## Things to keep in mind

- A pass on someone's branch doesn't count. Run it on `main` after the merges.
- The harness plays the sequencer and the activation buffer itself, so a green L0 doesn't say anything about `control_fsm` or `act_buffer`. Those are covered by B7 and C5.
- If L0 can't be run by Saturday because a dependency hasn't merged, that's the thing to report. Say which PR is blocking.

## What to give the model along with this prompt

- The terminal output of the L0 run
- The commit hash it ran on
- `model/cosim/README.md` (for what the harness covers)

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

