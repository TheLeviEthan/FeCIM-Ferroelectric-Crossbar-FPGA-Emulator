# AI prompt — G1: Thu 19 meeting: hardware gate, vectors delivered, port lists frozen

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **G1 — Thu 19 meeting: hardware gate, vectors delivered, port lists frozen**, owned by Ethan Ruddell, due Thu 19 Nov.

Draft the agenda post for this meeting and a meeting-log template that can be filled in during it. The log should have a row per agenda item with fields for outcome, decision, owner and date, a section for the four cross-lane technical decisions (one sentence each), and an action list. Then, if you're given rough notes from the meeting, turn them into the finished log without adding anything that isn't in the notes.

## Where the work goes

- **Agenda:** posted in the team channel the day before.
- **Log:** `docs/meetings/2026-11-19.md` (the folder doesn't exist yet; X5 creates it).
- **Bring:** both boards, both dongles, a multimeter, laptops with the latest `main`.

## Steps the owner is following

Suggested agenda, 60 to 75 minutes:

| Min | Item | Owner | Outcome to record |
|---|---|---|---|
| 0–15 | **Hardware gate, live:** `IDENTIFY`, a register write and read-back, baud switch to 921600 | Zhiting + Natalie | pass or fail; if fail, what's missing |
| 15–25 | Golden vectors: C1 and C2 delivered? B1 passing against them? | Ethan + Megan | status of B1–B6 |
| 25–35 | `control_fsm` merged? Cycle count agrees with the model's? Open timing questions (drain shift, read-noise alignment, `argmax_second`, soft reset) | Zhiting + Megan + Ethan | each decision in one sentence |
| 35–40 | Port lists frozen (K4) | Zhiting | any late change |
| 40–50 | Scope and the three kickoff decisions re-confirmed | Ethan | agreed or changed |
| 50–55 | Board 2 and dongle 2 to Natalie; 3.3 V check; Thanksgiving locations | Zhiting | rota confirmed |
| 55–65 | Slide section owners; time of the Fri 27 virtual sync | Ethan | names and a time |
| 65–75 | Anything at risk: assign a named helper today | all | who helps whom |

Before the meeting, each person posts their status against their Thursday tasks so the meeting spends its time on decisions.

After the meeting, the log goes into the repo the same day, and every decision that changes a spec gets a one-line spec edit.

## What done looks like

- `IDENTIFY` ran live on the board, or the gap is identified with an owner and a date.
- Every item in the table has a recorded outcome.
- The four cross-lane timing decisions are written down in one sentence each, and in the relevant spec.
- Board 2 is with Natalie; slide owners are named; the Fri 27 time is set.
- The meeting log is committed.

## Things to keep in mind

- **If the hardware gate fails,** don't spend the whole meeting debugging it. Take fifteen minutes, write down what's known, and keep the board with Zhiting afterwards. The most likely cause is the missing reply payload described in A2.
- Decisions made out loud and not written down will be remembered four different ways by Monday.
- This is the natural moment to move work if one lane is overloaded.

## What to give the model along with this prompt

- The agenda table above
- Each person's status post from the day before
- Rough notes from the meeting, when turning them into the log

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

