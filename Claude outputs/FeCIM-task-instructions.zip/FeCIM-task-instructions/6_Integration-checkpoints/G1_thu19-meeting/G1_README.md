# G1 — Thu 19 meeting: hardware gate, vectors delivered, port lists frozen

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Thu 19 Nov |
| **Board bucket** | Bucket 6 — Integration Checkpoints |
| **Board task** | Thu 19 meeting: hardware gate, vectors delivered, port lists frozen |
| **Needs first** | K1–K6; A1, A2, C1, C2, D2 in progress or done |
| **Unblocks** | board 2 handover, slide ownership, the weekend's integration work |
| **AI version** | `G1_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

This is the last time all four of us and both boards are in the same room before the dry run on 30 November. Anything that needs hands on hardware, or a decision made face to face, has to happen here.

The centrepiece is the hardware gate: Natalie's driver sends `IDENTIFY` and Zhiting's bitstream answers, live. That single exchange proves the cable, the baud rate, the UART, the packet parser, the checksum, the register file and the Python driver all work together. It was the plan's highest-risk milestone and it's been open since week 3.

The meeting is also the first checkpoint on the plan itself. Three days in, we can see whether the front-loaded work actually landed: the golden vectors, the sequencer, the frozen port lists. If something slipped, this is the cheapest moment to move people around.

## 2. Where the work goes

- **Agenda:** posted in the team channel the day before.
- **Log:** `docs/meetings/2026-11-19.md` (the folder doesn't exist yet; X5 creates it).
- **Bring:** both boards, both dongles, a multimeter, laptops with the latest `main`.

## 3. How to do it

Suggested agenda, 60 to 75 minutes:

| Min | Item | Owner | Outcome to record |
|---|---|---|---|
| 0–15 | **Hardware gate, live:** `IDENTIFY`, a register write and read-back, baud switch to 921600 | Zhiting + Natalie | pass or fail; if fail, what's missing |
| 15–25 | Golden vectors: C1 and C2 delivered? B1 passing against them? | Ethan + Megan | status of B1–B6 |
| 25–35 | `control_fsm` merged? Cycle count agrees with the model's? Open timing questions (drain shift, read-noise alignment, `argmax_second`, soft reset) | Zhiting + Megan + Ethan | each decision in one sentence |
| 35–40 | Port lists frozen (K4) | Zhiting | any late change |
| 40–50 | Scope and the three kickoff decisions re-confirmed | Ethan | agreed or changed |
| 50–55 | Board 2 and dongle 2 to Natalie; 3.3 V check; Thanksgiving locations | Zhiting | rota confirmed |
| 55–65 | Slide section owners; time of the Fri 27 virtual sync | Ethan | names and a time |
| 65–75 | Anything at risk: assign a named helper today | all | who helps whom |

Before the meeting, each person posts their status against their Thursday tasks so the meeting spends its time on decisions.

After the meeting, the log goes into the repo the same day, and every decision that changes a spec gets a one-line spec edit.

## 4. How you know it's done

- `IDENTIFY` ran live on the board, or the gap is identified with an owner and a date.
- Every item in the table has a recorded outcome.
- The four cross-lane timing decisions are written down in one sentence each, and in the relevant spec.
- Board 2 is with Natalie; slide owners are named; the Fri 27 time is set.
- The meeting log is committed.

## 5. Watch out for

- **If the hardware gate fails,** don't spend the whole meeting debugging it. Take fifteen minutes, write down what's known, and keep the board with Zhiting afterwards. The most likely cause is the missing reply payload described in A2.
- Decisions made out loud and not written down will be remembered four different ways by Monday.
- This is the natural moment to move work if one lane is overloaded.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

