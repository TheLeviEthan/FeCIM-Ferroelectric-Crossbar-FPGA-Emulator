# G4 — Checkpoint: L4 green on hardware (all six, bit-exact), timing met

| | |
|---|---|
| **Owner** | Zhiting Li |
| **Due** | Wed 25 Nov |
| **Board bucket** | Bucket 6 — Integration Checkpoints |
| **Board task** | Checkpoint: L4 green on hardware (all six, bit-exact), timing met |
| **Needs first** | A7, C8, D2, D3 |
| **Unblocks** | D6–D8 on hardware, A8, A9 |
| **AI version** | `G4_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

This is the moment the project's central claim becomes true: the physical board, running the real bitstream at 50 MHz, produces exactly the numbers the model predicts, for every non-ideality, at the same seed.

Until now, "the hardware matches the model" has been an expectation based on simulation. Simulation doesn't model wire delay, a marginal cable or a mis-assigned pin. Two things close that gap. Timing analysis shows every path settles inside the 20 ns clock period. And the hardware-versus-model script shows that the answers match, bit for bit, on real silicon.

After this checkpoint, every number that comes off the board can be trusted as much as a number from the model. The classifier accuracy, the sweeps and the plots all inherit that trust. Before it, they don't.

## 2. Where the work goes

- **Timing:** `quartus/reports/fecim.sta.summary` (task A7).
- **Hardware check:** `python sw/examples/check_hw_vs_model.py --backend fpga --port <port>` (task C8), run on both boards.
- **Log:** `results/l4/`, committed.
- **Post:** the team channel and the Planner task.

## 3. How to do it

1. Build the bitstream from `main` with the timing constraints. Record setup and hold slack at the slow corner.
2. Program board 1. Confirm `IDENTIFY` reports the expected `BUILD_ID`.
3. Run the full hardware check matrix. It prints one line per case and a final `PASS n/n`.
4. Send the same bitstream to Natalie; she repeats steps 2 and 3 on board 2.
5. Check `CYCLE_CNT` reads 392 for a full-tile compute.
6. Commit the log and post:

   ```text
   Timing: setup slack <x> ns, hold slack <y> ns (slow 85C)   build <id>   commit <hash>
   L4 board 1: PASS n/n     L4 board 2: PASS n/n     CYCLE_CNT = 392
   ```

If a case fails on hardware but passed in simulation, check in this order: the bitstream is the one you think it is (`BUILD_ID`); timing slack is positive; the identify block's error counters are zero; then run the failing case at 115200 baud to rule out the link.

## 4. How you know it's done

- Positive setup and hold slack at the slow corner, with the report committed.
- The full matrix passes on both boards with the same bitstream.
- `CYCLE_CNT` matches the model.
- The log is committed and the result is posted with build ID and commit hash.

## 5. Watch out for

- **A mismatch only when read noise is enabled** usually means a missing reseed or a different order of operations on the two backends, not a hardware fault.
- **A mismatch that comes and goes** points at timing or the link. A consistent mismatch points at logic.
- If this slips past Wed 25, the hardware classifier runs and sweeps slip with it. Say so immediately; the `sim`-backend versions of D6–D8 can proceed regardless.
- Both boards should carry the same bitstream from here to the presentation.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

