# AI prompt — G4: Checkpoint: L4 green on hardware (all six, bit-exact), timing met

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **G4 — Checkpoint: L4 green on hardware (all six, bit-exact), timing met**, owned by Zhiting Li, due Wed 25 Nov.

From the timing summary and hardware-check logs provided, write the checkpoint status post, and if any case failed, a short diagnosis plan. Classify each failure as consistent or intermittent from the logs, relate it to the enabled non-idealities, and list the checks to make in order (bitstream identity, timing slack, link error counters, baud rate), using only what the logs show.

## Where the work goes

- **Timing:** `quartus/reports/fecim.sta.summary` (task A7).
- **Hardware check:** `python sw/examples/check_hw_vs_model.py --backend fpga --port <port>` (task C8), run on both boards.
- **Log:** `results/l4/`, committed.
- **Post:** the team channel and the Planner task.

## Steps the owner is following

1. Build the bitstream from `main` with the timing constraints. Record setup and hold slack at the slow corner.
2. Program board 1. Confirm `IDENTIFY` reports the expected `BUILD_ID`.
3. Run the full hardware check matrix. It prints one line per case and a final `PASS n/n`.
4. Send the same bitstream to Natalie; she repeats steps 2 and 3 on board 2.
5. Check `CYCLE_CNT` reads 392 for a full-tile compute.
6. Commit the log and post:

   ```text
   Timing: setup slack <x> ns, hold slack <y> ns (slow 85C)   build <id>   commit <hash>
   L4 board 1: PASS n/n     L4 board 2: PASS n/n     CYCLE_CNT = 392
   ```

If a case fails on hardware but passed in simulation, check in this order: the bitstream is the one you think it is (`BUILD_ID`); timing slack is positive; the identify block's error counters are zero; then run the failing case at 115200 baud to rule out the link.

## What done looks like

- Positive setup and hold slack at the slow corner, with the report committed.
- The full matrix passes on both boards with the same bitstream.
- `CYCLE_CNT` matches the model.
- The log is committed and the result is posted with build ID and commit hash.

## Things to keep in mind

- **A mismatch only when read noise is enabled** usually means a missing reseed or a different order of operations on the two backends, not a hardware fault.
- **A mismatch that comes and goes** points at timing or the link. A consistent mismatch points at logic.
- If this slips past Wed 25, the hardware classifier runs and sweeps slip with it. Say so immediately; the `sim`-backend versions of D6–D8 can proceed regardless.
- Both boards should carry the same bitstream from here to the presentation.

## What to give the model along with this prompt

- `quartus/reports/fecim.sta.summary`
- The `results/l4/` logs from both boards
- The `IDENTIFY` output from each board

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

