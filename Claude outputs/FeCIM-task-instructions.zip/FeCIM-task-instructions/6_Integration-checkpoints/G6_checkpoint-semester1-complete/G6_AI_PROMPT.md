# AI prompt — G6: Checkpoint: semester-1 complete, every Must task Completed

> **How to use this file.** Everything below the line is the prompt. Paste it into any chatbot, together with the material listed under "What to give the model along with this prompt". Check the reply's "Needs your input" list before you post or commit the draft.

---

## Project context

You're helping a four-person undergraduate capstone team at the University of Florida (CEN 4907C) finish the first semester of **FeCIM**, a digital emulator of a ferroelectric (FeFET) compute-in-memory crossbar. A crossbar computes a matrix-vector product in analog; FeCIM reproduces that computation in SystemVerilog on a DE10-Lite FPGA board (128×128 tile, 64 MAC lanes, 7.84 µs per multiply) and injects six device non-idealities that can each be switched on alone: conductance quantization, device-to-device variation, stuck-at faults, read noise, IR drop and ADC quantization. A Python host drives the board over UART, a bit-exact C++ model checks every hardware result, and the demo is a digit classifier whose accuracy is measured as each non-ideality is turned up, calibrated against a published FeFET parameter set (Chatterjee et al., IEEE TED 2022).

**Team.** Lane A — Zhiting Li: host-interface RTL, top level, board bring-up. Lane B — Megan Mendez: array RTL. Lane C — Ethan Ruddell: C++ model, verification, calibration (team lead for scheduling). Lane D — Natalie Poche: Python host stack, application, sweeps.

**Schedule.** Work runs Mon 16 Nov to the presentation on Tue 1 Dec 2026. The last in-person meeting with both boards before the dry run is Thu 19 Nov. Thanksgiving break (Mon 23 – Sat 28 Nov) is working time, except Thanksgiving Day itself. There's a virtual sync on Fri 27 Nov, all work is due Sat 28 Nov, the merge cutoff is Sun 29 Nov at 18:00, and the in-person dry run is Mon 30 Nov. The team owns two DE10-Lite boards and two CP2102 USB-UART dongles. Tasks are tracked in Microsoft Teams Planner, and the course (milestone "M0") grades evidence that is committed to the GitHub repository.

**Facts that must stay accurate in anything you draft.**
- A full 128×128 multiply takes 392 cycles = 7.84 µs. An early estimate of 2.7 µs was wrong and was corrected.
- The FPGA has 144 multiplier *blocks* (not 288 multipliers). That forced 9-bit operands, a ±127 noise clamp and a triangular (not Gaussian) device-variation distribution.
- Calibration uses *published* FeFET data, not the team's own measurements. Radiation effects are permanently out of scope; retention drift is planned for semester 2.
- Don't invent results, numbers, dates or quotes. Where a number isn't in what you were given, leave a clearly marked placeholder and list it at the end.

## Your task

Task **G6 — Checkpoint: semester-1 complete, every Must task Completed**, owned by Ethan Ruddell, due Sat 28 Nov.

From the Planner export and the list of evidence links provided, produce the checkpoint report: the deliverable table with a link or "missing" in each row, the list of open tasks grouped into "can finish Sunday morning" and "should be cut", and for each proposed cut a one-sentence, factual disclosure suitable for a presentation slide. Mark a row as evidenced only if a link for it is in the material given.

## Where the work goes

- **Checklist:** the Planner board (every task) and the deliverable list at the top of `semester1-planner-board-rev3.md`.
- **Evidence:** links in each Planner task's comments: PRs, CI runs, logs, reports.
- **Post:** the team channel.

## Steps the owner is following

Walk the semester-1 deliverable, one line at a time, and link the evidence for each:

| Deliverable | Evidence to link |
|---|---|
| 128×128 tile, 64 lanes, on the board at 50 MHz | fit and timing summaries (A5, A7) |
| All six non-idealities, each switchable | L1 run per effect (C5), golden-vector tests |
| Bit-exact in simulation and on hardware | L0 (C4), L1/L2 (C5), L4 log from both boards (C8) |
| Calibrated against a published parameter set | `device-model.md` set A section (C6), L3 summary (C9) |
| Digit classifier demo, linear and MLP | scripts and result tables (D6, D7), recordings |
| Headline plots from hardware | `results/` and `docs/img/plots/` (D8) |
| Documentation | utilization, verification, user guide, API, replication guide (B9, C10, D9, A9) |
| Release | GitHub Release with bitstream and wheel (A9, D9) |

Then go through the Planner board task by task. For each one that isn't Completed, choose one:

1. It can finish Sunday morning: name the owner and a helper.
2. It's cut: write the one-line disclosure for the slides now.

Post the result:

```text
Semester-1 checkpoint, Sat 28: <n> of <m> tasks Completed.
Open for Sunday morning: <task IDs, owner + helper>
Cut and disclosed: <task IDs, the one line each>
main is green at commit <hash>.
```

## What done looks like

- Every row of the deliverable table has a link or is marked cut.
- Every Planner task is Completed, assigned for Sunday morning, or cut with its disclosure written.
- `main` is green in CI.
- The status post is in the channel.

## Things to keep in mind

- "It works on my branch" isn't Completed. The evidence has to be on `main`.
- Cutting something on Saturday with an honest sentence is better than demonstrating something half-working on Tuesday.
- Nothing new starts on Sunday. Sunday morning is for finishing and fixing only.

## What to give the model along with this prompt

- An export of the Planner board with task status
- The evidence links (PRs, CI runs, report paths, log paths)
- The deliverable list from `semester1-planner-board-rev3.md`

## How to respond

Produce the draft the task asks for, ready to paste or commit, in plain language an engineering undergraduate would use. Keep it as short as the content allows.

After the draft, add a short list headed "Needs your input" with every placeholder you left, every assumption you made, and anything in the material you were given that looks inconsistent. Don't fill a gap with a plausible-sounding fact.

