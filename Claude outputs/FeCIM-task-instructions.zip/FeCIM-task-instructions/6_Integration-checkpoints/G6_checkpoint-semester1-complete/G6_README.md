# G6 — Checkpoint: semester-1 complete, every Must task Completed

| | |
|---|---|
| **Owner** | Ethan Ruddell |
| **Due** | Sat 28 Nov |
| **Board bucket** | Bucket 6 — Integration Checkpoints |
| **Board task** | Checkpoint: semester-1 complete — every Must task Completed |
| **Needs first** | every task in buckets 2–5 and P1–P4 |
| **Unblocks** | X1 (merge cutoff), P5 (rehearsal), X2 (dry run) |
| **AI version** | `G6_AI_PROMPT.md`, in this folder |

## 1. What this is and why it matters

"Done" needs a moment when someone checks. Without one, the last 10 % of every task drifts into the final night, and the dry run becomes the first time anyone sees the whole thing together.

This checkpoint is that moment, set a full day before the merge cutoff. Saturday night, every task on the board is either Completed with its evidence linked, or explicitly cut with a line in the slides saying so. That leaves Sunday morning as real slack: time for the one thing that inevitably breaks, with nothing else competing for it.

It's also the semester-1 deliverable's acceptance check. The project plan defines semester 1 as a list: full tile, all six non-idealities, calibrated against a published set, classifier demo. Walking that list against the repository is how we know we can claim it.

## 2. Where the work goes

- **Checklist:** the Planner board (every task) and the deliverable list at the top of `semester1-planner-board-rev3.md`.
- **Evidence:** links in each Planner task's comments: PRs, CI runs, logs, reports.
- **Post:** the team channel.

## 3. How to do it

Walk the semester-1 deliverable, one line at a time, and link the evidence for each:

| Deliverable | Evidence to link |
|---|---|
| 128×128 tile, 64 lanes, on the board at 50 MHz | fit and timing summaries (A5, A7) |
| All six non-idealities, each switchable | L1 run per effect (C5), golden-vector tests |
| Bit-exact in simulation and on hardware | L0 (C4), L1/L2 (C5), L4 log from both boards (C8) |
| Calibrated against a published parameter set | `device-model.md` set A section (C6), L3 summary (C9) |
| Digit classifier demo, linear and MLP | scripts and result tables (D6, D7), recordings |
| Headline plots from hardware | `results/` and `docs/img/plots/` (D8) |
| Documentation | utilization, verification, user guide, API, replication guide (B9, C10, D9, A9) |
| Release | GitHub Release with bitstream and wheel (A9, D9) |

Then go through the Planner board task by task. For each one that isn't Completed, choose one:

1. It can finish Sunday morning: name the owner and a helper.
2. It's cut: write the one-line disclosure for the slides now.

Post the result:

```text
Semester-1 checkpoint, Sat 28: <n> of <m> tasks Completed.
Open for Sunday morning: <task IDs, owner + helper>
Cut and disclosed: <task IDs, the one line each>
main is green at commit <hash>.
```

## 4. How you know it's done

- Every row of the deliverable table has a link or is marked cut.
- Every Planner task is Completed, assigned for Sunday morning, or cut with its disclosure written.
- `main` is green in CI.
- The status post is in the channel.

## 5. Watch out for

- "It works on my branch" isn't Completed. The evidence has to be on `main`.
- Cutting something on Saturday with an honest sentence is better than demonstrating something half-working on Tuesday.
- Nothing new starts on Sunday. Sunday morning is for finishing and fixing only.

## 6. Workflow

1. Do the steps above, using the AI version (`*_AI_PROMPT.md` in this folder) for the first draft if that helps. Check every fact in an AI draft against the repo or the board before it goes out.
2. Anything the course grades (logs, run sheets, reports, slides) gets **committed to the repo**. A message in Teams isn't evidence.
3. Mark the Planner task Completed, paste the link to the commit, PR or document into its comments, and post one line in the daily check-in thread.

